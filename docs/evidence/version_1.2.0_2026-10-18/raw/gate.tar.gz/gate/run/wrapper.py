"""Run the version-only candidate's committed full gate without changing prior evidence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE = Path('/home/resense/data/version_1_2_0_candidate')
COMMIT = 'e9d8fc649f2dd51dd5cd1e4b04ac8c306cc02569'
ROOT = Path('/home/resense/ReSense')
OUTPUT = ROOT / 'docs/evidence/version_1.2.0_2026-10-18'
CACHE = Path('/home/resense/data/gate_cache')
WORK = Path('/home/resense/data/version_1_2_0_gate_work')
STATUS = Path('/home/resense/data/version_1_2_0_gate_status.json')
LOG = Path('/home/resense/data/logs/version_1_2_0_gate.log')
sys.path.insert(0, str(SOURCE / 'scripts'))
from cache_io import validate_extended_ride_cache
from detector_freeze import source_hashes, source_digest


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


assert not STATUS.exists() and not (OUTPUT / 'gate.json').exists() and not WORK.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == COMMIT
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
files = source_hashes(SOURCE)
libs = {str(p.relative_to(SOURCE)): sha(p) for p in (SOURCE / 'resense').glob('*.so')}
assert len(libs) == 1 and set(libs.values()) == {'511f7766639f0ddab471a77263f7a343de19d0a8217dd7cd3a11635c8a7db2c8'}
expected = {'originals': ('e23166801794cdeb2dcd77a3cc8b40a906b1d9cefab6f26739e368234e9168be', 3940746006, 2488),
            'set_o': ('d41c2fb28475194a98efeca5d2ee3fd175c0aef350ffb92fff4c26d497e696e9', 1746145824, 1510),
            'ride': ('8124b627a8a70516a4023db522849f1cadae711e7b152b0f701535a69dab99ec', 17078961996, 11271)}
receipts = {}
for name, values in expected.items():
    path = CACHE / (name + '_receipt.json')
    data = json.loads(path.read_text())
    assert data['verified'] and (data['sha256'], data['bytes'], data['total_frames']) == values
    receipts[str(path)] = sha(path)
validation = validate_extended_ride_cache(str(CACHE / 'new_data'), load_arrays=False)
env = {**os.environ, 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
       'MKL_NUM_THREADS': '1', 'OPENBLAS_CORETYPE': 'Haswell', 'PYTHONPATH': str(SOURCE)}
for key in list(env):
    if key.startswith('RESENSE_N2_'):
        del env[key]
preflight = json.loads(subprocess.check_output([
    sys.executable, '-c', 'import json,resense;from resense import _native;'
    'from resense.config import DetectorConfig;'
    'print(json.dumps({"version":resense.__version__,"native":_native.enabled(),'
    '"replay_default":DetectorConfig().calibration.orientation_replay_frames}))'
], cwd=SOURCE, env=env, text=True))
assert preflight == {'version': '1.2.0', 'native': True, 'replay_default': 0}
command = [sys.executable, str(SOURCE / 'scripts/regression_gate.py'), '--cache', str(CACHE), '--jobs', '1',
           '--baseline', str(SOURCE / 'docs/evidence/results/regression_baseline_2026-09-29_shell_off.json'),
           '--out', str(OUTPUT / 'gate.json'), '--work', str(WORK)]
state = {'status': 'running', 'pid': os.getpid(), 'pgid': os.getpgrp(), 'source_commit': COMMIT,
         'source_root': str(SOURCE), 'source_files': files, 'source_sha256': source_digest(files),
         'native_libraries': libs, 'command': command, 'preflight': preflight,
         'input_receipt_sha256': receipts, 'ride_validation': validation,
         'started_utc': now(), 'wrapper_sha256': sha(Path(__file__)),
         'timings_informational_shared_one_cpu_host': True}
STATUS.write_text(json.dumps(state, indent=2) + '\n')
with LOG.open('w') as stream:
    result = subprocess.run(command, cwd=SOURCE, env=env, stdout=stream, stderr=subprocess.STDOUT)
state.update(status='finished', returncode=result.returncode, finished_utc=now(),
             source_unchanged=files == source_hashes(SOURCE),
             native_unchanged=libs == {str(p.relative_to(SOURCE)): sha(p) for p in (SOURCE / 'resense').glob('*.so')})
if (OUTPUT / 'gate.json').exists():
    state['report_sha256'] = sha(OUTPUT / 'gate.json')
STATUS.write_text(json.dumps(state, indent=2) + '\n')
raise SystemExit(result.returncode)
