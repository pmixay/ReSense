"""Task-local parallel use of the unchanged cache_bag; bounded to 3 DB3 files.

Archive inventory/size/SHA and every completed cache split are verified. The
repository's serial intake will subsequently verify/reuse this cache as well.
"""
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
import json
from pathlib import Path
import shutil
import tarfile
import time
import urllib.request

import zstandard
from scripts.cache_extended_ride import resolve_yadisk_asset, HashingReader, SPLIT_RE, _split_complete
from scripts.cache_frames import cache_bag
from scripts.cache_io import validate_extended_ride_cache

CACHE = Path('/tmp/opencode/resense-b4-data/cache/new_data')
SPOOL = Path('/tmp/opencode/resense-b4-data/parallel-spool')


def process(path, split):
    try:
        name, count = cache_bag(str(path), str(CACHE), every=1, int16=True, stamps=True, zstd_level=3)
        assert name == f'new_data_{split}' and count == 51
        validate_extended_ride_cache(str(CACHE), expected_splits=[split], frames_per_split=51, load_arrays=True)
        return split
    finally:
        path.unlink(missing_ok=True)


def main():
    SPOOL.mkdir(exist_ok=True)
    source = resolve_yadisk_asset()
    start = time.monotonic()
    seen, pending, reused, written = set(), set(), [], []
    with urllib.request.urlopen(source['download_url'], timeout=180) as response:
        hashed = HashingReader(response)
        with ProcessPoolExecutor(max_workers=3) as pool:
            with zstandard.ZstdDecompressor().stream_reader(hashed, closefd=False) as stream:
                with tarfile.open(fileobj=stream, mode='r|') as archive:
                    for member in archive:
                        match = SPLIT_RE.search(member.name)
                        if not match or not member.isfile():
                            continue
                        split = int(match.group(1))
                        assert split not in seen and 0 <= split < 221
                        seen.add(split)
                        if _split_complete(CACHE, split):
                            reused.append(split)
                            continue
                        while len(pending) >= 3:
                            done, pending = wait(pending, return_when=FIRST_COMPLETED)
                            for f in done:
                                written.append(f.result())
                                print(len(written), 'new;', len(reused), 'reused;', round(time.monotonic()-start), 's', flush=True)
                        assert shutil.disk_usage(SPOOL).free > 8 * 1024**3
                        path = SPOOL / f'new_data_{split}.db3'
                        with archive.extractfile(member) as src, path.open('wb') as dst:
                            shutil.copyfileobj(src, dst, length=4*1024*1024)
                        assert path.stat().st_size == member.size
                        pending.add(pool.submit(process, path, split))
            for f in pending:
                written.append(f.result())
        hashed.drain()
    assert seen == set(range(221))
    assert hashed.bytes_read == source['size']
    assert hashed.digest.hexdigest() == source['sha256']
    validation = validate_extended_ride_cache(str(CACHE), expected_splits=221, frames_per_split=51, load_arrays=True)
    report = {'source_bytes': hashed.bytes_read, 'source_sha256': hashed.digest.hexdigest(),
              'validation': validation, 'written': sorted(written), 'reused': sorted(reused),
              'elapsed_s': time.monotonic()-start}
    Path('/tmp/opencode/b4-parallel-ride.json').write_text(json.dumps(report, indent=1))
    print('COMPLETE', validation, flush=True)


if __name__ == '__main__':
    main()
