import os
from pathlib import Path
import subprocess

root = Path('/home/aiops/resense')
data = Path('/tmp/opencode/resense-b4-data')
python = '/tmp/opencode/resense-b4-venv/bin/python'
bags = ['doubleT_obstacle', 'doubleT_platform', 'roundT_doubleT', 'roundT_pressureGate_roundT',
        'roundT_squareT_pressureGate_squareT', 'squareT_platform_squareT_switch']
os.environ['PYTHONPATH'] = str(root)
missing = [b for b in bags if not (data / 'for_hackathon' / b).exists()]
if missing:
    subprocess.run([python, 'scripts/unpack_dataset.py', '/tmp/opencode/resense-b4-dataset.zip',
                    '--out', str(data), '--only', ','.join(missing)], cwd=root, check=True)
for bag in bags:
    subprocess.run([python, 'scripts/cache_frames.py', str(data / 'for_hackathon' / bag),
                    str(data / 'cache' / bag), '--every', '1', '--int16', '--stamps'], cwd=root, check=True)
print('SIX_READY', flush=True)
