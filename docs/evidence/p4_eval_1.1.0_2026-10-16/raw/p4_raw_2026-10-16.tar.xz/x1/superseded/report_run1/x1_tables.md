| case | version | visible | STOP hits | non-STOP | causes (frames) |
|---|---|---:|---:|---:|---|
| A_cube03 | 707ea9c | 157 | 29 | 128 | no_blob 106, drop:infra_hardware 7, drop:min_points 5, track:confirm_hits 5, drop:low_narrow 4, drop:oversize_split_refused 1 |
| A_cube03 | 1.1.0 | 157 | 29 | 128 | no_blob 106, drop:infra_hardware 7, drop:min_points 5, track:confirm_hits 5, drop:low_narrow 4, drop:oversize_split_refused 1 |
| A_cube05 | 707ea9c | 180 | 66 | 114 | no_blob 81, demoted:beyond_height_ref 9, drop:min_points 9, thin_scanline_only 3, track:confirm_time 3, track:hit_fraction 3, track:confirm_hits 2, drop:oversize_split_refused 1, track:zone_vote 1, track:confidence 1, drop:infra_hardware 1 |
| A_cube05 | 1.1.0 | 180 | 66 | 114 | no_blob 81, demoted:beyond_height_ref 9, drop:min_points 9, thin_scanline_only 3, track:confirm_time 3, track:hit_fraction 3, track:confirm_hits 2, drop:oversize_split_refused 1, track:zone_vote 1, track:confidence 1, drop:infra_hardware 1 |
| A_lowbox_rail | 707ea9c | 119 | 29 | 90 | no_blob 80, track:confirm_hits 6, drop:low_narrow 2, drop:oversize_split_refused 1, drop:infra_hardware 1 |
| A_lowbox_rail | 1.1.0 | 119 | 29 | 90 | no_blob 80, track:confirm_hits 6, drop:low_narrow 2, drop:oversize_split_refused 1, drop:infra_hardware 1 |
| B_person | 707ea9c | 119 | 28 | 91 | no_blob 47, demoted:beyond_axis 24, drop:oversize_split_refused 10, track:zone_vote 7, track:confidence 1, track:hit_fraction 1, unclassified:not_qualified 1 |
| B_person | 1.1.0 | 119 | 28 | 91 | no_blob 47, demoted:beyond_axis 24, drop:oversize_split_refused 10, track:zone_vote 7, track:confidence 1, track:hit_fraction 1, unclassified:not_qualified 1 |
| C_cube05 | 707ea9c | 151 | 50 | 101 | drop:oversize_split_refused 73, no_blob 17, track:confirm_hits 3, demoted:beyond_height_ref 3, track:confirm_time 2, thin_scanline_only 1, drop:infra_wall_segment 1, drop:infra_hardware 1 |
| C_cube05 | 1.1.0 | 151 | 50 | 101 | drop:oversize_split_refused 72, no_blob 17, track:confirm_hits 3, demoted:beyond_height_ref 3, track:confirm_time 2, thin_scanline_only 1, drop:infra_wall_segment 1, unclassified:not_qualified 1, drop:infra_hardware 1 |
| D_cube05 | 707ea9c | 316 | 121 | 195 | no_blob 84, demoted:beyond_axis 26, drop:oversize_split_refused 16, thin_scanline_only 14, track:confirm_hits 11, drop:min_points 10, drop:infra_hardware 9, track:confirm_time 9, track:approach_block 7, track:zone_vote 5, drop:infra_linear_side 1, unclassified:not_qualified 1, weak_far_only 1, drop:infra_wall_segment 1 |
| D_cube05 | 1.1.0 | 316 | 121 | 195 | no_blob 84, demoted:beyond_axis 26, drop:oversize_split_refused 16, thin_scanline_only 14, track:confirm_hits 11, drop:min_points 10, drop:infra_hardware 9, track:confirm_time 9, track:approach_block 7, track:zone_vote 5, drop:infra_linear_side 1, unclassified:not_qualified 1, weak_far_only 1, drop:infra_wall_segment 1 |
| E6_cable_low_c | 707ea9c | 59 | 29 | 30 | track:confirm_hits 22, track:confirm_time 6, track:hit_fraction 1, demoted:beyond_axis 1 |
| E6_cable_low_c | 1.1.0 | 59 | 29 | 30 | track:confirm_hits 22, track:confirm_time 6, track:hit_fraction 1, demoted:beyond_axis 1 |
| S_cube05_100 | 707ea9c | 260 | 94 | 166 | drop:oversize_split_refused 62, track:confirm_hits 30, drop:infra_wall_segment 12, track:explained_run 9, track:confirm_time 8, track:hit_fraction 7, weak_far_only 6, drop:min_points 6, stop_off_object 5, track:approach_block 4, track:confidence 3, drop:infra_hardware 3, unclassified:not_qualified 2, demoted:column 2, no_blob 1, demoted:floating 1, track:zone_vote 1, track:column_hold 1, outside_strict_gauge 1, demoted:elevated 1, drop:infra_linear_side 1 |
| S_cube05_100 | 1.1.0 | 260 | 94 | 166 | drop:oversize_split_refused 62, track:confirm_hits 30, drop:infra_wall_segment 12, track:explained_run 9, track:confirm_time 8, track:hit_fraction 7, weak_far_only 6, drop:min_points 6, stop_off_object 5, track:approach_block 4, track:confidence 3, drop:infra_hardware 3, unclassified:not_qualified 2, demoted:column 2, no_blob 1, demoted:floating 1, track:zone_vote 1, track:column_hold 1, outside_strict_gauge 1, demoted:elevated 1, drop:infra_linear_side 1 |
| S_person_100 | 707ea9c | 260 | 82 | 178 | drop:oversize_split_refused 46, track:column_hold 30, drop:infra_wall_segment 28, track:explained_run 24, demoted:column 14, track:confirm_hits 11, track:hit_fraction 8, track:confirm_time 5, track:confidence 4, demoted:wall_face 3, unclassified:not_qualified 2, demoted:elevated 1, track:doubt 1, outside_strict_gauge 1 |
| S_person_100 | 1.1.0 | 260 | 82 | 178 | drop:oversize_split_refused 46, track:column_hold 30, drop:infra_wall_segment 28, track:explained_run 24, demoted:column 14, track:confirm_hits 11, track:hit_fraction 8, track:confirm_time 5, track:confidence 4, demoted:wall_face 3, unclassified:not_qualified 2, demoted:elevated 1, track:doubt 1, outside_strict_gauge 1 |
| S_person_150 | 707ea9c | 259 | 90 | 169 | drop:infra_wall_segment 97, drop:oversize_split_refused 21, track:confirm_hits 12, demoted:beyond_height_ref 10, track:confirm_time 8, outside_strict_gauge 8, track:zone_vote 5, demoted:beyond_axis 4, track:confidence 3, no_blob 1 |
| S_person_150 | 1.1.0 | 259 | 90 | 169 | drop:infra_wall_segment 97, drop:oversize_split_refused 21, track:confirm_hits 12, demoted:beyond_height_ref 10, track:confirm_time 8, outside_strict_gauge 8, track:zone_vote 5, demoted:beyond_axis 4, track:confidence 3, no_blob 1 |
| setO | 707ea9c | 60 | 6 | 54 | drop:oversize_split_refused 20, no_blob 18, weak_far_only 8, track:confirm_hits 4, track:confirm_time 3, drop:infra_linear_side 1 |
| setO | 1.1.0 | 60 | 6 | 54 | drop:oversize_split_refused 20, no_blob 18, weak_far_only 8, track:confirm_hits 4, track:confirm_time 3, drop:infra_linear_side 1 |

Cause → non-STOP visible frames per distance bin (m), all cases, 1.1.0:

| cause | 3–30 | 30–60 | 60–100 | 100–150 | 150–200 | 200–260 | total |
|---|---:|---:|---:|---:|---:|---:|---:|
| no_blob | 0 | 8 | 65 | 103 | 143 | 116 | 435 |
| drop:oversize_split_refused | 0 | 1 | 84 | 116 | 48 | 1 | 250 |
| drop:infra_wall_segment | 0 | 0 | 19 | 40 | 80 | 0 | 139 |
| track:confirm_hits | 0 | 17 | 37 | 35 | 12 | 5 | 106 |
| demoted:beyond_axis | 0 | 0 | 13 | 31 | 9 | 2 | 55 |
| track:confirm_time | 0 | 5 | 22 | 14 | 3 | 0 | 44 |
| track:explained_run | 0 | 0 | 18 | 15 | 0 | 0 | 33 |
| track:column_hold | 0 | 0 | 7 | 24 | 0 | 0 | 31 |
| drop:min_points | 0 | 1 | 26 | 3 | 0 | 0 | 30 |
| drop:infra_hardware | 0 | 0 | 9 | 12 | 1 | 0 | 22 |
| demoted:beyond_height_ref | 0 | 0 | 0 | 13 | 9 | 0 | 22 |
| track:hit_fraction | 0 | 0 | 11 | 8 | 0 | 1 | 20 |
| track:zone_vote | 0 | 4 | 3 | 12 | 0 | 0 | 19 |
| thin_scanline_only | 0 | 0 | 0 | 9 | 7 | 2 | 18 |
| demoted:column | 0 | 0 | 6 | 10 | 0 | 0 | 16 |
| weak_far_only | 0 | 0 | 12 | 3 | 0 | 0 | 15 |
| track:confidence | 0 | 0 | 3 | 7 | 2 | 0 | 12 |
| track:approach_block | 0 | 0 | 7 | 4 | 0 | 0 | 11 |
| outside_strict_gauge | 0 | 0 | 1 | 7 | 2 | 0 | 10 |
| unclassified:not_qualified | 0 | 0 | 4 | 3 | 0 | 0 | 7 |
| drop:low_narrow | 0 | 6 | 0 | 0 | 0 | 0 | 6 |
| stop_off_object | 0 | 0 | 2 | 3 | 0 | 0 | 5 |
| drop:infra_linear_side | 0 | 0 | 1 | 1 | 0 | 1 | 3 |
| demoted:wall_face | 0 | 0 | 0 | 3 | 0 | 0 | 3 |
| demoted:elevated | 0 | 0 | 1 | 1 | 0 | 0 | 2 |
| demoted:floating | 0 | 0 | 0 | 1 | 0 | 0 | 1 |
| track:doubt | 0 | 0 | 1 | 0 | 0 | 0 | 1 |
