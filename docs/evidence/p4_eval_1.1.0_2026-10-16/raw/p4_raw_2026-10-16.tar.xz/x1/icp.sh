#!/bin/bash
R=/home/user/rs-707ea9c; D=/home/user/rs-data
for b in roundT_squareT_pressureGate_squareT squareT_platform_squareT_switch roundT_doubleT roundT_pressureGate_roundT; do
  T=$(date +%s)
  (cd $R && PYTHONPATH=$R:$R/ros2_ws/src/resense_ros RESENSE_REPO=$R OPENBLAS_CORETYPE=Haswell OMP_NUM_THREADS=1 /home/user/rs-py310/bin/python $R/docs/evidence/judgement_2026-10-13/scripts/icp_odometry.py $D/decoded/$b $D/x1/icp/icp_$b.json > $D/x1/icp/$b.log 2>&1); echo "$b exit=$? $(( $(date +%s)-T ))s"
done; echo ICP_DONE
