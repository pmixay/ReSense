#!/bin/bash
# decode.sh <bag_dir> <out_dir> : judge cache_decoded.py with the 707ea9c checkout imports
R=/home/user/rs-707ea9c
cd "$R" && PYTHONPATH=$R:$R/ros2_ws/src/resense_ros RESENSE_REPO=$R OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  /home/user/rs-py310/bin/python $R/docs/evidence/judgement_2026-10-13/scripts/cache_decoded.py "$1" "$2"
