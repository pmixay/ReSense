#!/bin/bash
# per_bag.sh <bag>: extract one organizer bag, J1 judge_runner on 707ea9c and 1.1.0 (pre-release),
# node-decode it (judge cache_decoded.py, 707ea9c imports), then delete the raw bag.
set -u
B=$1; D=/home/user/rs-data; J=/home/user/ReSense/docs/evidence/rejudge_2026-10-16/scripts
log() { echo "$(date -u +%FT%TZ) $B $*"; }
T=$(date +%s)
/home/user/rs-venv/bin/python -I /home/user/ReSense/scripts/unpack_dataset.py $D/dl/dataset.zip --out $D/raw --only $B > $D/logs/$B.unpack.log 2>&1 || { log UNPACK_FAIL; exit 1; }
log unpacked $(( $(date +%s)-T ))s
run_judge() { R=$1; tag=$2; mkdir -p $D/j1/$tag
  ( cd $R && PYTHONPATH=$R:$R/ros2_ws/src/resense_ros RESENSE_REPO=$R OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
    /home/user/rs-py310/bin/python $J/judge_runner.py --bag $D/raw/for_hackathon/$B --out $D/j1/$tag/$B > $D/logs/$B.j1_$tag.log 2>&1 ); log "judge_$tag exit=$?"; }
run_judge /home/user/rs-707ea9c 707ea9c &
run_judge /home/user/rs-1.1.0 prerelease_1.1.0 &
/home/user/rs-data/decode.sh $D/raw/for_hackathon/$B $D/decoded/$B > $D/logs/$B.decode.log 2>&1; log "decode exit=$?"
wait
rm -rf $D/raw/for_hackathon/$B; log "done $(( $(date +%s)-T ))s"
