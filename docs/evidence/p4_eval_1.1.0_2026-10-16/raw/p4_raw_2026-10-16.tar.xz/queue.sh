#!/bin/bash
D=/home/user/rs-data
( for b in squareT_platform_squareT_switch roundT_doubleT doubleT_platform; do $D/per_bag.sh $b; done ) &
( $D/per_bag.sh doubleT_obstacle
  until grep -q exit= $D/decode_seto.log; do sleep 10; done
  grep -q exit=0 $D/decode_seto.log && rm -rf $D/raw/cloud_with_fake_obj && echo "Set O raw removed after decode"
  for b in roundT_squareT_pressureGate_squareT roundT_pressureGate_roundT; do $D/per_bag.sh $b; done ) &
wait; echo QUEUE_DONE
