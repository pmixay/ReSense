"""Low foreign objects on the track (v0.6): bumps above the learned track-bed cross-section.

The organizers' size criterion is an object of 300 x 300 x 100 mm (Q&A session, 2026-09;
docs/organizers/QA_session.md). Lying on the bed between the rails such an object stays
below the rail head, i.e. below the bottom of any clearance-gauge polygon, and it is lower
than the rail fastenings and cable ducts the corridor stage has to ignore, so the ordinary
pipeline cannot see it by construction. It is, however, an *anomaly of the bed*: the
cross-section of a metro track (rails, fastenings, the concrete bed, the drainage trough)
is the same every metre, so

1. the **template** ``h_bed(dy)`` - the height above the rail head of the bed surface at
   lateral offset ``dy`` - is learned every frame from the dense near range (4-30 m) as a
   low percentile per 2.5 cm lateral bin, dilated by +-5 cm (the rail heads and their flanks
   belong to the template, not to the anomalies), and smoothed over frames;
2. at every along-track bin (2 m) the **local offset** of the bed returns from the template
   (the height reference drifts by centimetres with range) is the median residual of the
   points that look like bed (residual within -0.15 ... +0.05 m);
3. a point in the train's envelope (``|dy| <= half_width``) below the gauge polygon bottom
   whose residual exceeds ``min_excess`` is a **low candidate**; the candidates go to the
   clusterer with the corridor candidates (flagged, so that the low-hardware rule does not
   drop them) and a cluster made of them must be short along the track (rails, guard rails
   and cables are long), at least ``min_width`` wide, have ``min_points`` voxels and **reach
   the rail-head plane** (its highest point at least ``min_top`` above the rail head): the bed
   carries fixtures of the same size that stay below the rail head by design.

4. (v0.6.2) **objects straddling the envelope floor**: an object lying across a rail can have
   most of its points below the rail head and only its top above the envelope floor (the
   organizers' object in ``doubleT_obstacle``: ~21 points at 56 m, ~16 of them below the rail
   head, ~3 above the 0.12 m floor, top 0.10-0.15 m above the rail head). The rule of step 3 that
   every candidate be ``min_point_top`` above the rail head (it keeps the rail fittings out)
   leaves it two points. ``low_candidates`` therefore also returns every bed anomaly without that
   rule; the detector clusters them together with the corridor points just above the floor and
   reports such a cluster only when its top reaches ``straddle_min_top`` (0.10 m) above the rail
   head - above the 1-8 cm the rail fittings reach (EXPERIMENTS.md §1d) - and it is at least
   ``straddle_min_width`` (0.35 m) wide across the track and at most ``straddle_max_length``
   (0.8 m) long along it: the trackside devices beside the rails (train stops, lubricators,
   signalling) reach 0.2-0.35 m but are mounted along the rail, 0.2-0.3 m across and 0.5-1.4 m
   long; without this shape rule the path added 49 false events on the 20-minute ride.

5. An opt-in central near-bed path accepts a compact, sufficiently raised anomaly below
   the rail head only within 30 m, inside the rail pair, with local bed support and current
   rail lock. Disabled by default pending real-ride false-positive evaluation. The
   point-wise rail-head rule and the straddle thresholds stay unchanged.

Where the bed is not observed (beyond ~50-80 m, grazing incidence) there is no local
offset and nothing is reported: the stage's range is where the bed is seen. Puddles in the
trough return nothing or mirror images *below* the bed (negative residuals): they are
ignored by construction.
"""
from __future__ import annotations

from typing import Optional

import numpy as np

from resense import _native
from resense.config import LowObjectConfig
from resense.track import bin_percentile


class BedTemplate:
    """The learned cross-section h_bed(dy) (smoothed across frames)."""

    def __init__(self, cfg: LowObjectConfig):
        self.cfg = cfg
        half = cfg.half_width + 0.15
        self.edges = np.arange(-half, half + cfg.template_bin, cfg.template_bin)
        self.centres = 0.5 * (self.edges[:-1] + self.edges[1:])
        self.prof: Optional[np.ndarray] = None

    def reset(self) -> None:
        self.prof = None

    def update(self, X: np.ndarray, dy: np.ndarray, h: np.ndarray) -> Optional[np.ndarray]:
        cfg = self.cfg
        x0, x1 = cfg.template_range
        sel = _native.select(X.size, (dy, ">", self.edges[0], "<", self.edges[-1]), (h, ">", -1.2, "<", 0.4),
                             (X, ">", x0, "<", x1))       # np.flatnonzero of the mask below; None: numpy
        if sel is None:
            sel = (X > x0) & (X < x1) & (dy > self.edges[0]) & (dy < self.edges[-1]) & (h > -1.2) & (h < 0.4)
        n_sel = int(sel.sum()) if sel.dtype == bool else sel.size
        if n_sel < 200:
            return self.prof
        nb = self.edges.size - 1
        b = np.clip(np.digitize(dy[sel], self.edges) - 1, 0, nb - 1)
        prof, _ = bin_percentile(h[sel].astype(np.float64), b, nb, cfg.template_percentile, cfg.template_min_points)
        ok = np.isfinite(prof)
        if ok.sum() < nb // 3:
            return self.prof
        prof = np.interp(self.centres, self.centres[ok], prof[ok])
        k = max(0, int(round(cfg.template_dilate / cfg.template_bin)))
        if k:
            pad = np.pad(prof, k, mode="edge")
            prof = np.max(np.stack([pad[i:i + nb] for i in range(2 * k + 1)]), axis=0)
        if self.prof is None:
            self.prof = prof
        else:
            a = cfg.template_smoothing
            self.prof = a * self.prof + (1.0 - a) * prof
        return self.prof

    def __call__(self, dy: np.ndarray) -> np.ndarray:
        return np.interp(dy, self.centres, self.prof)


def local_surface_mask(X: np.ndarray, dy: np.ndarray, h: np.ndarray,
                       candidates: np.ndarray, reference: np.ndarray,
                       cfg: LowObjectConfig, support_mask: Optional[np.ndarray] = None) -> np.ndarray:
    """Which candidate returns continue a locally observed bed/rail surface?

    ``candidates`` indexes this frame; ``reference`` is the baseline bed height at
    those indices. ``support_mask`` selects the already classified bed returns. No
    lack-of-support rejection: every failed check returns False. This deliberately
    does not infer a surveyed surface identity from a scan line.
    Work is capped at 512 candidate returns; busier frames retain baseline evidence.
    """
    reject = np.zeros(candidates.size, dtype=bool)
    if not cfg.local_support_enabled or candidates.size == 0 or candidates.size > 512:
        return reject
    radius = float(cfg.local_support_along)
    guard = max(float(cfg.local_support_guard), 0.3)
    lateral = float(cfg.local_support_lateral)
    tol = float(cfg.local_support_tolerance)
    correction = float(cfg.local_support_max_correction)
    if not (0 < guard < radius <= 12.0 and 0.025 < lateral <= 0.25
            and 0 < tol <= 0.03 and 0 < correction <= 0.15):
        return reject
    finite = np.isfinite(X) & np.isfinite(dy) & np.isfinite(h)
    eligible = finite.copy()
    if support_mask is not None:
        eligible &= np.asarray(support_mask, dtype=bool)
    order = np.flatnonzero(eligible)
    order = order[np.argsort(X[order])]
    xs = X[order]
    for k, j in enumerate(candidates):
        if not finite[j] or not np.isfinite(reference[k]):
            continue
        lo, hi = np.searchsorted(xs, [X[j] - radius, X[j] + radius])
        ids = order[lo:hi]
        dx, dd = X[ids] - X[j], dy[ids] - dy[j]
        use = ((np.abs(dx) > guard) & (np.abs(dd) >= 0.025)
               & (np.abs(dd) <= lateral))
        # Support on just one rail edge must not masquerade as a local surface.
        if not all(np.any(use & along & side) for along in (dx < -guard, dx > guard)
                   for side in (dd < -0.025, dd > 0.025)):
            continue
        # Identical dual returns cannot manufacture support. Count one occupied cell per
        # small along/lateral cell, then use one p90 per one-metre along bin, as in the
        # trace diagnostic. This prevents one dense scan row dominating the line.
        pts = np.column_stack((X[ids[use]], dy[ids[use]], h[ids[use]]))
        if len(pts) < 8:
            continue
        cells = np.floor(pts[:, :2] / [0.05, 0.025]).astype(np.int64)
        _, unique = np.unique(cells, axis=0, return_index=True)
        pts = pts[np.sort(unique)]
        bins = np.floor(pts[:, 0]).astype(np.int64)
        values = np.asarray([np.percentile(pts[bins == b, 2], 90)
                             for b in np.unique(bins) if (bins == b).sum() >= 2])
        bin_ids = np.asarray([b for b in np.unique(bins) if (bins == b).sum() >= 2])
        left, right = bin_ids < np.floor(X[j] - guard), bin_ids > np.floor(X[j] + guard)
        if left.sum() < 2 or right.sum() < 2 or values.size < 4:
            continue
        line = float(np.median(values))
        consistent = np.percentile(np.abs(values - line), 90) <= tol
        if consistent and 0 < line - reference[k] <= correction:
            reject[k] = abs(h[j] - line) <= tol
    return reject


def low_candidates(X: np.ndarray, dy: np.ndarray, h: np.ndarray, template: BedTemplate,
                   cfg: LowObjectConfig, range_min: float, x_limit: float,
                   h_bottom: float, with_all: bool = False, with_near: bool = False):
    """(indices of low candidates, range up to which the bed was observed); with ``with_all``
    also the indices of every bed anomaly before the ``min_point_top`` rule (step 4).
    ``with_near`` adds dense-bed, central near-range anomalies independently of that rule."""
    empty = np.zeros(0, dtype=np.int64)

    def result(kept, seen_range, all_idx=empty, near_idx=empty):
        return ((kept, seen_range, all_idx, near_idx) if with_near else
                (kept, seen_range, all_idx) if with_all else (kept, seen_range))

    if template.prof is None:
        return result(empty, 0.0)
    x1 = min(cfg.range_max, x_limit)
    idx = _native.select(X.size, (dy, None, None, "<=", cfg.half_width, True), (h, ">", -1.2, "<", h_bottom),
                         (X, ">=", range_min, "<", x1))
    if idx is None:
        band = (X >= range_min) & (X < x1) & (np.abs(dy) <= cfg.half_width) & (h < h_bottom) & (h > -1.2)
        idx = np.flatnonzero(band)
    if idx.size == 0:
        return result(idx, 0.0)
    res = h[idx] - template(dy[idx])
    edges = np.arange(range_min, x1 + cfg.local_bin, cfg.local_bin)
    nb = edges.size - 1
    b = np.clip(np.digitize(X[idx], edges) - 1, 0, nb - 1)
    bed = (res > -0.15) & (res < 0.05)
    off, cnt = bin_percentile(res[bed].astype(np.float64), b[bed], nb, 50.0, cfg.local_min_points)
    seen = np.isfinite(off)
    if not seen.any():
        return result(empty, 0.0)
    # the bed is "observed" up to the last bin with bed returns (gaps of a few bins are bridged)
    last = int(np.flatnonzero(seen)[-1])
    x_seen = float(edges[last + 1])
    centres = 0.5 * (edges[:-1] + edges[1:])
    off = np.interp(centres, centres[seen], off[seen])
    r = res - off[b]
    anomaly = (r > cfg.min_excess) & (r < cfg.max_excess) & (X[idx] < x_seen)
    local_reject = np.zeros(idx.size, dtype=bool)
    if cfg.local_support_enabled:
        proposed = anomaly.copy()
        if with_near and cfg.near_enabled:
            proposed |= ((r > cfg.near_min_excess) & (r < cfg.max_excess)
                         & (X[idx] < min(cfg.near_range, x_seen))
                         & (np.abs(dy[idx]) <= cfg.near_half_width))
        # Use the current low-height band, including non-anomalous returns; distant or
        # high corridor surfaces cannot establish this local bed reference.
        local_reject[proposed] = local_surface_mask(
            X[idx], dy[idx], h[idx], np.flatnonzero(proposed), h[idx][proposed] - r[proposed], cfg,
            support_mask=bed)
        anomaly &= ~local_reject
    keep = anomaly.copy()
    keep &= ~local_reject
    if cfg.min_point_top > -1.0:
        keep &= h[idx] > cfg.min_point_top
    # Require bed support in the *same* along-track bin: interpolation across an unobserved
    # trough / puddle or gap in the bed must not produce a near-bed alarm.
    near = empty
    if with_near and cfg.near_enabled:
        central_bed = bed & (np.abs(dy[idx]) <= cfg.near_half_width)
        cb = b[central_bed]
        lat = np.floor((dy[idx][central_bed] + cfg.near_half_width)
                       / max(cfg.template_bin, 1e-6)).astype(np.int64)
        # distinct lateral template bins with bed returns per along-track bin: one
        # np.unique over (along-track bin, lateral bin) pairs instead of a loop over bins
        spread = np.zeros(nb, dtype=np.int64)
        if lat.size:
            lat -= lat.min()
            span = int(lat.max()) + 1
            spread = np.bincount(np.unique(cb.astype(np.int64) * span + lat) // span, minlength=nb)
        near_seen = ((np.bincount(cb, minlength=nb) >= cfg.local_min_points)
                     & (spread >= cfg.near_min_bed_lateral_bins))
        central = ((r > cfg.near_min_excess) & (r < cfg.max_excess)
                   & (X[idx] < min(cfg.near_range, x_seen)) & (np.abs(dy[idx]) <= cfg.near_half_width)
                   & seen[b] & near_seen[b] & ~local_reject)
        near = idx[central]
    return result(idx[keep], x_seen, idx[anomaly], near)


def _band_line(X: np.ndarray, dy: np.ndarray, h: np.ndarray, d0: float, d1: float, x_lo: float, x_hi: float,
               g0: float, g1: float, step: float, min_count: int, min_bins: int) -> Optional[float]:
    """The height of a lateral band's own line along the track (19.10, F1): the median over ``step``
    along-track bins in [``x_lo``, ``x_hi``], outside [``g0``, ``g1``] (the cluster's extent and its
    guard), of each bin's highest return with ``d0 <= dy <= d1`` and -0.3 < h < 0.3 (rail heads, not
    the structure above them); None with fewer than ``min_bins`` bins of ``min_count`` returns."""
    m = ((X >= x_lo) & (X < x_hi) & ((X < g0) | (X > g1)) & (dy >= d0) & (dy <= d1) & (h > -0.3) & (h < 0.3))
    if int(np.count_nonzero(m)) < min_bins * min_count:
        return None
    b = np.floor((X[m] - x_lo) / step).astype(np.int64)
    nb = int(b.max()) + 1
    cnt = np.bincount(b, minlength=nb)
    top = np.full(nb, -np.inf)
    np.maximum.at(top, b, h[m].astype(np.float64))
    ok = cnt >= min_count
    if int(ok.sum()) < min_bins:
        return None
    return float(np.median(top[ok]))


def local_rail_reference(c, X: np.ndarray, dy: np.ndarray, h: np.ndarray, cfg: LowObjectConfig,
                         rails_spacing: float) -> Optional[float]:
    """19.10 (F1 task a, ``lowobj.local_rail_margin``): the rail-head height at low cluster ``c``'s
    lateral position, measured from this frame's own rail returns instead of the model's plane (which is
    extrapolated beyond ``template_range`` / ``rails_range``). Each rail's line is :func:`_band_line` of
    the band ``|dy -+ rails_spacing / 2| <= local_rail_band`` within ``local_rail_window`` m of the
    cluster along the track, 0.5 m bins with >= 1 return, at least ``local_rail_min_bins`` of them
    (beyond ~40 m a ring crosses the rail head every few metres). Both lines: linear across the bed at
    the cluster's lateral (a canted track). One line: only for a cluster on that rail's half of the bed
    within 0.3 m of the rail; otherwise None (no reference, no change). Heights in ``h``'s frame (above
    the model's rail-head plane)."""
    w, guard = float(cfg.local_rail_window), 0.3
    x0, x1 = float(c.bbox_min[0]), float(c.bbox_max[0])
    half, band = 0.5 * float(rails_spacing), float(cfg.local_rail_band)
    lines = {}
    for s in (-1.0, 1.0):
        lines[s] = _band_line(X, dy, h, s * half - band, s * half + band, x0 - w, x1 + w, x0 - guard, x1 + guard,
                              0.5, 1, int(cfg.local_rail_min_bins))
    lat = float(c.lateral)
    lo, hi = lines[-1.0], lines[1.0]
    if lo is not None and hi is not None:
        cross = float(getattr(cfg, "local_rail_cross_tol", 0.0))
        if cross > 0 and abs(hi - lo) > cross:
            # amendment 7 (F1a''): the rails disagree - an object along one rail raises only its line (review 1,
            # B1), real cant makes one rail higher: the lower line, the lenient choice, for every cluster
            return min(lo, hi)
        t = min(1.0, max(0.0, (lat + half) / (2.0 * half)))
        return lo + t * (hi - lo)
    for s, line in ((-1.0, lo), (1.0, hi)):
        if line is not None and s * lat > 0 and abs(lat - s * half) <= 0.3:
            return line
    return None


def low_free_mask(n: int, clusters) -> np.ndarray:
    """19.10 (F1a', amendment 6): the frame's returns that belong to no low cluster of ``clusters`` (kind
    ``low``: clean, straddle-continuation or marked alike). The rail lines of :func:`rail_reference_check` are
    measured on these only, so the pieces of one long low object lying along a rail cannot raise each other's
    reference (independent review 1, finding B1)."""
    free = np.ones(int(n), dtype=bool)
    for c in clusters:
        if c.kind == "low" and c.points_idx.size:
            free[c.points_idx] = False
    return free


def rail_reference_check(clusters, X: np.ndarray, dy: np.ndarray, h: np.ndarray, cfg: LowObjectConfig,
                         rails_spacing: float, free: Optional[np.ndarray] = None) -> list:
    """19.10 (F1 tasks a and b): the clean low clusters of ``clusters`` (kind ``low``, zone gauge, no
    reason, not weak) that do not rise above the rails around them: (a) ``local_rail_margin`` > 0 and
    the top (``height_max``) below :func:`local_rail_reference` + margin; (b) ``rail_band_range`` > 0, the
    cluster nearer than it, narrow (<= ``rail_start_max_width``), reaching a rail line (within
    ``rail_start_lateral``, as :func:`mark_rail_line`) and its top at most ``rail_band_margin`` above its
    own lateral band's line along the track (0.25 m bins, >= 2 returns, >= 4 bins, within
    ``local_rail_window``; no ``rail_start_min_ref`` condition). ``free`` (amendment 6): the frame's returns
    the lines may be measured on (:func:`low_free_mask`); None = every return (the first measured version).
    Returns them; the detector makes them advisory (``local_rail_advisory``) or weak low evidence. The
    clusters themselves are not modified here."""
    out = []
    half = 0.5 * float(rails_spacing)
    Xr, dyr, hr = (X, dy, h) if free is None else (X[free], dy[free], h[free])
    for c in clusters:
        if c.kind != "low" or c.zone != "gauge" or c.reason or c.low_height_weak or not c.points_idx.size:
            continue
        top = float(c.height_max)
        if cfg.local_rail_margin > 0:
            ref = local_rail_reference(c, Xr, dyr, hr, cfg, rails_spacing)
            if ref is not None and top < ref + float(cfg.local_rail_margin):
                out.append(c)
                continue
        if cfg.rail_band_range > 0 and c.distance < cfg.rail_band_range:
            d = dy[c.points_idx]
            d0, d1 = float(d.min()), float(d.max())
            tol = float(cfg.rail_start_lateral)
            if (float(c.size[1]) <= cfg.rail_start_max_width
                    and any(d0 <= s * half + tol and d1 >= s * half - tol for s in (-1.0, 1.0))):
                x0, x1, w = float(c.bbox_min[0]), float(c.bbox_max[0]), float(cfg.local_rail_window)
                line = _band_line(Xr, dyr, hr, d0, d1, x0 - w, x1 + w, x0 - 0.3, x1 + 0.3, 0.25, 2, 4)
                if line is not None and top <= line + float(cfg.rail_band_margin):
                    out.append(c)
    return out


def no_rail_advisory(clusters, within: float) -> int:
    """19.10 (F1 task c, ``lowobj.no_rail_low_within``; the detector calls it on a frame without the rail
    pair, ``track.rail_slabs == 0``): a clean low cluster farther than ``within`` is advisory, reason
    ``no_rail_low``; a signature (``demoted``), so a STOP already earned is kept by the stop-keep rule.
    Returns how many."""
    n = 0
    for c in clusters:
        if c.kind == "low" and c.zone == "gauge" and not c.reason and c.distance > within:
            c.zone, c.reason, c.demoted = "warning", "no_rail_low", True
            n += 1
    return n


def mark_rail_line(clusters, X: np.ndarray, dy: np.ndarray, h: np.ndarray, cfg: LowObjectConfig,
                   rails_spacing: float, range_min: float) -> int:
    """26.09 (P3 rail start, ``rail_start_within`` > 0; docs/evidence/results/p3_rail_start_2026-09-26.json):
    set ``Cluster.rail_line`` on the low clusters near the train that are rail geometry, not an
    object; returns how many. A fresh start at a standing train saw the rail heads 3.0-3.6 m ahead
    3-12 cm above a young model's rail-head plane, in front of the range the bed cross-section is
    learned from (``template_range``), and STOPped on them (EXPERIMENTS §1j).

    ``X``, ``dy``, ``h``: the whole frame (vehicle X, track coordinates). A low cluster is marked
    when (1) it starts nearer than ``rail_start_within``; (2) its lateral extent reaches an expected
    rail line (the axis +- ``rails_spacing`` / 2) within ``rail_start_lateral``; (3) it is at most
    ``rail_start_max_width`` wide across the track (an object lying across a rail is wider); (4)
    the same lateral band continues along the track: at least 4 of the 0.25 m bins between
    ``range_min`` - 0.5 m and ``rail_start_within`` + 2 m, outside the cluster's extent +- 0.3 m,
    hold >= 2 returns (a piece of a structure elongated along the track); and (5) its top - the
    band's highest return within its extent, the corridor points above the envelope floor
    included - is at most ``rail_start_margin`` above the band's height where the cluster is not
    (the median of those bins' highest returns: the rail head's own line). An object standing on a
    rail rises above that line (the organizers' 0.10 m object by 0.10 m). Only where the heights
    are 0.3 m below to 0.6 m above the modelled rail head. (6) (safety review of 26.09) That line
    is at least ``rail_start_min_ref`` above the modelled rail head: the young model's fault the
    rule compensates (the finding: 0.135-0.148 m); under a correct model (~0) nothing is marked.
    The tracker withholds a new report of a marked track that was never matched at >=
    ``rail_start_within`` (``Tracker.update``); that clause is no safeguard (a track deleted after
    its misses, a detector reset or a re-mount starts again): the margins (5) and (6) are."""
    near = float(cfg.rail_start_within)
    todo = [c for c in clusters if c.kind == "low" and c.distance < near and c.points_idx.size]
    if not todo:
        return 0
    x_lo, x_hi, step = float(range_min) - 0.5, near + 2.0, 0.25
    sel = np.flatnonzero((X >= x_lo) & (X < x_hi) & (np.abs(dy) < cfg.half_width + 0.5) & (h > -0.3) & (h < 0.6))
    Xs, dys, hs = X[sel].astype(np.float64), dy[sel], h[sel]
    half, tol = 0.5 * float(rails_spacing), float(cfg.rail_start_lateral)
    nb = int(np.ceil((x_hi - x_lo) / step))
    n = 0
    for c in todo:
        d = dy[c.points_idx]
        d0, d1 = float(d.min()), float(d.max())
        if not any(d0 <= s * half + tol and d1 >= s * half - tol for s in (-1.0, 1.0)):
            continue
        if float(c.size[1]) > cfg.rail_start_max_width:
            continue
        x0, x1 = float(c.bbox_min[0]), float(c.bbox_max[0])
        band = (dys >= d0) & (dys <= d1)
        foot = band & (Xs >= x0) & (Xs <= x1)
        if not foot.any():
            continue
        out = band & ((Xs < x0 - 0.3) | (Xs > x1 + 0.3))
        b = np.clip(np.floor((Xs[out] - x_lo) / step).astype(np.int64), 0, nb - 1)
        cnt = np.bincount(b, minlength=nb)
        top_bin = np.full(nb, -np.inf)
        np.maximum.at(top_bin, b, hs[out].astype(np.float64))
        ok = cnt >= 2
        if int(ok.sum()) < 4:
            continue
        line = float(np.median(top_bin[ok]))
        if line >= cfg.rail_start_min_ref and float(hs[foot].max()) <= line + cfg.rail_start_margin:
            c.rail_line = True
            n += 1
    return n
