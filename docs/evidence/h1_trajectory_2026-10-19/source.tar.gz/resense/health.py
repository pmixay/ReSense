"""Input-health checks and an estimate of monitored range.

The range estimate describes the available model and surviving evidence; it can extend past
missed objects. :class:`HealthMonitor` computes,
per frame and without touching any detection:

* ``points`` - valid returns; a frame far below ``min_points`` (a dead or blinded sensor, a
  truncated message) is a fault, one below ``low_points_fraction`` of the running median a
  warning;
* ``near_fraction`` - returns closer than ``near_range``: a dirty or blocked window, spray;
* ``blocked_sectors`` - 10 deg azimuth sectors of the central +-30 deg without returns
  (something in front of the sensor);
* ``visibility`` - how far along the track the tunnel is seen (the 20th farthest return within
  3 m of the track axis): the sightline in a curve, the end of the tunnel, fog;
* ``rail_lock`` - share of the recent frames in which the rail pair was found (the track model
  runs on its prior without it: stations, switches, a covered bed);
* ``latency_p95_ms`` against the frame budget. The detector supplies the previous completed
  process interval, including health, and labels this basis and one-frame age in its result.
  Its first call/reset has no sample: p95 is 0 until a completed call is supplied;
* the mount calibration status and drift (``resense/calibration.py``); an unconfirmed
  axis orientation warns and reports zero monitored/clear range until observation or
  adoption confirms it, without suppressing obstacle evidence;
* ``floor_shadow_frames`` / ``floor_held_frames`` / ``floor_released_frames`` (review 25.09) -
  since the start (or a reset), the frames in which the floor-shadow rule of the track model
  (``track.floor_shadow_height``) found the shadow of a large near object, held the previous bed,
  or was released after ``track.floor_shadow_max_hold`` held frames in a row: counters only;
* ``monitored_range`` - an estimate based on visibility and the supported model this frame:
  ``min(visibility, trusted axis range, trusted height-reference range, gauge range)``, since 15.10
  also no farther than where the axis contradicts a near tunnel wall (``wall_drift``,
  ``track.axis_wall_drift``: the curve entry whose lagging axis leaves the track); and
  ``clear_distance`` - the nearest confirmed obstacle, or ``monitored_range`` when there is
  none; with ``clear_cap`` (on since 25.09, round 2) also no farther than the nearest unconfirmed
  or advisory candidate touching the envelope (``candidate_distance``, from the detector).
  Sparse, filtered or misclassified objects can remain beyond these caps. This estimate does
  not establish obstacle-free track or a braking guarantee. The node and consumers separately
  enforce input and result freshness.

``level`` is ``ok`` / ``warn`` / ``error`` with human-readable ``messages``; the ROS node
publishes it as ``diagnostic_msgs/DiagnosticArray`` and adds the input-staleness watchdog.
``decision_level`` (26.09) is the level the node's decision reads (``DetectorNode.decision``: a
``warn`` there is ``CAUTION``): ``level`` without the latency warning unless
``health.latency_affects_decision``. Latency over the budget is the machine being slow, not the
path being unsafe; it stays in ``level``, ``messages`` and ``latency_p95_ms``.
"""
from __future__ import annotations

from collections import deque
from typing import Optional

import numpy as np

from resense import _native
from resense.config import GaugeConfig, HealthConfig

LEVELS = ("ok", "warn", "error")


_F32_MAX = float(np.finfo(np.float32).max)


def _float32_at_least(edge: float) -> np.float32:
    """The smallest float32 >= ``edge``: for float32 ``v``, ``v >= edge`` exactly when ``v`` is at
    least this."""
    f = np.float32(edge)
    return np.nextafter(f, np.float32(np.inf)) if float(f) < edge else f


def _sector_counts(values: np.ndarray, edges: np.ndarray) -> np.ndarray:
    """Exact ``np.histogram(values, bins=edges)[0]`` for the small explicit edge array of health.

    Counts ``values >= edge`` for every edge and differences the counts: vectorised comparisons, no
    sort (``np.histogram`` sorts for explicit edges, slow on NumPy 1.x without AVX-512) and no
    per-value search (branchy, slower than ``np.histogram`` on NumPy 2). ``np.histogram`` compares
    float32 data with float64 edges exactly; float32 data are compared here with the float32
    threshold that gives the same answer for every float32 value (the smallest float32 at least the
    edge, or above the last edge), so the cloud is not converted. NaN fails every comparison and
    +-inf cancel out, as there. Unusual layouts/dtypes and subclass dispatch keep the original call.
    29.09 (docs/evidence/cycle_2026-09-29/health_compare_counts): replaces the 28.09 binary search.
    """
    floating = (np.dtype("float32"), np.dtype("float64"))
    if not (type(values) is np.ndarray and values.ndim == 1 and values.dtype in floating
            and type(edges) is np.ndarray and edges.ndim == 1 and edges.dtype in floating
            and 2 <= edges.size <= 257 and np.isfinite(edges).all()
            and (edges[1:] > edges[:-1]).all()):
        return np.histogram(values, bins=edges)[0]
    e = edges.astype(np.float64, copy=False).tolist()
    if values.dtype == np.float32 and max(abs(e[0]), abs(e[-1])) < _F32_MAX:
        at = [_float32_at_least(x) for x in e]
        above = at[-1] if float(at[-1]) > e[-1] else np.nextafter(at[-1], np.float32(np.inf))
        v = values
    else:
        v = values.astype(np.float64, copy=False)
        at, above = e, None
    at_least = np.array([np.count_nonzero(v >= x) for x in at], dtype=np.intp)
    beyond = np.count_nonzero(v > e[-1]) if above is None else np.count_nonzero(v >= above)
    counts = at_least[:-1] - at_least[1:]
    counts[-1] += at_least[-1] - beyond   # the last bin includes its right edge
    return counts


def visibility_along_track(xyz: np.ndarray, center_y, band: float = 3.0, k: int = 20) -> float:
    """X of the ``k``-th farthest return within ``band`` metres of the track axis (m)."""
    model = getattr(center_y, "__self__", None)       # TrackModel.center_y: one native pass
    if _native.enabled() and hasattr(model, "center_coefs") and not getattr(model, "bent", False):
        v = _native.visibility(xyz, *model.center_coefs(), band, k)
        if v is not None:
            return v
    X = xyz[:, 0]
    fwd = X > 0.0
    if not fwd.any():
        return 0.0
    Xf = X[fwd].astype(np.float64)
    sel = np.abs(xyz[fwd, 1] - center_y(Xf)) < band
    Xs = Xf[sel]
    if Xs.size == 0:
        return 0.0
    if Xs.size <= k:
        return float(Xs.min())
    return float(np.partition(Xs, Xs.size - k)[Xs.size - k])


class HealthMonitor:
    def __init__(self, cfg: HealthConfig):
        self.cfg = cfg
        self._points = deque(maxlen=200)
        self._lock = deque(maxlen=max(1, int(cfg.lock_window)))
        self._lat = deque(maxlen=max(1, int(cfg.latency_window)))
        self._shadow = [0, 0, 0]            # floor-shadow frames: found, held, released

    def reset(self) -> None:
        self._points.clear()
        self._lock.clear()
        self._lat.clear()
        self._shadow = [0, 0, 0]

    def update(self, xyz: np.ndarray, meta: dict, track, gauge: GaugeConfig, trusted_range: float,
               rails_min_score: float, latency_ms: Optional[float], calibration: Optional[dict] = None,
               obstacle_distance: Optional[float] = None, candidate_distance: Optional[float] = None,
               wall_drift: Optional[float] = None) -> dict:
        """Update scene health once; append a supplied latency sample, or none for ``None``.

        ``wall_drift`` (15.10, ``track.axis_wall_drift``): the X from which the axis contradicts a
        near tunnel boundary (``TrackModel.wall_drift``); the monitored range ends there and the
        output carries it as ``wall_drift`` (only when given).

        Numeric callers retain their existing supplied-interval semantics. The detector
        supplies its previous completed call so timing includes the health update itself.
        The latency warning still requires ten samples in the configured window.
        """
        cfg = self.cfg
        msgs, level, dlevel = [], 0, 0

        def flag(lv: int, text: str, decision: bool = True):
            nonlocal level, dlevel
            level = max(level, lv)
            if decision:
                dlevel = max(dlevel, lv)
            msgs.append(text)

        n = int(xyz.shape[0])
        n_raw = int(meta.get("n_raw", n))
        n_near = int(meta.get("n_near", 0))
        med = float(np.median(self._points)) if self._points else float(n)
        self._points.append(n)
        if n < cfg.min_points:
            flag(2, f"only {n} valid returns (< {cfg.min_points}): sensor blinded or message truncated")
        elif self._points and n < cfg.low_points_fraction * med:
            flag(1, f"{n} valid returns, {n / max(med, 1):.0%} of the running median")
        near_frac = n_near / max(n_raw, 1)
        if near_frac > cfg.max_near_fraction:
            flag(1, f"{near_frac:.0%} of the returns closer than {cfg.near_range} m: dirty or blocked window")

        # blocked sectors in the central +-30 deg
        blocked = 0
        if n:
            az = np.degrees(np.arctan2(xyz[:, 1], xyz[:, 0]))
            edges = np.arange(-30.0, 30.0 + 1e-6, cfg.sector_deg)
            counts = _sector_counts(az, edges)
            ref = float(np.median(counts)) if counts.size else 0.0
            blocked = int((counts < 0.05 * max(ref, 1.0)).sum()) if ref > 0 else int(counts.size)
            if blocked:
                flag(2 if blocked >= counts.size // 2 else 1,
                     f"{blocked} of {counts.size} central {cfg.sector_deg:.0f} deg sectors without returns: view blocked")

        vis = visibility_along_track(xyz, track.center_y) if n else 0.0
        if vis < cfg.min_visibility:
            flag(1, f"track visible to {vis:.0f} m only (< {cfg.min_visibility:.0f} m)")

        self._lock.append(bool(track.rail_score >= rails_min_score))
        lock = sum(self._lock) / len(self._lock)
        if len(self._lock) >= min(5, self._lock.maxlen) and lock < cfg.min_lock_rate:
            flag(1, f"rail pair found in {lock:.0%} of the last {len(self._lock)} frames: track model on its prior")

        if getattr(track, "floor_shadow", 0.0) > 0:
            self._shadow[0] += 1
            if track.floor_held:
                self._shadow[1] += 1
            elif getattr(track, "floor_hold_run", 0) > 0:
                self._shadow[2] += 1

        if latency_ms is not None:
            self._lat.append(float(latency_ms))
        p95 = float(np.percentile(self._lat, 95)) if self._lat else 0.0
        if len(self._lat) >= 10 and p95 > cfg.latency_budget_ms:
            flag(1, f"latency p95 {p95:.0f} ms over the {cfg.latency_budget_ms:.0f} ms budget",
                 decision=cfg.latency_affects_decision)

        orientation_confirmed = None
        if calibration:
            st = calibration.get("status")
            if calibration.get("orientation_conflict", False):
                flag(2, "mount orientation unconfirmed: " + calibration.get("message", "axis conflict"))
            # Orientation readiness is separate from the final tilt fit. An inverted
            # sensor can otherwise produce GO before the search adopts a valid map.
            # Legacy external status dictionaries have no readiness field; completed
            # or provisional fits imply an observed map, while pending/fallback do not.
            orientation_confirmed = calibration.get(
                "orientation_confirmed", st in ("ok", "identity", "provisional", "disabled")) is True
            if not orientation_confirmed:
                flag(1, "sensor orientation unconfirmed: waiting for a supported axis mapping")
            if st == "fallback":
                flag(1, "mount calibration: " + calibration.get("message", "fallback"))
            if calibration.get("drift_deg", 0.0) > 0 and "drift" in calibration.get("message", ""):
                flag(1, calibration["message"])

        monitored = float(max(0.0, min(vis, trusted_range, gauge.range_max)))
        if wall_drift is not None:              # 15.10: the corridor beyond is not where the track is
            monitored = float(max(0.0, min(monitored, wall_drift)))
        if level >= 2 or orientation_confirmed is False:
            monitored = 0.0                     # input fault or unconfirmed coordinates: no range is verified
        clear = monitored if obstacle_distance is None else float(min(obstacle_distance, monitored))
        if candidate_distance is not None:     # clear_cap (25.09): an unconfirmed / advisory object in the envelope
            clear = float(max(0.0, min(clear, candidate_distance)))
        out = {
            "level": LEVELS[level], "decision_level": LEVELS[dlevel], "messages": msgs,
            "points": n, "near_fraction": round(near_frac, 3), "blocked_sectors": blocked,
            "visibility": round(vis, 1), "rail_lock": round(lock, 2), "latency_p95_ms": round(p95, 1),
            "monitored_range": round(monitored, 1), "clear_distance": round(clear, 1),
            "floor_shadow_frames": self._shadow[0], "floor_held_frames": self._shadow[1],
            "floor_released_frames": self._shadow[2],
        }
        if cfg.clear_cap:
            out["candidate_distance"] = None if candidate_distance is None else round(float(candidate_distance), 1)
        if wall_drift is not None:
            out["wall_drift"] = round(float(wall_drift), 1)
        if orientation_confirmed is not None:
            out["orientation_confirmed"] = orientation_confirmed
        return out
