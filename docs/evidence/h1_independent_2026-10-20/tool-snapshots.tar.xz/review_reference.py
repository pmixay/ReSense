#!/usr/bin/env python3
"""Read-only independent H1 reference audit; never imports/runs the detector.

Only --out is written, exclusively, in this evidence directory. Archived inputs
are read directly from the existing portable evidence archive, not re-created.
Exit 0 means the review completed, NOT that H1 or its reference passed.
"""
from __future__ import annotations

import argparse
import collections
import copy
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
import numpy as np
import yaml
from rosbags.typesys import Stores, get_typestore


EVIDENCE_NAME = 'h1_independent_2026-10-20'
A = 'roundT_squareT_pressureGate_squareT'
C = 'roundT_pressureGate_roundT'
EXPECTED_FAILURES = {
    'seed_disagreement': 4, 'reverse_translation': 24,
    'reverse_rotation': 7, 'fitness': 1,
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def signature(path):
    s = path.stat()
    return (s.st_size, s.st_mtime_ns, s.st_dev, s.st_ino)


class Inputs:
    def __init__(self):
        self.files = {}
        self.members = []

    def add(self, path):
        path = path.resolve()
        key = str(path)
        if key not in self.files:
            before = signature(path)
            sha = file_digest(path)
            require(signature(path) == before, f'Input changed while hashing: {path}')
            self.files[key] = dict(path=key, bytes=before[0], sha256=sha,
                                   signature=list(before))
        return self.files[key]

    def json(self, path):
        self.add(path)
        return json.loads(path.read_text(encoding='utf-8'))

    def unchanged(self):
        for item in self.files.values():
            require(list(signature(Path(item['path']))) == item['signature'],
                    f'Input changed during audit: {item["path"]}')
        return True


class Archive:
    def __init__(self, path, inputs, prior_directory):
        inputs.add(path)
        self.path, self.inputs, self.prior_directory = path, inputs, prior_directory
        self.tar = tarfile.open(path, 'r:gz')

    def json(self, name):
        stream = self.tar.extractfile(name)
        require(stream is not None, f'Archive member missing: {name}')
        with stream:
            data = stream.read()
        item = dict(archive=str(self.path), member=name, bytes=len(data), sha256=digest(data))
        prior = self.prior_directory / name
        if prior.is_file():
            old = self.inputs.add(prior)
            require(old['sha256'] == item['sha256'], f'Archive/prior mismatch: {name}')
            item['equals_prior_session_input'] = True
        self.inputs.members.append(item)
        return json.loads(data)


def git(repo, *args, binary=False):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', '-C', str(repo), *args], env=env,
                                   text=not binary)


def source_snapshot(repo):
    head = git(repo, 'rev-parse', 'HEAD').strip()
    names = set(filter(None, git(repo, 'ls-files', '-z', '--', 'resense', 'native', 'configs',
                                'ros2_ws', 'setup.py', 'pyproject.toml').split('\0')))
    # The integrity seal also covers build inputs outside these source roots.
    freeze = json.loads((repo / 'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json')
                        .read_text(encoding='utf-8'))
    names.update(freeze['files'])
    files = {}
    for name in sorted(names):
        actual = file_digest(repo / name)
        committed = digest(git(repo, 'show', f'{head}:{name}', binary=True))
        files[name] = dict(sha256=actual, head_sha256=committed,
                           equals_head=actual == committed)
    index = Path(git(repo, 'rev-parse', '--git-path', 'index').strip())
    if not index.is_absolute():
        index = repo / index
    return dict(head=head, tracked_status=git(repo, 'status', '--porcelain',
                '--untracked-files=no'), index_sha256=file_digest(index),
                production_files=files, file_count=len(files),
                all_production_files_equal_head=all(v['equals_head'] for v in files.values()))


def inventory(vm, inputs):
    bags = [(vm / 'resense-b4-data/for_hackathon' / n / f'{n}_0.db3') for n in
            ['doubleT_obstacle', 'doubleT_platform', 'roundT_doubleT', C, A,
             'squareT_platform_squareT_switch']]
    bags += [vm / 'resense-b4-data/cloud_with_fake_obj/cloud_with_fake_obj_0.db3',
             vm / 'l16-s3/falcon_test_second_dark/falcon_test_second_dark_0.db3']
    bags += [vm / 'yadisk-markers-2026-10-19/extracted' / n / f'{n}_0.db3' for n in
             ['synthetic_platform_cloud_with_markers', 'synthetic_switch_cloud_with_markers',
              'synthetic_tunnels_cloud_with_markers']]
    rows = []
    for path in bags:
        receipt = inputs.add(path)
        with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as con:
            con.execute('PRAGMA query_only=ON')
            joined = con.execute('SELECT t.id,t.name,t.type,COUNT(m.id) FROM topics t '
                                 'LEFT JOIN messages m ON t.id=m.topic_id GROUP BY t.id').fetchall()
            groups = dict(con.execute('SELECT topic_id,COUNT(*) FROM messages GROUP BY topic_id'))
            total = con.execute('SELECT COUNT(*) FROM messages').fetchone()[0]
            orphan = con.execute('SELECT COUNT(*) FROM messages m LEFT JOIN topics t '
                                 'ON t.id=m.topic_id WHERE t.id IS NULL').fetchone()[0]
        require(total == sum(r[3] for r in joined) + orphan, f'Count mismatch: {path.name}')
        require(all(groups.get(r[0], 0) == r[3] for r in joined), 'Independent GROUP BY mismatch')
        clouds = sum(r[3] for r in joined if r[2] == 'sensor_msgs/msg/PointCloud2')
        require(clouds > 0 and orphan == 0, 'Cloud positive control/orphan check failed')
        meta_path = path.parent / 'metadata.yaml'
        inputs.add(meta_path)
        meta = yaml.safe_load(meta_path.read_text())['rosbag2_bagfile_information']
        meta_counts = {m['topic_metadata']['name']: m['message_count']
                       for m in meta['topics_with_message_count']}
        require(meta['message_count'] == total, 'Metadata total mismatch')
        require(meta_counts == {r[1]: r[3] for r in joined}, 'Metadata topic mismatch')
        topics = [dict(id=r[0], name=r[1], type=r[2], messages=r[3]) for r in joined]
        external = [r for r in topics if r['type'] not in {
            'sensor_msgs/msg/PointCloud2', 'visualization_msgs/msg/MarkerArray',
            'rcl_interfaces/msg/Log'} and r['messages'] > 0]
        require(not external, f'Unexpected non-cloud/marker/log input: {external}')
        rows.append(dict(bag=str(path), sha256=receipt['sha256'], total_messages=total,
                         orphan_messages=orphan, cloud_positive_control=clouds,
                         independent_group_by_equal=True, metadata_equal=True, topics=topics,
                         external_spatial_messages=external))
        print(f'INVENTORY {path.parent.name}: {total} messages; SHA-256 complete', flush=True)
    return dict(bags=rows, bag_count=len(rows), total_messages=sum(r['total_messages'] for r in rows),
                scope='Exactly the 11 named raw bags; no universal claim about unavailable files.',
                positive_control='Nonzero clouds in every bag; nonzero MarkerArray and rosout in same query.',
                excluded='The previously observed malformed ride-spool/new_data_215.db3 is not queried; '
                         'no absence claim is made about that split.')


def rotation_angle(matrix):
    # Independent of scipy Rotation: trace and antisymmetric part give cos/sin.
    v = np.array([matrix[2, 1] - matrix[1, 2], matrix[0, 2] - matrix[2, 0],
                  matrix[1, 0] - matrix[0, 1]]) / 2
    return float(np.degrees(np.arctan2(np.linalg.norm(v), (np.trace(matrix) - 1) / 2)))


def gate(row, point=None):
    a, b, r = [np.asarray(row[k]['T'], dtype=float) for k in ['primary', 'alternate', 'reverse']]
    point = np.asarray(row['near_point'] if point is None else point, dtype=float)
    cycle = a @ r
    values = dict(projected_disagreement_m=float(np.linalg.norm(((a - b) @ point)[:3])),
                  reverse_translation_m=float(np.linalg.norm(cycle[:3, 3])),
                  reverse_rotation_deg=rotation_angle(cycle[:3, :3]),
                  min_fitness=min(row[k]['stages'][-1]['fitness']
                                  for k in ['primary', 'alternate', 'reverse']))
    failures = [('seed_disagreement', values['projected_disagreement_m'] > .1),
                ('reverse_translation', values['reverse_translation_m'] > .1),
                ('reverse_rotation', values['reverse_rotation_deg'] > .05),
                ('fitness', values['min_fitness'] < .7)]
    values['first_failed_condition_recomputed'] = next((k for k, bad in failures if bad), None)
    values['consistent'] = not any(bad for _, bad in failures)
    return values


def review_gates(archive):
    data = archive.json('direct-gicp-regularized-all.json')
    rows, counts, keys = [], collections.Counter(), set()
    for i, row in enumerate(data['rows']):
        key = (row['sequence'], row['frame'], row['future_frame'], row['station'])
        require(key not in keys, 'Repeated direct-comparison row')
        keys.add(key)
        result = gate(row)
        require(result['consistent'] == row['consistent'], f'Gate bit mismatch: {key}')
        for field in ['projected_disagreement_m', 'reverse_translation_m',
                      'reverse_rotation_deg', 'min_fitness']:
            require(abs(result[field] - row[field]) < 1e-6, f'Metric mismatch: {key}/{field}')
        counts[result['first_failed_condition_recomputed'] or 'PASS'] += 1
        rows.append(dict(row=i, sequence=key[0], frame=key[1], future_frame=key[2],
                         nominal_station_m=key[3], **result))
    require(len(rows) == 36 and dict(counts) == EXPECTED_FAILURES, 'Prior 36-row result differs')
    control = archive.json('validation-reconstruction.json')['controls']
    point = [15., 0., -1., 1.]
    positive = gate(control, point)
    require(positive['consistent'], 'Known-transform positive validator control failed')
    error = np.linalg.inv(np.asarray(control['truth'])) @ np.asarray(control['primary']['T'])
    truth_error = dict(translation_m=float(np.linalg.norm(error[:3, 3])),
                       rotation_deg=rotation_angle(error[:3, :3]))
    require(truth_error['translation_m'] < .02 and truth_error['rotation_deg'] < .01,
            'Saved manufactured transform does not match known truth')
    planted = {}
    for name in EXPECTED_FAILURES:
        bad = copy.deepcopy(control)
        if name == 'seed_disagreement':
            bad['alternate']['T'][1][3] += .5
        elif name == 'reverse_translation':
            bad['reverse']['T'][1][3] += .5
        elif name == 'reverse_rotation':
            t = np.asarray(bad['reverse']['T']); x = np.radians(1.)
            rot = np.array([[np.cos(x), -np.sin(x), 0], [np.sin(x), np.cos(x), 0], [0, 0, 1]])
            t[:3, :3] = t[:3, :3] @ rot
            bad['reverse']['T'] = t.tolist()
        else:
            bad['primary']['stages'][-1]['fitness'] = .1
        result = gate(bad, point)
        require(result['first_failed_condition_recomputed'] == name, f'Planted {name} not detected')
        planted[name] = result
    return dict(rows=rows, pass_count=sum(r['consistent'] for r in rows),
                first_failed_condition_counts=dict(counts), positive_control=positive,
                manufactured_truth_error=truth_error, planted_controls=planted,
                method='Recomputed from saved matrices; no registration was run. Ordered failures '
                       'are recomputed conditions, not a newly captured execution trace.',
                limits='Closure/seed agreement is not an independently calibrated absolute pose bound; '
                       'station labels are nominal selections from rejected trajectories.')


def review_landmarks(archive, direct_rows):
    summaries = {}
    for seq in ['A', 'C']:
        data = archive.json(f'landmark-tracks-{seq}.json')
        solution = archive.json(f'landmark-bundle-{seq}-converged.json')
        poses = np.asarray([r['pose'] for r in solution['rows']])
        saved = {r['id']: r for r in solution['validation']}
        validation, by_frame = [], collections.defaultdict(dict)
        centroids_checked, max_error = 0, 0.
        for index, track in enumerate(data['retained']):
            require(track['validation_only'] == (index % 5 == 0), 'Validation split changed')
            observations = track['observations']
            for obs in observations:
                error = float(np.linalg.norm(np.mean(obs['points'], axis=0) - obs['center']))
                max_error = max(max_error, error)
                require(error < 1e-12, 'Saved centroid is not the mean of its raw support')
                centroids_checked += 1
                by_frame[obs['frame']][track['id']] = np.asarray(obs['center'])
            if not track['validation_only']:
                continue
            world = np.asarray([poses[o['frame'], :3, :3] @ np.asarray(o['center'])
                                + poses[o['frame'], :3, 3] for o in observations])
            anchor = np.median(world[:min(5, len(world))], axis=0)
            residuals = np.linalg.norm(world - anchor, axis=1)
            percentiles = np.percentile(residuals, [50, 95, 100])
            require(np.max(np.abs(percentiles - saved[track['id']]['after']
                                  ['residual_p50_p95_max'])) < 1e-12,
                    'Withheld-track residual recomputation differs')
            validation.append(dict(track_id=track['id'], frames=[o['frame'] for o in observations],
                                   observation_count=len(observations), anchor=anchor.tolist(),
                                   residual_p50_p95_max_m=percentiles.tolist(),
                                   residuals_m=residuals.tolist(), p95_le_0_10_m=bool(percentiles[1] <= .1)))
        shared = []
        for row in direct_rows:
            if row['sequence'] == seq and row['nominal_station_m'] >= 100:
                ids = sorted(by_frame[row['frame']].keys() & by_frame[row['future_frame']].keys())
                shared.append(dict(frame=row['frame'], future_frame=row['future_frame'],
                                   nominal_station_m=row['nominal_station_m'], common_track_ids=ids))
        positives = [(f, f + 1, len(by_frame[f].keys() & by_frame[f + 1].keys()))
                     for f in sorted(list(by_frame)) if f + 1 in by_frame
                     and len(by_frame[f].keys() & by_frame[f + 1].keys()) >= 4]
        require(positives, 'Shared-track search positive control failed')
        f, g, ids = (185, 235, [552, 570]) if seq == 'A' else (0, 1, [11, 12])
        distance0 = float(np.linalg.norm(by_frame[f][ids[0]] - by_frame[f][ids[1]]))
        distance1 = float(np.linalg.norm(by_frame[g][ids[0]] - by_frame[g][ids[1]]))
        q = np.asarray(list(by_frame[f].values())); theta = .02
        rot = np.array([[np.cos(theta), -np.sin(theta), 0],
                        [np.sin(theta), np.cos(theta), 0], [0, 0, 1]])
        moved = q @ rot.T + [80., .2, .05]
        distances = np.linalg.norm(q[:, None] - q[None, :], axis=2)
        moved_distances = np.linalg.norm(moved[:, None] - moved[None, :], axis=2)
        invariant_error = float(np.max(np.abs(distances - moved_distances)))
        moved[0] += [0, .5, 0]
        planted_error = float(np.max(np.abs(distances - np.linalg.norm(
            moved[:, None] - moved[None, :], axis=2))))
        require(invariant_error < 1e-10 and planted_error > .01, 'Rigid-invariant control failed')
        summaries[seq] = dict(training_tracks=sum(not t['validation_only'] for t in data['retained']),
            validation_tracks=len(validation), validation_observations=sum(v['observation_count'] for v in validation),
            tracks_p95_le_0_10_m=sum(v['p95_le_0_10_m'] for v in validation),
            maximum_track_p95_m=max(v['residual_p50_p95_max_m'][1] for v in validation),
            validation=validation, centroids_recomputed=centroids_checked, maximum_centroid_error_m=max_error,
            far_pair_shared_tracks=shared, adjacent_pairs_with_at_least_four_tracks=len(positives),
            shared_search_positive_examples=positives[:3],
            pose_invariant_example=dict(frames=[f, g], track_ids=ids, first_distance_m=distance0,
                second_distance_m=distance1, absolute_change_m=abs(distance1 - distance0)),
            rigid_80m_control_max_distance_error_m=invariant_error,
            planted_nonrigid_control_max_distance_change_m=planted_error)
    require(sum(s['validation_observations'] for s in summaries.values()) == 1185,
            'Validation observation scope differs from prior check')
    return dict(sequences=summaries, limits='These are combined association/centroid/pose errors, '
                'not a measured pure pose-error distribution. Raw observations are not deskewed. '
                'Shared-track absence applies only to the retained tracks and 24 specified pairs.')


def cache_path(vm, seq, frame):
    root = vm / ('r3-h1/baseline/cache' if seq == 'A' else 'r3-h1/supplement-range/decoded')
    return root / (A if seq == 'A' else C) / f'f_{frame:05d}.npz'


def vehicle_xyz(raw):
    # Explicit fixed sensor-axis permutation, not detector calibration or axis.
    return raw.astype(np.float64)[:, [1, 0, 2]] * [-1., 1., 1.]


def slice_points(xyz, station, low=-3., high=-.4):
    keep = ((np.abs(xyz[:, 0] - station) < 4) & (np.abs(xyz[:, 1]) < 7)
            & (xyz[:, 2] > low) & (xyz[:, 2] < high))
    return np.unique(xyz[keep], axis=0)


def reflector(xyz, intensity):
    keep = ((intensity >= 100) & (xyz[:, 0] > 40) & (xyz[:, 0] < 50)
            & (xyz[:, 1] > -2.5) & (xyz[:, 1] < -1.8))
    return np.unique(xyz[keep], axis=0)


def review_raw(vm, inputs, archive):
    store = get_typestore(Stores.ROS2_HUMBLE)
    archived_slices = {(r['sequence'], r['frame'], r['station']): r
                       for r in archive.json('raw-near-far-rails.json')}
    saved_reflector = archive.json('validation-reconstruction.json')['landmark_check']
    frames, slices, reflectors = [], [], []
    for seq, frame in [('A', 0), ('A', 1), ('A', 135), ('C', 55)]:
        name = A if seq == 'A' else C
        path = vm / 'resense-b4-data/for_hackathon' / name / f'{name}_0.db3'
        inputs.add(path)
        with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as con:
            con.execute('PRAGMA query_only=ON')
            rows = con.execute("SELECT m.id,m.timestamp,m.data FROM messages m JOIN topics t "
                               "ON m.topic_id=t.id WHERE t.type='sensor_msgs/msg/PointCloud2' "
                               'ORDER BY m.timestamp,m.id LIMIT 1 OFFSET ?', (frame,)).fetchall()
        require(len(rows) == 1, 'Missing raw frame')
        mid, timestamp, blob = rows[0]
        msg = store.deserialize_cdr(blob, 'sensor_msgs/msg/PointCloud2')
        formats = {1: 'i1', 2: 'u1', 3: 'i2', 4: 'u2', 5: 'i4', 6: 'u4', 7: 'f4', 8: 'f8'}
        require(all(f.count == 1 for f in msg.fields), 'Unexpected array field')
        endian = '>' if msg.is_bigendian else '<'
        dtype = np.dtype(dict(names=[f.name for f in msg.fields],
                              formats=[endian + formats[f.datatype] for f in msg.fields],
                              offsets=[f.offset for f in msg.fields], itemsize=msg.point_step))
        records = np.ndarray((msg.height, msg.width), dtype=dtype, buffer=msg.data,
                             strides=(msg.row_step, msg.point_step)).reshape(-1)
        raw = np.column_stack([records[k] for k in ['x', 'y', 'z']])
        squared = raw[:, 0] ** 2
        squared += raw[:, 1] ** 2
        squared += raw[:, 2] ** 2
        keep = np.isfinite(squared) & (squared >= 2.5 ** 2) & (squared <= 250. ** 2)
        cached = cache_path(vm, seq, frame)
        inputs.add(cached)
        with np.load(cached, allow_pickle=False) as cache:
            equal = np.array_equal(raw[keep], cache['xyz'])
            require(equal, 'Independent raw/cache XYZ alignment failed')
        xyz = vehicle_xyz(raw[keep])
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        offsets = records['timestamp'][keep] - stamp
        frames.append(dict(sequence=seq, frame=frame, message_id=mid, bag_timestamp_ns=timestamp,
            raw_message_sha256=digest(blob), frame_id=msg.header.frame_id,
            fields=[dict(name=f.name, offset=f.offset, datatype=f.datatype, count=f.count) for f in msg.fields],
            raw_points=len(raw), cropped_points=int(keep.sum()), cached_xyz_exact_equal=equal,
            point_time_offset_min_max_s=[float(offsets.min()), float(offsets.max())]))
        if frame in [135, 55]:
            for station in [15., 30., 60., 90., 120., 150.]:
                q = slice_points(xyz, station)
                require(len(q) == archived_slices[seq, frame, station]['raw_distinct_points'],
                        'Raw CDR/archive slice count mismatch')
                slices.append(dict(sequence=seq, frame=frame, station_m=station, distinct_returns=len(q),
                                   sample_xyz=q.tolist() if station >= 120 else q[::max(1, len(q)//6)].tolist()))
        if seq == 'A' and frame in [0, 1]:
            intensity = records['intensity'][keep]
            q = reflector(xyz, intensity)
            require(len(q) > 0, 'Raw reflector positive control missing')
            shifted_count = len(reflector(xyz + [10000., 10000., 10000.], intensity))
            require(shifted_count == 0, 'Shifted reflector negative control failed')
            saved = saved_reflector['rows'][frame]['cluster']
            require(np.array_equal(q, np.asarray(saved['points'])), 'Raw reflector/archive support mismatch')
            reflectors.append(dict(frame=frame, distinct_returns=len(q), centroid=q.mean(axis=0).tolist(),
                                   extent=np.ptp(q, axis=0).tolist(), points=q.tolist(),
                                   shifted_10km_control_selected=shifted_count))
    delta = np.asarray(reflectors[0]['centroid']) - np.asarray(reflectors[1]['centroid'])
    require(np.max(np.abs(delta - saved_reflector['raw_centroid_displacement'])) < 1e-12,
            'Independent raw reflector displacement mismatch')
    require(next(r['distinct_returns'] for r in slices if r['sequence'] == 'A' and r['station_m'] == 15) > 0,
            'Same-path near slice positive control missing')
    broad = []
    for seq, frame in [('A', 135), ('A', 230), ('A', 248), ('A', 256),
                       ('C', 0), ('C', 50), ('C', 55), ('C', 75)]:
        path = cache_path(vm, seq, frame)
        inputs.add(path)
        with np.load(path, allow_pickle=False) as cache:
            xyz = vehicle_xyz(cache['xyz'])
        for station in [100., 120., 140., 150.]:
            narrow = slice_points(xyz, station)
            wide = slice_points(xyz, station, -8., 1.)
            require(len(wide) >= len(narrow), 'Wider Z crop lost points')
            broad.append(dict(sequence=seq, frame=frame, station_m=station,
                              original_z_count=len(narrow), wide_z_count=len(wide)))
    return dict(frames=frames, raw_reflector=reflectors, raw_reflector_displacement_m=delta.tolist(),
                original_slices=slices, wider_z_slices=broad,
                interpretation='The raw reflector supports the longitudinal 1.34 m mode, not full SE3 truth. '
                'Slices count returns, not rail heads. Wider Z changes support, not rail identity.',
                corrected_preflight='The earlier independent finite-only crop was incorrect; the decoder '
                'now reproduces the inclusive 2.5 <= range <= 250 m crop and checks all four raw frames.')


def historical_misses(archive):
    probe = archive.json('probes-merged-candidate/A-axis.json')
    visible = [r for r in probe['rows'] if r['n_obj'] > 0 and r['X'] is not None and r['X'] > 3]
    misses = [r for r in visible if not r['hit']]
    far = [r for r in visible if 100 <= r['X'] < 150]
    require((len(visible), sum(r['hit'] for r in visible), len(misses)) == (177, 114, 63),
            'Historical A-axis counts differ from prior check')
    return dict(fresh_current_replay=False, provenance='Archived merged H1 probe, measured 0f02b28; '
                'historical retained E evidence at 7d0f571. NOT a measurement of current HEAD.',
                total_rows=len(probe['rows']), visible_rows=len(visible), matched_visible_rows=114,
                misses=len(misses), miss_decisions=dict(collections.Counter(r['decision'] for r in misses)),
                miss_rows=[dict(frame=r['k'], nominal_X_m=r['X'], decision=r['decision'],
                                injected_returns=r['n_obj']) for r in misses],
                nominal_100_150_m=dict(visible=len(far), matched=sum(r['hit'] for r in far)),
                limits='Axis-aligned injection is not independent rail truth; no causal labels or '
                       'new wrong-selected-pair/no-rails acceptance are inferred.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument('--vm-root', type=Path, default=Path('/tmp/opencode'))
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo, vm, output = args.repo.resolve(), args.vm_root.resolve(), args.out.resolve()
    require(output.parent == repo / 'docs/evidence' / EVIDENCE_NAME,
            'Only a new report in this evidence directory may be written')
    require(output.parent.is_dir() and not output.exists(), 'Output parent missing or report already exists')
    require(os.environ.get('RESENSE_REPO') == str(repo), 'Set RESENSE_REPO to the audited checkout')
    require(os.environ.get('OPENBLAS_CORETYPE') == 'Haswell' and os.environ.get('OMP_NUM_THREADS') == '1',
            'Required P4 environment is missing')
    started = time.monotonic()
    before = source_snapshot(repo)
    require(before['tracked_status'] == '' and before['all_production_files_equal_head'],
            'Production source must be an identified clean committed tree')
    inputs = Inputs()
    inputs.add(Path(__file__))
    for relative in ['CLAUDE.md', 'docs/BACKLOG.md', 'docs/DETECTOR_FREEZE.md',
                     'docs/evidence/h1_reference_2026-10-19/README.md',
                     'docs/evidence/h1_reference_2026-10-19/PROTOCOL.md',
                     'docs/evidence/h1_trajectory_2026-10-19/README.md',
                     'docs/evidence/h1_trajectory_2026-10-19/LANDMARK_BUNDLE.md',
                     'docs/evidence/h1_trajectory_2026-10-19/REFERENCE_AMENDMENT.md',
                     'docs/evidence/organizer_markers_2026-10-19/README.md',
                     'docs/organizers/answers.md', 'docs/SENSOR.md']:
        inputs.add(repo / relative)
    freeze = inputs.json(repo / 'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json')
    frozen_match = all(before['production_files'][p]['sha256'] == sha for p, sha in freeze['files'].items())
    require(frozen_match, 'Current frozen production source bytes differ')
    archive = Archive(repo / 'docs/evidence/h1_trajectory_2026-10-19/raw-evidence.tar.gz',
                      inputs, vm / 'h1-trajectory')
    topics = inventory(vm, inputs)
    direct = review_gates(archive)
    landmarks = review_landmarks(archive, direct['rows'])
    raw = review_raw(vm, inputs, archive)
    historical = historical_misses(archive)
    archive.tar.close()
    after = source_snapshot(repo)
    require(before == after, 'Git HEAD/index/tracked source changed during this audit')
    inputs.unchanged()
    report = dict(schema='resense-h1-independent-reference-review-v1', verdict='BLOCKED',
        verification_completed=True, h1_closed=False, generated_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        runtime=dict(python=sys.version, platform=platform.platform(), executable=sys.executable,
                     numpy=np.__version__, rosbags=importlib.metadata.version('rosbags'),
                     yaml=importlib.metadata.version('PyYAML'), elapsed_s=time.monotonic() - started,
                     environment={k: os.environ.get(k) for k in ['RESENSE_REPO', 'OPENBLAS_CORETYPE',
                     'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'PYTHONDONTWRITEBYTECODE']}),
        current_git_source=before, source_and_index_unchanged=True,
        frozen_source_bytes=dict(manifest='docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json',
                                 files=len(freeze['files']), match=frozen_match,
                                 scope='Byte identity only; not a fresh gate or final-bundle acceptance.'),
        inputs=dict(files=list(inputs.files.values()), archive_members=inputs.members,
                    stat_signatures_unchanged=True,
                    hashing='Full SHA-256 of every named file, including all 11 complete databases. '
                            'File size/mtime/device/inode checked again after all computations.'),
        topic_inventory=topics, direct_validation=direct, landmark_validation=landmarks,
        raw_checks=raw, historical_a_axis=historical,
        prior_independent_crosscheck=dict(
            method='Before this script existed, independent SSH reads used raw SQLite GROUP BY and metadata, '
                   'raw CDR decoding, rotation-trace matrix checks and direct withheld-observation residuals. '
                   'This run additionally compares portable archive members byte-for-byte to those retained inputs.',
            expected_direct_failures=EXPECTED_FAILURES,
            expected_validation=dict(A=dict(tracks=28, observations=685, p95_pass=13),
                                     C=dict(tracks=27, observations=500, p95_pass=16)),
            raw_decoder_separate_from_prior_detector_fastcloud=True),
        minimal_missing_input='Independently checked left/right rail-head geometry in identified A/C frames '
            'at 100-150 m, with support, correct path identity and quantified uncertainty; or synchronized '
            'independently validated relative SE3 poses/extrinsics/error budget plus independently checked '
            'later near-rail observations. Reconstruction is not surveyed truth.',
        alternatives=dict(new_method='Explicit fixed physical corner/joint correspondences, closed-form '
            'rigid solve (not ICP), >=3 non-collinear anchors plus excluded independent anchors, '
            'conditioning, acquisition-time and measurement-error checks before transferring near rails.',
            current_feasibility='Retained features do not supply a full-pose anchor set in the 24 '
            'specified nominal far pairs. This does not prove all manual raw-data methods impossible.',
            orientation_budget_example=dict(range_m=150, allocated_error_m=.1,
                angle_deg=float(np.degrees(np.arctan(.1/150))),
                displacement_at_0_05_deg_m=float(150*np.tan(np.radians(.05))))),
        limits=['No detector replay, instrumentation, production import, optimization, release action or held-out run.',
                'The reported 63 misses are historical archived results, not fresh current-main findings.',
                'Wrong-selected-pair and current replay are outside this review; no acceptance is inferred.',
                'Live public listing and archive-inventory checks from the preceding read-only session are '
                'documented in README, not claimed to have been repeated by this offline script.'])
    with output.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(verdict=report['verdict'], verification_completed=True,
        current_head=before['head'], raw_bags=topics['bag_count'], direct_pass=direct['pass_count'],
        validation_observations=sum(v['validation_observations'] for v in landmarks['sequences'].values()),
        historical_misses=historical['misses'], report=str(output), report_sha256=file_digest(output))))


if __name__ == '__main__':
    main()
