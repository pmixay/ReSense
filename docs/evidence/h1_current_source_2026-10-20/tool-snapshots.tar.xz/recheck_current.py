#!/usr/bin/env python3
"""Pinned 520e7dc H1 delta review; no detector edits, tracer, gate or Git writes.

Reads old evidence/captures; runs only the pinned worktree detector. Writes new
exclusive artifacts in this evidence directory and its named scratch directory.
The sole authorized runtime installation is copying the verified identical .so.
"""
from __future__ import annotations
import argparse
import ast
import collections
import copy
import dataclasses as dc
import datetime as dt
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import shutil
import struct
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
import numpy as np

ROOT = Path('/tmp/opencode/h1-reviewed-publication')
HERE = ROOT/'docs/evidence/h1_current_source_2026-10-20'
WORK = Path('/tmp/opencode/h1-final-review/current520')
OLD_ROOT = Path('/home/aiops/resense')
OLD = OLD_ROOT/'docs/evidence'
RAIL = OLD/'h1_rail_limits_2026-10-20'
MISS = OLD/'h1_miss_audit_2026-10-20'
OLD_WORK = Path('/tmp/opencode/h1-miss-audit')
CACHE = Path('/tmp/opencode/r3-h1/baseline/cache/roundT_squareT_pressureGate_squareT')
ICP = Path('/tmp/opencode/r3-h1/baseline/icp_roundT_squareT_pressureGate_squareT.json')
BASE = Path(str(CACHE)+'_baseline.json')
HEAD = '520e7dcd2843a0e7c9055fca6c186c0d1687945f'
PREVIOUS = 'f56ad5e62d9d051811c804734c7731b6951eae90'
INPUTS = {}


def need(ok, message):
    if not ok: raise AssertionError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()


def record(path):
    p=Path(path).resolve(); s=p.stat()
    item=dict(bytes=s.st_size,sha256=sha(p),stat=[s.st_size,s.st_mtime_ns,s.st_ino])
    if str(p) in INPUTS: need(INPUTS[str(p)]==item,('input changed',str(p)))
    INPUTS[str(p)]=item
    return item


def load(path): record(path); return json.loads(Path(path).read_text())


def git(*args,binary=False):
    return subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),*args],text=not binary,
                                   env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))


def raw(v):
    if dc.is_dataclass(v): return {f.name:raw(getattr(v,f.name)) for f in dc.fields(v) if f.name!='timing_ms'}
    if isinstance(v,dict): return {k:raw(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return type(v)(raw(x) for x in v)
    return v


def fp(v):
    if dc.is_dataclass(v): return {f.name:fp(getattr(v,f.name)) for f in dc.fields(v)}
    if isinstance(v,np.ndarray): return dict(dtype=v.dtype.str,shape=list(v.shape),sha256=hashlib.sha256(v.tobytes()).hexdigest())
    if isinstance(v,np.generic): return fp(np.asarray(v))
    if isinstance(v,float): return dict(f64=struct.pack('>d',v).hex())
    if isinstance(v,dict): return {str(k):fp(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return [fp(x) for x in v]
    return v


def exact(a,b):
    if type(a) is not type(b): return False
    if isinstance(a,np.ndarray): return a.dtype.str==b.dtype.str and a.shape==b.shape and a.tobytes()==b.tobytes()
    if isinstance(a,np.generic): return a.dtype.str==b.dtype.str and a.tobytes()==b.tobytes()
    if isinstance(a,float): return struct.pack('>d',a)==struct.pack('>d',b)
    if isinstance(a,dict): return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
    if isinstance(a,(tuple,list)): return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
    return a==b


def canonical(v):
    """Canonical IEEE format used by the immutable publication capture receipts."""
    h=hashlib.sha256()
    def push(tag,b): h.update(tag+struct.pack('<Q',len(b))+b)
    def walk(x):
        if isinstance(x,np.ndarray): push(b'array',str((x.dtype.str,x.shape)).encode()); push(b'bytes',x.tobytes())
        elif isinstance(x,np.generic): push(b'np',x.dtype.str.encode()+x.tobytes())
        elif isinstance(x,float): push(b'f64',struct.pack('<d',x))
        elif isinstance(x,dict):
            push(b'dict',str(len(x)).encode())
            for k in sorted(x): walk(k); walk(x[k])
        elif isinstance(x,(tuple,list)):
            push(b'tuple' if isinstance(x,tuple) else b'list',str(len(x)).encode())
            for z in x: walk(z)
        else: push(type(x).__name__.encode(),repr(x).encode())
    walk(v); return h.hexdigest()


def injection_hash(v):
    """Original typed input-digest format; does not import the old audit driver."""
    h=hashlib.sha256()
    def atom(tag,b): h.update(tag+struct.pack('>Q',len(b))+b)
    def walk(x):
        if isinstance(x,np.ndarray): atom(b'A',str(x.dtype).encode()); walk(x.shape); atom(b'B',x.tobytes(order='C'))
        elif isinstance(x,np.generic): atom(b'N',str(x.dtype).encode()+b':'+x.tobytes())
        elif isinstance(x,dict):
            atom(b'D',str(len(x)).encode())
            for k in sorted(x): walk(k); walk(x[k])
        elif isinstance(x,(tuple,list)):
            atom(b'T' if isinstance(x,tuple) else b'L',str(len(x)).encode())
            for y in x: walk(y)
        else: atom(type(x).__name__.encode()+b':',repr(x).encode())
    walk(v); return h.hexdigest()


def jsonable(v):
    if isinstance(v,np.ndarray): return v.tolist()
    if isinstance(v,np.generic): return jsonable(v.item())
    if isinstance(v,float) and not math.isfinite(v): return dict(f64=struct.pack('>d',v).hex())
    if isinstance(v,dict): return {str(k):jsonable(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return [jsonable(x) for x in v]
    return v


def save(path,v):
    p=Path(path).resolve(); need(p.is_relative_to(HERE) or p.is_relative_to(WORK),('write scope',str(p)))
    with p.open('x') as f: json.dump(jsonable(v),f,indent=2,allow_nan=False); f.write('\n')
    need(p.stat().st_size<20_000_000,('portable JSON too large',str(p)))


def difference(a,b,path='result'):
    """Enumerate every changed leaf/array; no early exit or hidden top-level fields."""
    if exact(a,b): return []
    if type(a) is type(b) and isinstance(a,dict):
        out=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b: out.append(dict(path=path+'.'+str(k),kind='key',old_present=k in a,current_present=k in b))
            else: out.extend(difference(a[k],b[k],path+'.'+str(k)))
        return out
    if type(a) is type(b) and isinstance(a,(tuple,list)):
        out=[]
        if len(a)!=len(b): out.append(dict(path=path,kind='length',old=len(a),current=len(b)))
        for i in range(min(len(a),len(b))): out.extend(difference(a[i],b[i],f'{path}[{i}]'))
        # All added/removed entries are represented individually, not silently dropped.
        for i in range(min(len(a),len(b)),max(len(a),len(b))):
            out.append(dict(path=f'{path}[{i}]',kind='added_removed_entry',old=None if i>=len(a) else summary(a[i]),current=None if i>=len(b) else summary(b[i])))
        return out
    return [dict(path=path,kind='value_or_type_or_array_bytes',old=summary(a),current=summary(b))]


def summary(v):
    if isinstance(v,np.ndarray): return fp(v)
    if isinstance(v,np.generic): return dict(numpy_dtype=v.dtype.str,bytes=v.tobytes().hex())
    if isinstance(v,float): return dict(value=v if math.isfinite(v) else repr(v),f64=struct.pack('>d',v).hex())
    if isinstance(v,(dict,list,tuple)): return dict(type=type(v).__name__,length=len(v),canonical_sha256=canonical(v))
    return v


def stream(path):
    with gzip.open(path,'rb') as f:
        while True:
            try: yield pickle.load(f)
            except EOFError: return


def match(detections,x,y,longitudinal=None,lateral=1.15):
    w=max(2.,.03*x)+.15 if longitudinal is None else longitudinal
    return [i for i,d in enumerate(detections) if x-w<=float(d['distance'])<=x+w and y-lateral<=float(d['center'][1])<=y+lateral]


def match_second(detections,x,y,longitudinal=None,lateral=1.15):
    w=max(2.,.03*x)+.15 if longitudinal is None else longitudinal
    return [i for i,d in enumerate(detections) if abs(float(d['distance'])-x)<=w and abs(float(d['center'][1])-y)<=lateral]


def default_seal():
    tree=ast.parse((ROOT/'scripts/detector_freeze.py').read_text())
    return next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
                and any(isinstance(t,ast.Name) and t.id=='DEFAULT_MANIFEST' for t in n.targets))


def snapshot(seal):
    names=set(seal['files'])|set(git('ls-files','resense','native','configs','ros2_ws','setup.py','pyproject.toml').splitlines())
    files={n:sha(ROOT/n) for n in sorted(names)}
    for n,h in files.items(): need(hashlib.sha256(git('show',f'{HEAD}:{n}',binary=True)).hexdigest()==h,('source differs from pinned HEAD',n))
    index=Path(git('rev-parse','--git-path','index').strip())
    if not index.is_absolute(): index=ROOT/index
    return dict(head=git('rev-parse','HEAD').strip(),files=files,index_sha256=sha(index),index_path=str(index))


def prepare():
    need(git('rev-parse','HEAD').strip()==HEAD,'worktree HEAD is not pinned 520e7dc')
    sealname=default_seal(); seal=load(ROOT/sealname)
    need(sealname=='docs/evidence/detector_freeze_2026-10-20_1.2.0_f1a.json','unexpected current default seal')
    before=snapshot(seal)
    oldseal=load(ROOT/'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json')
    deltas=[]
    for n,h in seal['files'].items():
        need(before['files'][n]==h,('current seal hash',n))
        if h!=oldseal['files'][n]: deltas.append(dict(path=n,old=oldseal['files'][n],current=h))
    need([v['path'] for v in deltas]==['resense/lowobj.py'],'unexpected sealed source delta')
    need(git('diff','--name-only',PREVIOUS,HEAD,'--','resense','native','configs','ros2_ws','setup.py','pyproject.toml','scripts/build_native.sh').splitlines()==['resense/lowobj.py'],'unexpected detector revision delta')
    native_names=git('ls-files','native','resense/_native.py','scripts/build_native.sh','setup.py','pyproject.toml').splitlines()
    native_sources={}
    for n in native_names:
        h=sha(ROOT/n); old=hashlib.sha256(git('show',f'{PREVIOUS}:{n}',binary=True)).hexdigest()
        need(h==old==sha(OLD_ROOT/n),('native source changed',n)); native_sources[n]=h
    old_manifest=load(MISS/'manifest-before.json')
    binary=OLD_ROOT/'resense/_resense_native.so'; expected=old_manifest['sources'][str(binary)]
    need(record(binary)['sha256']==expected,'original native binary mismatch')
    target=ROOT/'resense/_resense_native.so'; copied=False
    if not target.exists():
        need(target.parent.is_dir(),'native destination parent absent')
        with binary.open('rb') as src,target.open('xb') as dest: shutil.copyfileobj(src,dest)
        copied=True
    need(sha(target)==expected,'copied native binary mismatch')
    record(target)
    freeze=subprocess.run(['python3','-B',str(ROOT/'scripts/detector_freeze.py'),'verify'],cwd=ROOT,capture_output=True,text=True)
    need(freeze.returncode==0,('current freeze failed',freeze.stderr))
    control=WORK/('freeze-control-'+uuid.uuid4().hex); control.mkdir()
    for n in set(seal['files'])|{sealname,'scripts/detector_freeze.py',seal['baseline']['path'],seal['validation']['path']}:
        dest=control/n; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/n,dest)
    cmd=['python3','-B',str(control/'scripts/detector_freeze.py'),'verify']
    clean=subprocess.run(cmd,capture_output=True,text=True)
    need(clean.returncode==0,('clean temporary freeze control',clean.stderr))
    with (control/'resense/lowobj.py').open('ab') as f: f.write(b'\n# deliberate copy-only positive control\n')
    bad=subprocess.run(cmd,capture_output=True,text=True)
    need(bad.returncode!=0 and 'changed detector file: resense/lowobj.py' in bad.stderr,'freeze tamper control not detected')
    # Pin unchanged original injection tools, H1 test and fixture to original Git bytes.
    tools=git('ls-files','docs/evidence/judgement_2026-10-13/scripts').splitlines()+['tests/test_column_collision_core.py','tests/fixtures/h1_physical.py']
    tools_hash={}
    for n in tools:
        h=record(ROOT/n)['sha256']; need(h==hashlib.sha256(git('show',f'{PREVIOUS}:{n}',binary=True)).hexdigest(),('injection/test tool changed',n)); tools_hash[n]=h
    return seal,before,dict(commit=HEAD,previous_commit=PREVIOUS,worktree=str(ROOT),sealed_files=len(seal['files']),
        default_manifest=sealname,manifest_sha256=sha(ROOT/sealname),seal_digest=seal['source_sha256'],
        detector_delta=deltas,current_sources=before,unchanged_native_sources=native_sources,
        native_binary=dict(sha256=expected,destination=str(target),copied_from_verified_existing_binary=copied,rebuild=False),
        freeze=dict(returncode=freeze.returncode,stdout=freeze.stdout,clean_copy_passed=True,tampered_copy_rejected=True),
        unchanged_injection_tools_and_tests=tools_hash)


def input_hashes():
    old=load(MISS/'manifest-before.json'); matched=[]
    for name,expected in old['inputs'].items():
        value=record(name); need(value['sha256']==expected,('original fixed input no longer matches',name))
        matched.append(dict(path=name,bytes=value['bytes'],sha256=value['sha256']))
    need(BASE.is_file(),'fixed baseline missing; evaluator must not create it')
    captures={}
    with gzip.open(MISS/'publication-evidence.json.gz','rt') as f: bundle=json.load(f)
    record(MISS/'publication-evidence.json.gz')
    for mode in ['plain','traced']:
        path=OLD_WORK/(mode+'.pkl.gz'); value=record(path)
        need(value['sha256']==bundle['source_capture_sha256'][mode],('old capture hash',mode)); captures[mode]=value
    return dict(fixed_cache_baseline_icp_files=matched,old_capture_hashes=captures,
                previous_review=record(OLD/'h1_final_review_2026-10-20/report.json'))


def directed(Detector,DetectorConfig,Frame):
    summaries=sum([load(RAIL/n) for n in ['run-summary.json','additional-controls-summary.json','floor-summary.json','near-control-summary.json']],[])
    rows=[]; diffs=[]; cache={}; summaries_out=[]; controls={}; currentraw=WORK/'directed-current.pkl.gz'
    with gzip.open(currentraw,'xb',compresslevel=1) as capture:
        for case in summaries:
            data=load(RAIL/(case['name']+'.json')); det=Detector(DetectorConfig()); per=[]
            for old in data['frames']:
                name=old['input']
                if name not in cache:
                    record(RAIL/name)
                    with np.load(RAIL/name,allow_pickle=False) as f: cache[name]={k:f[k] for k in f.files}
                arrays=cache[name]; spec=data['inputs'][name]['geometry']; p=arrays['xyz']; lab=arrays['labels']
                for key in ['xyz','ring','labels']: need(fp(arrays[key])==data['inputs'][name][key],('directed input fingerprint',case['name'],key))
                if det._previous_latency_ms is not None: det._previous_latency_ms=42.
                r=det.process(Frame(xyz=p,ring=arrays['ring'],intensity=np.full(len(p),35,np.float32),stamp=old['i']*.1))
                result=raw(r); tracks=raw(det.tracker.tracks)
                fprint={f.name:fp(getattr(r,f.name)) for f in dc.fields(r) if f.name!='timing_ms'}; fprint['tracker']=fp(det.tracker.tracks)
                changed=[k for k in old['exact'].keys()|fprint.keys() if not exact(old['exact'].get(k),fprint.get(k))]
                paths=difference(old['exact'],fprint)
                if paths: diffs.append(dict(case=case['name'],i=old['i'],differences=paths))
                x=spec.get('distance',67.); y=spec.get('lateral',.68)
                ds=match(result['detections'],x,y,1.,.5); ws=match(result['warnings'],x,y,1.,.5)
                need(ds==match_second(result['detections'],x,y,1.,.5),'directed second matcher disagrees')
                cs=[j for j,c in enumerate(result['candidates']) if abs(c['distance']-x)<1 and abs(c['centroid'][1]-y)<.5]
                head=spec.get('bed',-2.18)+spec.get('host_height',.35); target=p[lab==1]
                h=target[:,2].astype(float)-head
                body=int(np.count_nonzero((abs(target[:,1])<=1.05)&(h>=.12)&(h<=3.)))
                outside=abs(y)-spec.get('width',.46)/2>1.05
                need(body==data['inputs'][name]['raw_host_body_points'],'independent truth body differs')
                core=any(result['candidates'][j]['collision_core'] for j in cs)
                trackwindow=[t for t in tracks if abs(t['centroid'][0]-x)<1 and abs(t['centroid'][1]-y)<.5]
                row=dict(case=case['name'],i=old['i'],changed_fields=sorted(changed),equal=not changed,
                    current_fingerprint_sha256=canonical(fprint),old_fingerprint_sha256=canonical(old['exact']),
                    old_target_hit=bool(old['target_detection_indices']),target_hit=bool(ds),target_warning=bool(ws),
                    hit_equal=bool(ds)==bool(old['target_detection_indices']),target_core=bool(core),
                    old_target_core=any(old['output']['candidates'][j]['collision_core'] for j in old['target_candidates']),
                    any_candidate_core=any(c['collision_core'] for c in result['candidates']),global_STOP=bool(r.obstacle),
                    truth_outside=outside,host_head_z=head,raw_body_points=body,raw_target_count=len(target),
                    geometric_gap_m=abs(y)-spec.get('width',.46)/2-1.05,
                    false_core=bool(outside and core),false_target_STOP=bool(outside and ds),
                    inside_miss=bool(body>0 and not ds),floor_held=bool(r.track.floor_held),rail_slabs=r.track.rail_slabs,
                    actual_raw_rail_returns=int(np.isin(lab,[10,11,20,21]).sum()),
                    track_model_exact_to_capture=exact(fp(r.track),old['exact']['track']),
                    matching_detections=[result['detections'][j] for j in ds],
                    target_tracker=[{k:t[k] for k in ['id','hits','misses','reported','zone_hist','column_hist','collision_core_hits','collision_core_ready','collision_core_span_s']} for t in trackwindow])
                rows.append(row); per.append(row)
                pickle.dump(dict(case=case['name'],i=old['i'],input=name,frame_result=result,tracker=tracks),capture,protocol=5)
                if ds and 'known_positive_match' not in controls:
                    need(not match([],x,y,1.,.5),'deleted directed hit not detected'); controls['known_positive_match']=dict(case=case['name'],i=old['i'])
                if ds and 'removed_positive_output_detected' not in controls:
                    changed_control=copy.deepcopy(fprint); changed_control['detections']=[]
                    need(difference(fprint,changed_control),'deleted positive directed detection escaped comparator'); controls['removed_positive_output_detected']=True
            summaries_out.append(dict(case=case['name'],scans=len(per),equal_rows=sum(r['equal'] for r in per),
                target_STOP=[r['i'] for r in per if r['target_hit']],target_core=[r['i'] for r in per if r['target_core']],
                false_core=[r['i'] for r in per if r['false_core']],false_target_STOP=[r['i'] for r in per if r['false_target_STOP']],
                inside_miss=[r['i'] for r in per if r['inside_miss']],floor_held=[r['i'] for r in per if r['floor_held']]))
            print('DIRECTED_CURRENT',case['name'],'EQUAL',sum(r['equal'] for r in per),'/',len(per),'STOP',summaries_out[-1]['target_STOP'],flush=True)
    need(len(rows)==518 and len(summaries_out)==31,'directed coverage incomplete')
    return dict(sequences=31,scans=518,fields_plus_full_tracker_compared=True,equal_rows=sum(r['equal'] for r in rows),
        changed_rows=sum(not r['equal'] for r in rows),changed_field_counts=dict(collections.Counter(f for r in rows for f in r['changed_fields'])),
        matching_changed_rows=[dict(case=r['case'],i=r['i']) for r in rows if not r['hit_equal']],
        false_core_rows=sum(r['false_core'] for r in rows),false_target_STOP_rows=sum(r['false_target_STOP'] for r in rows),
        summaries=summaries_out,rows=rows,positive_controls=controls,current_capture=dict(path=str(currentraw),bytes=currentraw.stat().st_size,sha256=sha(currentraw))),diffs


def replay_A():
    judge=ROOT/'docs/evidence/judgement_2026-10-13/scripts'; sys.path.insert(0,str(judge))
    import range_test as evaluator
    need(Path(evaluator.__file__).resolve()==judge/'range_test.py','wrong evaluator import')
    original=evaluator.run_frame; oldstream=iter(stream(OLD_WORK/'plain.pkl.gz'))
    rows=[]; diffs=[]; controls={}; capturepath=WORK/'a-current.pkl.gz'
    with gzip.open(capturepath,'xb',compresslevel=1) as capture:
        def run_frame(rep,xyz,inten,ring,metadata,index):
            caller=sys._getframe(1).f_locals; info=dict(caller['info'])
            exactpos=dict(X=float(caller['X']) if info['X'] is not None else None,
                          Y=float(caller['yc']) if 'Y' in info else None,Zb=float(caller['zb']) if 'Zb' in info else None)
            first=len(xyz)-2*info['n_obj']; old=next(oldstream)
            need(old['k']==index and exact(old['exact'],exactpos) and exact(old['info'],info),'A evaluator placement/caller changed')
            ih=injection_hash(dict(xyz=xyz,intensity=inten,ring=ring,metadata=metadata))
            need(ih==old['input_hash'],'A injected raw input bytes changed')
            previous=rep.detector._previous_latency_ms
            if previous is not None: rep.detector._previous_latency_ms=42.
            result=original(rep,xyz,inten,ring,metadata,index); result_raw=raw(result)
            targettracks=[raw(t) for t in rep.detector.tracker.tracks if exactpos['X'] is not None
                and abs(float(t.centroid[0])-exactpos['X'])<10 and exactpos['Y'] is not None
                and abs(float(t.centroid[1])-exactpos['Y'])<3]
            oldresult=old['frame_result']; changed=[k for k in oldresult.keys()|result_raw.keys() if not exact(oldresult.get(k),result_raw.get(k))]
            paths=difference(oldresult,result_raw)
            tdiff=difference(old['tracks'],targettracks,'captured_target_window_tracker')
            if paths or tdiff: diffs.append(dict(k=index,differences=paths+tdiff))
            visible=info['n_obj']>0 and exactpos['X'] is not None and exactpos['X']>3
            ids=[]; oldids=[]; matched=[]
            if visible:
                x,y=exactpos['X'],exactpos['Y']; mi=match(result_raw['detections'],x,y)
                need(mi==match_second(result_raw['detections'],x,y),'A independent matchers disagree')
                oldmi=match(oldresult['detections'],x,y)
                ids=[result_raw['detections'][j]['id'] for j in mi]; oldids=[oldresult['detections'][j]['id'] for j in oldmi]
                matched=[result_raw['detections'][j] for j in mi]
                if ids and 'known_positive_match' not in controls:
                    need(not match([],x,y),'A deleted positive hit escaped matcher'); controls['known_positive_match']=index
                if index==164:
                    damaged=copy.deepcopy(result_raw); damaged['xyz'][0,0]=np.nextafter(damaged['xyz'][0,0],np.float32(np.inf))
                    need(any(d['path']=='result.xyz' for d in difference(result_raw,damaged)),'A one-ULP escaped exact comparator')
                    controls['one_ULP_detected']=True
                    damaged=copy.deepcopy(result_raw); damaged['detections']=[]
                    need(difference(result_raw,damaged),'A removed detection escaped exact comparator'); controls['removed_detection_detected']=True
            item=dict(k=index,visible=visible,X=exactpos['X'],Y=exactpos['Y'],input_hash=ih,input_equal=True,
                equal=not changed and not tdiff,changed_fields=sorted(changed),stored_tracker_equal=not tdiff,
                old_frame_ieee_sha256=canonical(oldresult),current_frame_ieee_sha256=canonical(result_raw),
                old_target_tracker_ieee_sha256=canonical(old['tracks']),current_target_tracker_ieee_sha256=canonical(targettracks),
                hit=bool(ids),old_hit=bool(oldids),matching_ids=ids,old_matching_ids=oldids,matching_detections=matched,
                detections=len(result.detections),warnings=len(result.warnings),
                raw_target_returns=len(xyz)-first,decision=evaluator.node_decision(result))
            rows.append(item)
            rec=dict(k=index,info=info,exact=exactpos,metadata=metadata,input_hash=ih,
                frame_result=result_raw,input_target=dict(first_index=first,xyz=xyz[first:],intensity=inten[first:],ring=ring[first:]),
                tracks=targettracks,all_tracks=raw(rep.detector.tracker.tracks),events=[])
            pickle.dump(rec,capture,protocol=5)
            if index in [152,159,164,174,177,178,196,224,306,319,323,324]:
                print('A_CURRENT',index,'FIELDS',changed,'TRACKER_EQUAL',not tdiff,'HIT',bool(ids),'OLD_HIT',bool(oldids),
                      'FIRST_TARGET_XYZ',result.xyz[first:first+2].tolist() if visible else [],flush=True)
            if index%50==0: print('A_PROGRESS',index,flush=True)
            return result
        evaluator.run_frame=run_frame
        argv=sys.argv
        prefix=WORK/'range-current'
        need(not Path(str(prefix)+'.json').exists(),'A evaluator output already exists')
        sys.argv=[str(evaluator.__file__),str(CACHE),str(ICP),str(prefix),'--obj','0.3,0.3,2.8','--start','150','--d0','230','--end','340']
        try: evaluator.main()
        finally: evaluator.run_frame=original; sys.argv=argv
    need(next(oldstream,None) is None and len(rows)==340,'A capture coverage')
    judged=load(WORK/'range-current.json'); visible=[r for r in rows if r['visible']]
    need(len(visible)==177,'A visibility unexpectedly changed')
    current_miss={r['k'] for r in visible if not r['hit']}; oldmiss={r['k'] for r in visible if not r['old_hit']}
    for row in visible: need(row['hit']==judged['rows'][row['k']]['hit'],'rounded evaluator and exact matcher disagree')
    # Same set-difference checker must detect an injected positive and removed miss.
    positive=next(r['k'] for r in visible if r['hit']); missing=min(current_miss)
    need((current_miss|{positive})-current_miss=={positive} and current_miss-(current_miss-{missing})=={missing},'set positive controls')
    return dict(frames=340,visible_rows=177,hits=sum(r['hit'] for r in visible),misses=len(current_miss),old_misses=len(oldmiss),
        miss_rows=sorted(current_miss),old_miss_rows=sorted(oldmiss),added_misses=sorted(current_miss-oldmiss),removed_misses=sorted(oldmiss-current_miss),
        equal_rows=sum(r['equal'] for r in rows),changed_rows=sum(not r['equal'] for r in rows),
        changed_field_counts=dict(collections.Counter(f for r in rows for f in r['changed_fields'])),
        tracker_changed_rows=[r['k'] for r in rows if not r['stored_tracker_equal']],rows=rows,positive_controls=controls,
        current_capture=dict(path=str(capturepath),bytes=capturepath.stat().st_size,sha256=sha(capturepath)),
        evaluator_summary=judged['summary'],tracker_scope='Every field of all original target-window stored tracks; old A captures did not retain all background tracks.',
        no_new_causal_trace=True),diffs


def tests():
    xml=HERE/'tests104.xml'; log=HERE/'tests104.log'
    need(not xml.exists() and not log.exists(),'test outputs already exist')
    cmd=[sys.executable,'-B','-m','pytest','tests/test_column_collision_core.py','-q','-p','no:cacheprovider',
         '--basetemp='+str(WORK/'pytest-temp'),'--junitxml='+str(xml)]
    run=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=600)
    with log.open('x') as f: f.write(run.stdout+run.stderr)
    suites=ET.parse(xml).getroot(); counts={k:sum(int(s.attrib.get(k,0)) for s in suites.iter('testsuite')) for k in ['tests','failures','errors','skipped']}
    return dict(command=cmd,returncode=run.returncode,counts=counts,stdout=run.stdout,stderr=run.stderr,
                test_module_sha256=sha(ROOT/'tests/test_column_collision_core.py'),fixture_sha256=sha(ROOT/'tests/fixtures/h1_physical.py'))


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--out',type=Path,default=HERE/'current-report.json'); args=parser.parse_args()
    dest=args.out.resolve(); need(dest.parent==HERE and not dest.exists(),'exclusive report path')
    need(os.environ.get('RESENSE_REPO')==str(ROOT) and os.environ.get('PYTHONPATH')==str(ROOT),'wrong detector environment')
    need(os.environ.get('OPENBLAS_CORETYPE')=='Haswell' and os.environ.get('OMP_NUM_THREADS')=='1'
         and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1','P4 environment')
    started=time.monotonic(); record(Path(__file__)); record(ROOT/'CLAUDE.md'); record(ROOT/'AGENTS.md'); record(ROOT/'docs/DETECTOR_FREEZE.md')
    seal,before,source=prepare(); inputs=input_hashes()
    sys.path.insert(0,str(ROOT))
    import resense
    from resense.detector import Detector,FrameResult
    from resense.config import DetectorConfig
    from resense.frame import Frame
    from resense import _native
    need(Path(resense.__file__).resolve().is_relative_to(ROOT) and _native.enabled()
         and Path(_native.LIBRARY).resolve()==ROOT/'resense/_resense_native.so','wrong detector/native runtime import')
    d,dd=directed(Detector,DetectorConfig,Frame); a,ad=replay_A(); t=tests()
    modules={name:str(Path(m.__file__).resolve()) for name,m in sys.modules.items() if name.startswith(('resense','judge_runner','range_test')) and getattr(m,'__file__',None)}
    need(all(Path(p).is_relative_to(ROOT) for p in modules.values()),('non-pinned module imported',modules))
    after=snapshot(seal); need(before==after,'pinned worktree source/index changed during replay')
    for name,info in INPUTS.items():
        s=Path(name).stat(); need([s.st_size,s.st_mtime_ns,s.st_ino]==info['stat'],('input stat changed',name))
    # Do not erase differences: all changed leaf/array paths are durable, lossless JSON.
    diffpath=HERE/'row-differences.json.gz'
    with gzip.open(diffpath,'xt',compresslevel=9) as f: json.dump(jsonable(dict(directed=dd,A=ad)),f,separators=(',',':'),allow_nan=False)
    need(diffpath.stat().st_size<20_000_000,'difference artifact too large')
    controls=dict(signed_zero_detected=not exact(-0.,0.),dtype_detected=not exact(np.array([1.],np.float32),np.array([1.],np.float64)))
    need(all(controls.values()),'exact comparator controls')
    old_findings_reproduced=a['miss_rows']==a['old_miss_rows'] and not d['matching_changed_rows']
    blocker=bool(a['misses'] or d['false_core_rows'] or d['false_target_STOP_rows'])
    result=dict(schema='resense-h1-current-source-delta-v1',generated_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        audit_completed=True,H1_acceptance='BLOCKED' if blocker else 'UNVERIFIED',h1_closed=False,
        source=source,inputs=inputs,compared_non_timing_fields=[f.name for f in dc.fields(FrameResult) if f.name!='timing_ms'],
        deterministic_previous_latency_ms=42.,first_latency=None,directed=d,A=a,tests=t,
        previous_H1_findings_reproduced=old_findings_reproduced,all_outputs_exact_to_f56=(d['changed_rows']==0 and a['changed_rows']==0),
        field_difference_artifact=dict(path=diffpath.name,sha256=sha(diffpath),bytes=diffpath.stat().st_size),
        positive_controls=controls,imported_detector_and_evaluator_modules=modules,source_and_worktree_index_unchanged=True,
        checked_inputs=INPUTS,elapsed_s=time.monotonic()-started,
        limits=['Bounded delta review only; no full gate/X3/Falcon or G3.',
               'No new external true axis; old far-reference blocker remains unresolved.',
               'Fresh runs are plain; old causal traces remain immutable f56 evidence, not claimed as new 520 traces.',
               'Synthetic host identity is fixture truth; no universal guarantee or real-world prevalence claim.',
               'Old /home/aiops/resense checkout is input-only; its concurrent HEAD is not used for execution.'])
    save(dest,result)
    print(json.dumps(dict(audit_completed=True,commit=HEAD,H1=result['H1_acceptance'],directed_scans=d['scans'],directed_changed=d['changed_rows'],
        A_frames=a['frames'],A_changed=a['changed_rows'],visible=a['visible_rows'],hits=a['hits'],misses=a['misses'],
        false_core_rows=d['false_core_rows'],false_STOP_rows=d['false_target_STOP_rows'],tests=t['counts'],
        report_bytes=dest.stat().st_size,report_sha256=sha(dest),elapsed_s=result['elapsed_s'])))


if __name__=='__main__': main()
