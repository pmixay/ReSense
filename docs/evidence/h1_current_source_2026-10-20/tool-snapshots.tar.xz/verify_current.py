#!/usr/bin/env python3
"""Second-method verification from retained current raw captures; no detector import.

Does not import recheck_current.py. Writes only one exclusive verification JSON
in the new current-source evidence directory. No replay or Git writes.
"""
import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path
import pickle
import struct
import sys
import collections
import subprocess
sys.dont_write_bytecode=True
import numpy as np

ROOT=Path('/tmp/opencode/h1-reviewed-publication')
HERE=ROOT/'docs/evidence/h1_current_source_2026-10-20'
OLD=Path('/home/aiops/resense/docs/evidence')
WORK=Path('/tmp/opencode/h1-final-review/current520')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()


def stream(p):
    with gzip.open(p,'rb') as f:
        while True:
            try: yield pickle.load(f)
            except EOFError: return


def normalized(v):
    if isinstance(v,np.ndarray):
        return ['ndarray',v.dtype.str,list(v.shape),hashlib.sha256(memoryview(np.ascontiguousarray(v))).hexdigest()]
    if isinstance(v,np.generic): return ['numpy_scalar',v.dtype.str,v.tobytes().hex()]
    if isinstance(v,float): return ['float64',struct.pack('<d',v).hex()]
    if isinstance(v,dict): return ['dict',[[k,normalized(v[k])] for k in sorted(v)]]
    if isinstance(v,(tuple,list)): return [type(v).__name__,[normalized(x) for x in v]]
    return [type(v).__name__,v]


def same(a,b): return normalized(a)==normalized(b)


def match(ds,x,y,dx=None,dy=1.15):
    width=max(2.,.03*x)+.15 if dx is None else dx
    return [d['id'] for d in ds if max(abs(float(d['distance'])-x)/width,abs(float(d['center'][1])-y)/dy)<=1.]


def check_fingerprint(v,record):
    if isinstance(v,np.ndarray):
        assert record==dict(dtype=v.dtype.str,shape=list(v.shape),sha256=hashlib.sha256(memoryview(np.ascontiguousarray(v))).hexdigest())
    elif isinstance(v,np.generic): check_fingerprint(np.asarray(v),record)
    elif isinstance(v,float): assert int.from_bytes(struct.pack('>d',v),'big')==int(record['f64'],16)
    elif isinstance(v,dict):
        assert v.keys()==record.keys()
        for k in v: check_fingerprint(v[k],record[k])
    elif isinstance(v,(tuple,list)):
        assert len(v)==len(record)
        for a,b in zip(v,record): check_fingerprint(a,b)
    else: assert type(v)==type(record) and v==record


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--out',type=Path,default=HERE/'verification.json'); args=parser.parse_args()
    dest=args.out.resolve(); assert dest.parent==HERE and not dest.exists()
    r=json.loads((HERE/'current-report.json').read_text()); fields=r['compared_non_timing_fields']
    assert len(fields)==19 and r['source']['commit']=='520e7dcd2843a0e7c9055fca6c186c0d1687945f'
    assert sha(OLD/'h1_final_review_2026-10-20/report.json')=='bdd7e94747aff3422d217a824f9327be09f5c1e6c0cdfb9f1da9ca81f533c71e'
    assert sha(OLD/'h1_final_review_2026-10-20/review_h1.py')=='3921a10aa9f52f2e6f6e0972f6ceacda5dd9c154fea05e4811057a33ed955167'
    current=r['A']['current_capture']; assert sha(current['path'])==current['sha256']
    rows=[]; miss=[]; controls={}; example={}
    for now,plain,traced in zip(stream(current['path']),stream('/tmp/opencode/h1-miss-audit/plain.pkl.gz'),
                                stream('/tmp/opencode/h1-miss-audit/traced.pkl.gz'),strict=True):
        k=now['k']; assert k==plain['k']==traced['k']
        for f in fields:
            assert same(now['frame_result'][f],plain['frame_result'][f]),(k,f,'old plain')
            assert same(now['frame_result'][f],traced['frame_result'][f]),(k,f,'old traced')
        assert same(now['tracks'],plain['tracks']) and same(now['tracks'],traced['tracks'])
        assert same(now['input_target'],plain['input_target']) and same(now['metadata'],plain['metadata'])
        assert now['input_hash']==plain['input_hash']==traced['input_hash']
        if now['info']['n_obj']>0 and now['exact']['X'] is not None and now['exact']['X']>3:
            x,y=now['exact']['X'],now['exact']['Y']; ids=match(now['frame_result']['detections'],x,y)
            oldids=match(plain['frame_result']['detections'],x,y)
            assert ids==oldids==r['A']['rows'][k]['matching_ids']
            rows.append(k)
            if not ids: miss.append(k)
            if k==164:
                assert ids and not match([],x,y)
                altered=copy.deepcopy(now['frame_result']); altered['detections']=[]
                assert not same(altered,now['frame_result'])
                controls['deleted_known_positive_detection']=True
        if k in [318,319,323,324]:
            example[k]=[dict(id=t['id'],core_hits=t['collision_core_hits'],core_span=t['collision_core_span_s'],
                             core_ready=t['collision_core_ready'],reported=t['reported']) for t in now['tracks']]
    assert len(rows)==177 and len(miss)==63 and miss==r['A']['miss_rows']==r['A']['old_miss_rows']
    assert r['A']['frames']==340 and r['A']['changed_rows']==0

    # Recount directed failures using actual injected-return provenance in each
    # candidate, independently of the primary distance/centroid candidate matcher.
    directed=r['directed']['current_capture']; assert sha(directed['path'])==directed['sha256']
    cases={}; cache={}; count=0; false_core=false_stop=0; changes=[]; stops={}; held=[]
    for now in stream(directed['path']):
        name=now['case']; i=now['i']; count+=1
        if name not in cases: cases[name]=json.loads((OLD/'h1_rail_limits_2026-10-20'/(name+'.json')).read_text())
        data=cases[name]; old=data['frames'][i]
        values=dict(now['frame_result'],tracker=now['tracker'])
        check_fingerprint(values,old['exact'])
        spec=data['inputs'][now['input']]['geometry']; d=spec.get('distance',67.); y=spec.get('lateral',.68)
        ids=match(now['frame_result']['detections'],d,y,1.,.5)
        assert bool(ids)==bool(old['target_detection_indices'])
        outside=abs(y)-spec.get('width',.46)/2>1.05
        if now['input'] not in cache:
            with np.load(OLD/'h1_rail_limits_2026-10-20'/now['input'],allow_pickle=False) as f: cache[now['input']]={k:f[k] for k in f.files}
        raw=cache[now['input']]; lab=raw['labels']
        target=[]
        for c in now['frame_result']['candidates']:
            ix=c['points_idx']; ix=ix[(ix>=0)&(ix<len(lab))]
            if len(ix) and np.mean(lab[ix]==1)>.5: target.append(c)
        core=any(c['collision_core'] for c in target)
        if outside:
            false_core+=int(core); false_stop+=bool(ids)
        if ids: stops.setdefault(name,[]).append(i)
        if name=='actual_floor_held' and i>=14:
            assert now['frame_result']['track']['floor_held'] and now['frame_result']['track']['rail_slabs']==3
            assert not np.isin(lab,[10,11,20,21]).any() and not np.any(lab==1)
            held.append(i)
    assert count==518 and len(cases)==31
    assert (false_core,false_stop)==(56,40)==(r['directed']['false_core_rows'],r['directed']['false_target_STOP_rows'])
    assert stops['loss_target_remains']==list(range(4,18))
    assert stops['loss_target_absent']==list(range(4,15))
    assert stops['actual_floor_held']==list(range(4,15)) and held==list(range(14,28))
    assert r['directed']['changed_rows']==0
    for n,h in r['source']['current_sources']['files'].items(): assert sha(ROOT/n)==h
    assert sha(r['source']['current_sources']['index_path'])==r['source']['current_sources']['index_sha256']
    assert subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==r['source']['commit']
    with gzip.open(HERE/'row-differences.json.gz','rt') as f: differences=json.load(f)
    assert differences==dict(directed=[],A=[])
    result=dict(status='PASS',method='Separate verifier; no detector or primary recheck module imported',
                current_report_sha256=sha(HERE/'current-report.json'),A_frames_compared_to_both_old_plain_and_traced=340,
                visible_matching_rows=177,hits=114,misses=63,exact_miss_set_equal=True,
                directed_full_field_and_tracker_rows=518,directed_sequences=31,
                provenance_based_false_core_rows=false_core,false_target_STOP_rows=false_stop,
                actual_floor_held_rows=held,late_core_release_snapshots=example,
                difference_artifact_empty=True,positive_controls=controls,
                original_f56_report_and_script_unchanged=True,current_sources_and_index_unchanged=True)
    with dest.open('x') as f: json.dump(result,f,indent=2); f.write('\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
