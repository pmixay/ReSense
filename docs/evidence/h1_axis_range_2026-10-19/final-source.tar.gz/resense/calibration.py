"""Automatic LiDAR mount calibration (v0.6): which way the sensor looks, and how it is tilted.

The detector works in the vehicle frame (X forward, Y left, Z up). ``sensor.forward/left/up``
maps the raw sensor axes onto it for the hackathon mount (``-y/+x/+z``); the track model then
re-estimates the sensor height, the lateral offset and the yaw of the track every frame. What
the per-frame model cannot absorb is a *different mount*: a unit bolted on with another axis
forward (``+x`` is the ROS convention and what most drivers publish), upside down, or rolled
or pitched by a few degrees. A roll of 3 deg tilts the gauge polygon by 7 cm at its sides and
18 cm at its top corners; a wrong forward axis makes the detector blind. This module finds the
mount from the data during the first frames and hands the detector a correction rotation
``R`` (``p_vehicle = R @ p_configured``), so a new train needs no hand calibration.

What is measured, and from what:

1. **Orientation** (which signed sensor axis points forward / up): only when the configured
   mapping fails a sanity check on a frame (no rail pair in the near range, or fewer far
   returns ahead than behind). Then the axis-aligned proper rotations are tried - the 8 that
    keep the configured up axis vertical (upright or inverted, the default mount assumption)
    or, with ``keep_up_axis: false``, all 24 - and each
   is scored by the rail pair it reveals: two parallel ridges 1.59 m apart, 0.08-0.5 m above a
    bed that lies below the sensor, running along +X, with the tunnel visible ahead.
    A wall can imitate that pattern, so it is not independent orientation proof.
    A new orientation is adopted only when
   the same candidate wins on ``orientation_votes`` frames and the configured one never
   passed, so a platform or a switch (no rails) cannot flip the mount. (The sideways
   candidates are off by default because a flat side wall of a square tunnel with two cable
   trays on it passes for a bed with a rail pair: measured on ``roundT_squareT_pressureGate_squareT``.
    Geometry alone cannot tell such a wall from the bed. With reliable channel
    cones, the default upright-scanner assumption is checked independently:
    their common axis must be vertical under the proposed mapping. A gross
    axis permutation can then be searched in all 24 rotations, restricted by
    that measured axis. Directional clouds can also constrain signed forward
    and, separately, a well-resolved broad-horizontal/narrow-vertical FOV.
    Without either up cue the original orientation family is kept. Neither
    cue measures gravity or validates a physically sideways scanning plane.)
2. **Roll** from the rail pair: the two rail heads are at the same height in the track's own
   cross-section, so their height difference over the rail spacing is the sensor roll
   relative to the rail plane (which is what the clearance gauge is defined in).
3. **Pitch** from the slope of the bed fit at the vehicle (``floor_coef`` linear term): the
   train body rides on the track, so the bed slope at X = 0 in the sensor frame is the mount
   pitch whatever the grade of the line.
4. **Yaw** from the rail-slab tangent (``RailsFit.tan_yaw``) - only when its median exceeds
   ``min_yaw_deg`` (a big mount yaw); the per-frame track model follows small and dynamic
   yaw (curves) itself.

The tilt is measured in two stages, because on a moving train the per-frame roll swings by
+-1 deg with the cant transitions and the body's lean (the 20-minute ride: median -0.1 deg,
10-90 % range -1.0 ... +0.7 deg, EXPERIMENTS.md section 6), and neighbouring frames see the same
stretch of rail: a median of 5 consecutive frames is off by up to 1.6-2.2 deg there. A
**provisional** correction from the first ``provisional_frames`` observations is applied only
for a clearly tilted rig (``provisional_min_deg``, e.g. the ~3 deg of the ``doubleT_obstacle``
rig); the **final** one is the median of ``frames`` observations taken every ``obs_spacing``
frames (20 s at the defaults: p90 error 0.5 deg on the ride), applied above ``apply_min_deg``,
and then frozen; the track model is re-seeded after every change. Afterwards the same
measurements continue every ``monitor_period`` frames on the corrected cloud: when the median
of the last ``drift_window`` checks leaves ``drift_warn_deg`` (a mount knocked loose - a
lasting change, not a curve) it is reported through the health status, never silently
re-applied.
Implausible estimates (tilt > ``max_tilt_deg``) are rejected and reported; with no rail pair
in ``max_frames`` frames the calibrator gives up and keeps the configured mapping
(``status = 'fallback'``).
"""
from __future__ import annotations

import itertools
from copy import deepcopy
from dataclasses import dataclass, field
import math
import sys
from typing import List, Optional

import numpy as np

from resense.config import CalibrationConfig, TrackConfig
from resense.track import TrackModel, _fit_floor, default_track_model, estimate_rails


class OrientationReplayBuffer:
    """Owned, bounded startup inputs; any discontinuity permanently disables this attempt.

    Only plain metadata containers/scalars and numeric arrays are copied. The byte
    estimate is conservative and includes array payloads, metadata, and containers.
    The current frame counts toward both limits, so adoption after the budget cannot
    reconstruct a selectively truncated history.
    """
    MAX_BYTES = 32 * 1024 * 1024

    def __init__(self, max_frames: int):
        if type(max_frames) is not int or not 0 <= max_frames <= 4:
            raise ValueError("calibration.orientation_replay_frames must be an integer from 0 to 4")
        self.max_frames = max_frames
        self.frames = []
        self.used_bytes = 0
        self.peak_bytes = 0
        self.finished = max_frames == 0
        self.reason = "disabled" if self.finished else "pending"

    def stop(self, reason: str):
        self.frames.clear()
        self.used_bytes = 0
        self.finished, self.reason = True, reason

    @classmethod
    def _size(cls, value, seen, *, copy_reserve=True):
        if id(value) in seen:
            return 0
        seen.add(id(value))
        size = sys.getsizeof(value)
        if type(value) in (str, bytes, int, float, bool, type(None)):
            return size
        if isinstance(value, np.generic):
            if value.dtype.hasobject:
                raise ValueError("startup metadata scalar contains Python objects")
            return size + value.nbytes
        if type(value) is np.ndarray and not value.dtype.hasobject:
            return size + (value.nbytes if copy_reserve or not value.flags.owndata else 0)
        if type(value) in (dict, list, tuple):
            if copy_reserve:
                # deepcopy builds containers incrementally: a copied list can
                # have more allocated slots than its source. Reserve a whole
                # one-entry container per item before allocating the copy.
                unit = {dict: {None: None}, list: [None], tuple: (None,)}[type(value)]
                size += len(value) * sys.getsizeof(unit)
            items = itertools.chain.from_iterable(value.items()) if type(value) is dict else value
            for item in items:
                size += cls._size(item, seen, copy_reserve=copy_reserve)
                if size > cls.MAX_BYTES:
                    return size
            return size
        raise ValueError("unsupported startup metadata type")

    def capture(self, frame, ego_speed):
        if self.finished:
            return False
        if len(self.frames) >= self.max_frames:
            self.stop("frame_budget")
            return False
        try:
            stamp = float(frame.stamp)
            if not math.isfinite(stamp):
                self.stop("invalid_stamp")
                return False
            if self.frames:
                previous = self.frames[-1][0]
                gap = stamp - previous.stamp
                if not 0 < gap <= 1.0 or frame.frame_id != previous.frame_id:
                    self.stop("input_discontinuity")
                    return False
            # These arrays and metadata are copied separately, so aliases
            # across fields do not share deepcopy's memo or the byte charge.
            size = sum(self._size(value, set()) for value in (
                frame.xyz, frame.intensity, frame.ring, frame.meta,
                stamp, frame.frame_id, ego_speed)) + 1024
            if size + self.used_bytes > self.MAX_BYTES:
                self.stop("byte_budget")
                return False
            from resense.frame import Frame
            saved = Frame(xyz=frame.xyz.copy(), intensity=frame.intensity.copy(),
                          ring=None if frame.ring is None else frame.ring.copy(),
                          stamp=stamp, frame_id=frame.frame_id, meta=deepcopy(frame.meta))
            owned = self._size((saved.xyz, saved.intensity, saved.ring, saved.meta,
                                saved.stamp, saved.frame_id, ego_speed), set(),
                               copy_reserve=False) + 1024
            # Verify the actual retained allocation independently of the
            # pre-copy reservation, including container capacity and aliases.
            size = max(size, owned)
            if size + self.used_bytes > self.MAX_BYTES:
                self.stop("byte_budget")
                return False
        except (TypeError, ValueError, OverflowError, RecursionError):
            self.stop("unsupported_input")
            return False
        self.frames.append((saved, ego_speed))
        self.used_bytes += size
        self.peak_bytes = max(self.peak_bytes, self.used_bytes)
        return True


def orientation_candidates(keep_up_axis: bool = False) -> List[np.ndarray]:
    """The 24 proper rotations that map sensor axes onto signed vehicle axes (identity first);
    with ``keep_up_axis`` only the 8 whose up row is the configured up axis (either sign)."""
    out = [np.eye(3)]
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((1.0, -1.0), repeat=3):
            R = np.zeros((3, 3))
            for row, (col, s) in enumerate(zip(perm, signs)):
                R[row, col] = s
            if abs(np.linalg.det(R) - 1.0) < 1e-9 and not np.allclose(R, np.eye(3)):
                if keep_up_axis and abs(R[2, 2]) != 1.0:
                    continue
                out.append(R)
    return out


def rot_x(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def axis_label(R: np.ndarray) -> str:
    """'forward=-y left=+x up=+z' for an axis-aligned rotation (rows = vehicle axes)."""
    names = "xyz"
    parts = []
    for row, veh in zip(R, ("forward", "left", "up")):
        j = int(np.argmax(np.abs(row)))
        parts.append(f"{veh}={'+' if row[j] > 0 else '-'}{names[j]}")
    return " ".join(parts)


def scan_axis(xyz: np.ndarray, ring: Optional[np.ndarray]) -> Optional[np.ndarray]:
    """Unsigned common axis of well-resolved channel cones, or no evidence.

    Unit rays in one spinning-LiDAR channel lie in a plane normal to its spin
    axis. Require at least three different planes with a common normal; channel
    numbering/elevation order is irrelevant. This is sensor sampling evidence,
    not a floor fit. Ring-free/constant/mixed IDs, narrow pencils and translated
    or deskewed clouds that no longer resolve such planes give no constraint.
    Work is bounded to 16k rays and eight 128-ray channel fits at startup only.
    """
    if ring is None or ring.ndim != 1 or len(ring) != len(xyz) or ring.dtype.kind not in "iu":
        return None
    step = max(1, int(np.ceil(len(xyz) / 16384)))
    p = xyz[::step].astype(np.float64)
    ids = ring[::step]
    lengths = np.linalg.norm(p, axis=1)
    good = np.isfinite(p).all(axis=1) & (lengths > 1.0) & (ids >= 0)
    p, ids = p[good] / lengths[good, None], ids[good]
    channels = np.unique(ids)
    if len(channels) < 3:
        return None
    channels = channels[np.linspace(0, len(channels) - 1, min(8, len(channels)), dtype=int)]
    normals, means = [], []
    for channel in channels:
        u = p[ids == channel]
        if len(u) < 24:
            continue
        u = u[::max(1, int(np.ceil(len(u) / 128)))]
        mean = u.mean(axis=0)
        centered = u - mean
        eigen, vectors = np.linalg.eigh(centered.T @ centered / len(u))
        # Resolve a plane, not a line; <= 0.001 rms in unit-ray coordinates,
        # and at least 1000x more variance within the plane than normal to it.
        if eigen[1] < 1e-4 or eigen[0] > min(1e-6, eigen[1] * 1e-3):
            continue
        normal = vectors[:, 0]
        if normals and float(normal @ normals[0]) < 0:
            normal = -normal
        normals.append(normal)
        means.append(mean)
    if len(normals) < max(3, int(np.ceil(0.75 * len(channels)))):
        return None
    axis = np.mean(normals, axis=0)
    norm = float(np.linalg.norm(axis))
    if norm < 0.99:
        return None
    axis /= norm
    if np.min(np.asarray(normals) @ axis) < np.cos(np.radians(2.0)):
        return None
    offsets = np.sort(np.asarray(means) @ axis)
    if np.ptp(offsets) < 0.01:
        return None                         # different IDs must resolve different cones
    distinct, previous = 1, offsets[0]
    for offset in offsets[1:]:
        if offset - previous >= 0.005:
            distinct += 1
            previous = offset
    if distinct < 3:
        return None
    return axis


def directional_axes(xyz: np.ndarray) -> tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Bounded directional-FOV evidence: signed forward and optional unsigned scan up.

    A unique almost-one-sided axis identifies forward, NEVER roll about forward.
    Under the same upright-scanner assumption as channel cones, well-resolved
    broad horizontal / narrow vertical angular coverage can identify unsigned
    up without channel IDs. This describes sensor coverage, not gravity; cropped,
    one-sided or unresolved fields supply no up constraint. Bed/rail checks and
    repeated votes still decide the sign and validate an alternative mapping.
    """
    p = xyz[::max(1, int(np.ceil(len(xyz) / 16384)))].astype(np.float64)
    length = np.linalg.norm(p, axis=1)
    p = p[np.isfinite(p).all(axis=1) & (length > 1.0)]
    if len(p) < 500:
        return None, None
    positive = np.mean(p > 0, axis=0)
    one_sided = np.flatnonzero(np.maximum(positive, 1 - positive) > 0.98)
    if len(one_sided) != 1:
        return None, None
    j = int(one_sided[0])
    forward = np.zeros(3)
    forward[j] = 1.0 if positive[j] > 0.5 else -1.0
    along = p @ forward
    p, along = p[along > 0], along[along > 0]
    transverse = [k for k in range(3) if k != j]
    angles = np.arctan2(p[:, transverse], along[:, None])
    lo, hi = np.percentile(angles, [2, 98], axis=0)
    span = hi - lo
    narrow, broad = int(np.argmin(span)), int(np.argmax(span))
    # Require a broad two-sided scan and resolved vertical extent, rather than
    # inferring up from an arbitrary narrow object or a one-sided wall patch.
    if (span[broad] < np.radians(60) or span[narrow] < np.radians(5)
            or span[narrow] > np.radians(50) or span[broad] < 2 * span[narrow]
            or lo[broad] > -np.radians(15) or hi[broad] < np.radians(15)
            or max(abs(lo[narrow]), abs(hi[narrow])) > np.radians(35)):
        return forward, None
    up = np.zeros(3)
    up[transverse[narrow]] = 1.0
    return forward, up


@dataclass
class MountObservation:
    """What one frame says about the mount (in the currently corrected cloud)."""
    ok: bool                        # a plausible rail pair ahead, bed below, tunnel ahead
    rail_score: float = -1.0
    roll: float = float("nan")      # rad, correction about X that levels the rail heads
    pitch: float = float("nan")     # rad, correction about Y that levels the bed at the vehicle
    yaw: float = float("nan")       # rad, correction about Z that aligns X with the rails
    height: float = float("nan")    # m, sensor above the rail head at X = 0
    lateral: float = float("nan")   # m, track axis at X = 0 (+ left of the sensor)
    forward_ratio: float = 0.0      # far returns ahead / behind


def observe_mount(xyz: np.ndarray, tcfg: TrackConfig, prior: Optional[TrackModel] = None,
                  min_rail_score: float = 0.05, max_points: int = 60000,
                  point_weight: float = 1.0) -> MountObservation:
    """Measure rails, bed slope and tunnel direction of one cloud (vehicle frame under the
    current correction). Cheap: the near range only, strided to ``max_points``.
    ``point_weight`` scales admission counts for the S3 search sample only;
    voting/tilt observations are revalidated on the original cloud."""
    X = xyz[:, 0]
    ax = np.abs(X)
    lat = np.hypot(xyz[:, 1], xyz[:, 2])
    fwd = int(((X > 15.0) & (lat < 0.35 * ax)).sum()) * point_weight
    rear = int(((X < -15.0) & (lat < 0.35 * ax)).sum()) * point_weight
    ratio = fwd / (rear + 1.0)
    near = (X > 2.0) & (X < 45.0) & (np.abs(xyz[:, 1]) < 4.0)
    P = xyz[near]
    if P.shape[0] > max_points:
        P = P[:: int(np.ceil(P.shape[0] / max_points))]
    if P.shape[0] * point_weight < 500 or fwd < 200 or ratio < 1.5:
        return MountObservation(ok=False, forward_ratio=ratio)
    base = prior if prior is not None else default_track_model(tcfg)
    base = TrackModel(floor_coef=np.array(base.floor_coef, dtype=np.float64), floor_range=base.floor_range,
                      center=base.center, yaw=0.0 if prior is None else base.yaw,
                      curvature=0.0 if prior is None else base.curvature, rail_offset=base.rail_offset)
    fit = _fit_floor(P, tcfg, base)
    if fit is None:
        return MountObservation(ok=False, forward_ratio=ratio)
    coef, frange, _, _ = fit
    model = TrackModel(floor_coef=coef, floor_range=frange, center=base.center, yaw=base.yaw,
                       curvature=base.curvature, rail_offset=base.rail_offset)
    if float(model.floor_z(0.0)) > -0.3:
        return MountObservation(ok=False, forward_ratio=ratio)       # the "bed" is not below the sensor
    rails = estimate_rails(P, model, tcfg, base.center, prior)
    if rails.score < min_rail_score or not np.isfinite(rails.cant):
        return MountObservation(ok=False, rail_score=rails.score, forward_ratio=ratio)
    roll = -np.arctan2(rails.cant, tcfg.rails_spacing)
    slope = float(coef[-2])                                          # dz/dX of the bed at X = 0
    pitch = float(np.arctan(slope))
    yaw = -float(np.arctan(rails.tan_yaw)) if rails.tan_yaw is not None else float("nan")
    height = -float(model.floor_z(0.0) + rails.rail_offset)
    return MountObservation(ok=True, rail_score=float(rails.score), roll=float(roll), pitch=pitch, yaw=yaw,
                            height=height, lateral=float(rails.center), forward_ratio=ratio)


@dataclass
class MountCalibration:
    """Current state of the calibration, as reported in the status JSON (``mount``)."""
    R: np.ndarray = field(default_factory=lambda: np.eye(3))
    status: str = "pending"         # pending | provisional | ok | identity | fallback | disabled
    orientation: str = "configured"  # 'configured' or the adopted axis mapping, e.g. 'forward=+x left=+y up=+z'
    orientation_confirmed: bool = False  # an observed/adopted mapping; distinct from unfinished tilt calibration
    roll_deg: float = 0.0
    pitch_deg: float = 0.0
    yaw_deg: float = 0.0
    height: Optional[float] = None
    lateral: Optional[float] = None
    frames_used: int = 0
    drift_deg: float = 0.0          # residual tilt seen by the monitor after freezing
    message: str = ""
    orientation_conflict: bool = False  # reliable startup evidence contradicts the current mapping

    def to_dict(self) -> dict:
        return {
            "status": self.status, "orientation": self.orientation,
            "orientation_confirmed": bool(self.orientation_confirmed),
            "roll_deg": round(self.roll_deg, 2), "pitch_deg": round(self.pitch_deg, 2),
            "yaw_deg": round(self.yaw_deg, 2),
            "height": None if self.height is None else round(self.height, 2),
            "lateral": None if self.lateral is None else round(self.lateral, 2),
            "frames_used": int(self.frames_used), "drift_deg": round(self.drift_deg, 2),
            "message": self.message,
            "orientation_conflict": self.orientation_conflict,
        }


class MountCalibrator:
    """Online mount calibration: observe the first frames, freeze a correction, monitor drift."""

    def __init__(self, cfg: CalibrationConfig, tcfg: TrackConfig):
        self.cfg = cfg
        self.tcfg = tcfg
        self.state = MountCalibration(status="pending" if cfg.enabled else "disabled",
                                      orientation_confirmed=not cfg.enabled)
        self._R_orient = np.eye(3)
        self._R_tilt = np.eye(3)
        self._canonical_axes = False  # new directional-history recovery only
        self._orient_votes: dict = {}
        self._orient_samples: dict = {}  # valid candidate observations for newly recoverable axis permutations
        self._config_passed = False
        self._obs: List[tuple] = []      # spaced observations for the final tilt: (roll, pitch, yaw, height, lateral)
        self._recent: List[tuple] = []   # the first observations, for the provisional tilt
        self._provisional_done = False
        self._since_obs = 0
        self._applied = (0.0, 0.0, 0.0)  # rad: the tilt part of the current correction (roll, pitch, yaw)
        self._checks: List[tuple] = []   # drift monitor: residual (roll, pitch) of the last checks
        self.last_change_deg = 0.0       # how far the last correction change rotated the cloud
        self.last_change_orientation = False   # the last change adopted a new axis orientation
        self._refine_run = 0             # spaced observations in a row with the refinement condition
        self._refines = 0                # refinements made
        self._ref_raw: Optional[List[float]] = None   # rad: raw medians (roll, pitch, yaw) behind the applied provisional / refined tilt
        self._frames = 0
        self._frozen = not cfg.enabled
        self._since_check = 0
        self._candidates = orientation_candidates()
        self._scan_axis: Optional[np.ndarray] = None  # a physical scanner axis does not change between startup frames
        self._forward_axis: Optional[np.ndarray] = None
        self._directional_up: Optional[np.ndarray] = None

    # ------------------------------------------------------------------
    @property
    def R(self) -> np.ndarray:
        return self.state.R

    @property
    def frozen(self) -> bool:
        return self._frozen

    def directional_startup_history(self, xyz: np.ndarray, ring: Optional[np.ndarray]) -> bool:
        """A first-frame ring-free up conflict needs the correct startup state.

        This does not opt existing upright/yaw recoveries into history replay.
        The caller uses the existing owned four-frame / 32-MiB startup buffer.
        """
        if (self._frames or self._config_passed or not self.cfg.enabled
                or not self.cfg.search_orientations or not self.cfg.keep_up_axis or ring is not None):
            return False
        if self._forward_axis is None:
            self._forward_axis, self._directional_up = directional_axes(xyz)
        min_z = np.cos(np.radians(self.cfg.max_tilt_deg)) ** 2
        return (self._directional_up is not None
                and abs(float(self.R[2] @ self._directional_up)) < min_z)

    def apply(self, xyz: np.ndarray) -> np.ndarray:
        """The cloud in the corrected vehicle frame (the same array when the correction is the identity)."""
        R = self.state.R
        if np.allclose(R, np.eye(3), atol=1e-9):
            return xyz
        if self._canonical_axes:
            # A composed permutation+tilt changes float32 dot-product order.
            # Restore canonical XYZ before tilt so remounting cannot perturb
            # geometric thresholds or the later calibration/tracking history.
            columns = np.argmax(np.abs(self._R_orient), axis=1)
            signs = self._R_orient[np.arange(3), columns].astype(np.float32)
            oriented = np.ascontiguousarray(xyz[:, columns] * signs, dtype=np.float32)
            if np.allclose(self._R_tilt, np.eye(3), atol=1e-9):
                return oriented
            return (oriented @ self._R_tilt.T.astype(np.float32)).astype(np.float32, copy=False)
        return (xyz @ R.T.astype(np.float32)).astype(np.float32, copy=False)

    def _set_tilt(self, roll: float, pitch: float, yaw: float) -> bool:
        """Compose the orientation with a tilt (rad); True when the correction changed."""
        self._R_tilt = rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)
        R = self._R_tilt @ self._R_orient
        d = R @ self.state.R.T
        self.last_change_deg = float(np.degrees(np.arccos(np.clip((np.trace(d) - 1.0) / 2.0, -1.0, 1.0))))
        self.last_change_orientation = False
        self.state.R = R
        self._applied = (roll, pitch, yaw)
        self.state.roll_deg, self.state.pitch_deg, self.state.yaw_deg = (float(np.degrees(v)) for v in (roll, pitch, yaw))
        return self.last_change_deg > 1e-6

    @staticmethod
    def _medians(obs: List[tuple]):
        a = np.asarray(obs, dtype=np.float64)
        yaws = a[:, 2][np.isfinite(a[:, 2])]
        return (float(np.median(a[:, 0])), float(np.median(a[:, 1])), float(np.median(yaws)) if yaws.size else 0.0,
                float(np.median(a[:, 3])), float(np.median(a[:, 4])))

    # ------------------------------------------------------------------
    def _search_orientation(self, xyz_cfg: np.ndarray, axis: Optional[np.ndarray] = None,
                            forward: Optional[np.ndarray] = None) -> Optional[tuple]:
        """Index and observation of the best passing orientation in the configured frame."""
        step = max(1, int(np.ceil(len(xyz_cfg) / 60000)))
        sample = xyz_cfg[::step]  # once, before any rotation or candidate mask (S3)
        best, best_ob, best_score = None, None, 0.0
        min_z = np.cos(np.radians(self.cfg.max_tilt_deg)) ** 2
        for k, Rc in enumerate(self._candidates):
            if k == 0:
                continue
            if axis is None and self.cfg.keep_up_axis and abs(Rc[2, 2]) != 1.0:
                continue
            if axis is not None and abs(float(Rc[2] @ axis)) < min_z:
                continue
            if forward is not None and float(Rc[0] @ forward) < min_z:
                continue
            ob = observe_mount(sample @ Rc.T, self.tcfg, None, self.cfg.min_rail_score,
                               point_weight=step)
            if ob.ok and ob.rail_score > best_score:
                best, best_ob, best_score = k, ob, ob.rail_score
        return (best, best_ob) if best is not None else None

    def update(self, xyz_cfg: np.ndarray, xyz_cur: np.ndarray, track: Optional[TrackModel],
               periods: int = 1, ring: Optional[np.ndarray] = None) -> bool:
        """Feed one frame (``xyz_cfg``: the configured vehicle frame; ``xyz_cur``: the same cloud
        under the current correction; ``track``: the detector's current model). Returns True
        when the correction changed (the caller re-seeds its track model). ``periods``: nominal
        frame periods per processed frame at the input rate (the Detector passes 1 at 10 Hz, 2
        at 5 Hz); with ``time_cadence`` the spacing, the drift check period and the give-up
        limit count them instead of frames (else it is ignored)."""
        cfg = self.cfg
        if not cfg.enabled:
            return False
        step = max(1, int(periods)) if cfg.time_cadence else 1
        self._frames += step
        if self._frozen:
            if cfg.monitor_period > 0:
                self._since_check += step
                if self._since_check >= cfg.monitor_period:
                    self._since_check = 0
                    ob = observe_mount(xyz_cur, self.tcfg, track, cfg.min_rail_score)
                    if ob.ok:
                        self._checks = (self._checks + [(ob.roll, ob.pitch)])[-max(cfg.drift_window, 1):]
                        c = np.asarray(self._checks)
                        self.state.drift_deg = float(np.degrees(np.max(np.abs(np.median(c, axis=0)))))
                        drifting = len(self._checks) >= max(cfg.drift_window // 2, 1) and self.state.drift_deg > cfg.drift_warn_deg
                        if drifting:
                            self.state.message = (f"mount drift: residual tilt {self.state.drift_deg:.1f} deg "
                                                  f"(> {cfg.drift_warn_deg}, median of the last {len(self._checks)} checks) "
                                                  f"since calibration")
                        elif self.state.message.startswith("mount drift"):
                            self.state.message = "drift back within bounds"
            return False

        spacing = max(cfg.obs_spacing, 1)
        if self._provisional_done and self._config_passed and self._obs and self._since_obs + step < spacing:
            # between two spaced observations the frame is not needed: observing every frame cost
            # 10-15 ms for the first ~20 s of every recording (review 23.09). The spacing counts
            # frames (with time_cadence: frame periods); the observation is taken on the first
            # frame with a rail pair after it.
            self._since_obs += step
            return self._finish(False)
        if cfg.keep_up_axis and not self._config_passed and self._scan_axis is None:
            self._scan_axis = scan_axis(xyz_cfg, ring)
        if not self._config_passed and self._forward_axis is None:
            self._forward_axis, self._directional_up = directional_axes(xyz_cfg)
        axis = None
        forward = None
        if not self._config_passed:
            forward = self._forward_axis
            if cfg.keep_up_axis:
                axis = self._scan_axis if self._scan_axis is not None else self._directional_up
        # The existing tilt limit is per roll/pitch axis. A valid combined
        # tilt can exceed max_tilt_deg relative to vertical: cos(roll)*cos(pitch).
        min_z = np.cos(np.radians(cfg.max_tilt_deg)) ** 2
        axis_ok = axis is None or abs(float(self.R[2] @ axis)) >= min_z
        axis_ok = axis_ok and (forward is None or float(self.R[0] @ forward) >= min_z)
        ob = (observe_mount(xyz_cur, self.tcfg, track, cfg.min_rail_score)
              if axis_ok else MountObservation(ok=False))
        if not axis_ok:
            self.state.orientation_conflict = True
            self.state.message = "scan coverage contradicts configured axes; orientation unconfirmed"
            # Channel geometry supplies the missing constraint that previously
            # let cable trays on a wall beat the real rail bed. It supplies no
            # forward direction/sign: all candidates still need bed/rail proof
            # and the existing orientation_votes observations.
        changed = False
        # --- 1. orientation: only if the current mapping fails and another one passes repeatedly
        if not ob.ok and cfg.search_orientations and not self._config_passed:
            candidate = self._search_orientation(xyz_cfg, axis, forward)
            if candidate is not None:
                k, observation = candidate
                # S3 bounds the candidate loop, not the winning mount's final
                # validation. Preserve the original full-cloud observation for
                # tilt cadence: a strided score must not change real STOP onset.
                observation = observe_mount(xyz_cfg @ self._candidates[k].T,
                                            self.tcfg, None, cfg.min_rail_score)
                if not observation.ok:
                    return self._finish(False)
                if axis is not None:
                    self.state.orientation_conflict = True
                    self.state.message = "alternative orientation awaiting confirmation"
                    if abs(float(axis[2])) < min_z:
                        # These are already observations in the proposed correct
                        # frame. Discarding the voting frames would delay the
                        # provisional tilt and real STOP by two frames (B4).
                        samples = self._orient_samples.setdefault(k, [])
                        samples.append((self._frames, (observation.roll, observation.pitch, observation.yaw,
                                                       observation.height, observation.lateral)))
                self._orient_votes[k] = self._orient_votes.get(k, 0) + 1
                if self._orient_votes[k] >= cfg.orientation_votes:
                    self._R_orient = self._candidates[k]
                    self.state.R = self._R_orient.copy()
                    self.state.orientation = axis_label(self._R_orient)
                    self.state.message = f"sensor orientation found from the data: {self.state.orientation}"
                    self.last_change_deg = 90.0
                    self.last_change_orientation = True
                    self._obs.clear()
                    self._recent.clear()
                    self._since_obs = 0
                    samples = self._orient_samples.get(k, [])
                    if samples:
                        self._recent.extend(sample for _, sample in samples)
                        last_observed = None
                        for frame, sample in samples:
                            if last_observed is None or frame - last_observed >= spacing:
                                self._obs.append(sample)
                                last_observed = frame
                        self._since_obs = self._frames - last_observed
                    self._config_passed = True          # stop searching
                    self.state.orientation_conflict = False
                    self.state.orientation_confirmed = True
                    if samples:
                        self._finish(True)
                        # A tilt may also be due on this frame; the caller must
                        # still treat the total change as an axis permutation.
                        self.last_change_deg = 90.0
                        self.last_change_orientation = True
                    return True
        if ob.ok:
            self._config_passed = True
            self.state.orientation_conflict = False
            self.state.orientation_confirmed = True
            # absolute estimate = the tilt already applied + the residual seen through it (small angles)
            a_r, a_p, a_y = self._applied
            est = (ob.roll + a_r, ob.pitch + a_p, (ob.yaw + a_y) if np.isfinite(ob.yaw) else float("nan"),
                   ob.height, ob.lateral)
            if not self._provisional_done:
                self._recent.append(est)
            self._since_obs += step
            if not self._obs or self._since_obs >= max(cfg.obs_spacing, 1):
                self._obs.append(est)
                self._since_obs = 0
                changed = self._refine() or changed
        return self._finish(changed)

    def _final_tilt(self, obs: List[tuple]):
        """The tilt the final calibration sets from ``obs``: medians, roll / pitch below
        ``apply_min_deg`` and yaw below ``min_yaw_deg`` set to 0. Also height and lateral."""
        cfg = self.cfg
        roll, pitch, yaw, height, lateral = self._medians(obs)
        if abs(roll) < np.radians(cfg.apply_min_deg):
            roll = 0.0
        if abs(pitch) < np.radians(cfg.apply_min_deg):
            pitch = 0.0
        if abs(yaw) < np.radians(cfg.min_yaw_deg):
            yaw = 0.0
        return roll, pitch, yaw, height, lateral

    def _refine(self) -> bool:
        """``refine_min_deg`` (25.09): while a provisional tilt is applied, the spaced
        observations so far replace it once they are as many as the provisional ones and say
        something at least ``refine_min_deg`` different in roll or pitch (the first consecutive
        frames can see one canted stretch of rail). True when the correction changed.

        Safety review of 26.09: comparing the zeroed target with the applied tilt made every
        crossing of ``apply_min_deg`` a jump of at least 0.75 deg, so a median hovering there
        flipped the correction (and re-seeded the track model) again and again (4 times on
        roundT_doubleT, +3 deg pitch). Now the condition must hold on ``refine_confirm_obs``
        spaced observations in a row (a one-off move of the median, or a bimodal one when an
        obstacle fools the rail observation, is not applied) and at most ``refine_max``
        refinements are made. The opt-in ``refine_raw_trigger`` (tried, not shipped) triggers
        each axis by its RAW median moving ``refine_min_deg`` from the raw median behind its
        applied value and keeps the other axes: it kept noise-level provisional values the final
        would zero."""
        cfg = self.cfg
        if (cfg.refine_min_deg <= 0 or self.state.status != "provisional"
                or len(self._obs) < max(cfg.provisional_frames, 1) or len(self._obs) >= cfg.frames):
            return False
        limit = int(getattr(cfg, "refine_max", 0))
        if limit > 0 and self._refines >= limit:
            return False
        roll, pitch, yaw, _, _ = self._final_tilt(self._obs)
        max_t = np.radians(cfg.max_tilt_deg)
        if abs(roll) > max_t or abs(pitch) > max_t:
            return False
        applied = self._applied
        raw_trigger = bool(getattr(cfg, "refine_raw_trigger", False))
        if raw_trigger:
            raw = self._medians(self._obs)[:3]
            ref = self._ref_raw if self._ref_raw is not None else list(applied)
            step = np.radians(cfg.refine_min_deg)
            moved = [abs(r - f) >= step for r, f in zip(raw, ref)]
            roll, pitch, yaw = (t if m else a for t, m, a in zip((roll, pitch, yaw), moved, applied))
            due = max(abs(roll - applied[0]), abs(pitch - applied[1]), abs(yaw - applied[2])) > 1e-9
        else:
            due = not np.degrees(max(abs(roll - applied[0]), abs(pitch - applied[1]))) < cfg.refine_min_deg
        self._refine_run = self._refine_run + 1 if due else 0
        if not due or self._refine_run < max(1, int(getattr(cfg, "refine_confirm_obs", 1))):
            return False
        self._refine_run = 0
        self._refines += 1
        if raw_trigger:
            new = (roll, pitch, yaw)
            self._ref_raw = [r if abs(n - a) > 1e-9 else f for r, f, n, a in zip(raw, ref, new, applied)]
        changed = self._set_tilt(roll, pitch, yaw)
        self.state.message = (f"provisional tilt refined from {len(self._obs)} spaced observations: roll "
                              f"{self.state.roll_deg:+.2f}, pitch {self.state.pitch_deg:+.2f} deg "
                              f"(final after {cfg.frames} observations)")
        return changed

    def _finish(self, changed: bool) -> bool:
        """The provisional tilt, the final tilt and the no-rail fallback, once the frame's
        observation (if any) is recorded."""
        cfg = self.cfg
        max_t = np.radians(cfg.max_tilt_deg)
        # --- 2a. provisional tilt: only a clearly tilted rig is corrected before the final window
        if not self._provisional_done and len(self._recent) >= cfg.provisional_frames:
            self._provisional_done = True
            roll, pitch, yaw, _, _ = self._medians(self._recent)
            self._ref_raw = [roll, pitch, yaw]
            if (np.degrees(max(abs(roll), abs(pitch))) >= cfg.provisional_min_deg
                    and abs(roll) <= max_t and abs(pitch) <= max_t):
                yaw = yaw if abs(yaw) >= np.radians(cfg.min_yaw_deg) else 0.0
                if cfg.provisional_per_axis:
                    # 25.09: only the clearly tilted axis; the other one is at the noise of 5 frames
                    roll = roll if np.degrees(abs(roll)) >= cfg.provisional_min_deg else 0.0
                    pitch = pitch if np.degrees(abs(pitch)) >= cfg.provisional_min_deg else 0.0
                changed = self._set_tilt(roll, pitch, yaw)
                self.state.status = "provisional"
                self.state.message = (f"provisional tilt: roll {self.state.roll_deg:+.2f}, pitch {self.state.pitch_deg:+.2f} deg "
                                      f"(final after {cfg.frames} observations)")
        # --- 2b. final tilt: medians over spaced frames with a rail pair
        if len(self._obs) >= cfg.frames:
            roll, pitch, yaw, height, lateral = self._medians(self._obs)
            if abs(roll) > max_t or abs(pitch) > max_t:
                self.state.status = "fallback"
                self.state.message = (f"implausible tilt (roll {np.degrees(roll):.1f}, pitch "
                                      f"{np.degrees(pitch):.1f} deg): configured mapping kept")
                self._frozen = True
                return self._set_tilt(0.0, 0.0, 0.0) or changed     # drop a provisional tilt too
            if abs(roll) < np.radians(cfg.apply_min_deg):
                roll = 0.0
            if abs(pitch) < np.radians(cfg.apply_min_deg):
                pitch = 0.0
            if abs(yaw) < np.radians(cfg.min_yaw_deg):
                yaw = 0.0
            a_r, a_p, a_y = self._applied
            if (cfg.keep_within_deg > 0 and self.state.status == "provisional" and abs(yaw - a_y) < 1e-12
                    and np.degrees(max(abs(roll - a_r), abs(pitch - a_p))) < cfg.keep_within_deg):
                # 25.09: the final confirms the applied provisional tilt within its own error:
                # keep it, so the track model is not re-seeded for a change of a few hundredths
                pass
            else:
                changed = self._set_tilt(roll, pitch, yaw) or changed
            self.state.height, self.state.lateral = height, lateral
            self.state.frames_used = len(self._obs)
            identity = np.allclose(self.state.R, np.eye(3), atol=1e-9)
            self.state.status = "identity" if identity else "ok"
            if not self.state.message or self.state.message.startswith("provisional"):
                self.state.message = ("configured mapping confirmed" if identity else
                                      f"tilt corrected: roll {self.state.roll_deg:+.2f}, pitch {self.state.pitch_deg:+.2f}, "
                                      f"yaw {self.state.yaw_deg:+.2f} deg")
            self._frozen = True
        elif self._frames >= cfg.max_frames:
            kept = "provisional correction kept" if self.state.status == "provisional" else "configured mapping kept"
            self.state.status = "fallback"
            self.state.message = (f"no rail pair in {self._frames} frames: {kept}"
                                  if not self._obs else f"only {len(self._obs)} observations with a rail pair: {kept}")
            self._frozen = True
        return changed
