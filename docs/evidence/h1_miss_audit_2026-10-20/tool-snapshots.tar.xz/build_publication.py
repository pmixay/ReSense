#!/usr/bin/env python3
"""Offline publication projection of existing captures. Never calls the detector or Git.

Commands: relocate (preserve production bytes), build (compact evidence).
Requires NumPy only to read the existing dictionary/ndarray pickle captures.
"""
import argparse
import base64
import collections
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import shutil
import struct

import numpy as np

HERE = Path(__file__).resolve().parent
WORK = Path('/tmp/opencode/h1-miss-audit')
VM_ONLY = WORK / 'vm-only'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(part)
    return h.hexdigest()


def write_json(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def ieee_hash(value):
    # Same documented exact canonical encoding as ieee-exact-check.json.
    h = hashlib.sha256()
    def push(tag, data): h.update(tag + struct.pack('<Q', len(data)) + data)
    def visit(v):
        if isinstance(v, np.ndarray):
            push(b'array', str((v.dtype.str, v.shape)).encode()); push(b'bytes', v.tobytes())
        elif isinstance(v, np.generic): push(b'np', v.dtype.str.encode() + v.tobytes())
        elif isinstance(v, float): push(b'f64', struct.pack('<d', v))
        elif isinstance(v, dict):
            push(b'dict', str(len(v)).encode())
            for key in sorted(v): visit(key); visit(v[key])
        elif isinstance(v, (list, tuple)):
            push(b'list' if isinstance(v, list) else b'tuple', str(len(v)).encode())
            for x in v: visit(x)
        else: push(type(v).__name__.encode(), repr(v).encode())
    visit(value)
    return h.hexdigest()


def pack(v):
    """Lossless, stdlib-decodable ndarray/scalar encoding; JSON floats are unrounded."""
    if isinstance(v, np.ndarray):
        return {'__ndarray__': True, 'dtype': v.dtype.str, 'shape': list(v.shape),
                'base64': base64.b64encode(v.tobytes(order='C')).decode('ascii')}
    if isinstance(v, np.generic):
        return {'__numpy_scalar__': v.dtype.str, 'base64': base64.b64encode(v.tobytes()).decode('ascii')}
    if isinstance(v, float) and not math.isfinite(v):
        return {'__float64_bits__': struct.pack('<d', v).hex()}
    if isinstance(v, tuple): return {'__tuple__': [pack(x) for x in v]}
    if isinstance(v, list): return [pack(x) for x in v]
    if isinstance(v, dict): return {str(k): pack(x) for k, x in v.items()}
    return v


def stream(path):
    with gzip.open(path, 'rb') as f:
        while True:
            try: yield pickle.load(f)
            except EOFError: break


def relocate():
    assert WORK.is_dir() and HERE.name == 'h1_miss_audit_2026-10-20'
    assert not (HERE / 'storage-map.json').exists()
    VM_ONLY.mkdir(exist_ok=True)
    receipt_names = ['SHA256SUMS', 'artifact-manifest.json', 'archive-manifest.json', 'checksum-verification.json']
    receipts = {name: dict(sha256=sha(HERE / name), bytes=(HERE / name).stat().st_size)
                for name in receipt_names}
    production = json.loads((HERE / 'artifact-manifest.json').read_text())['files']
    operations = []
    for name in ['README.md', 'PROTOCOL.md']:
        source = HERE / name
        dest = VM_ONLY / (source.stem + '.production' + source.suffix)
        assert not dest.exists() and sha(source) == production[name]['sha256']
        shutil.copyfile(source, dest)
        assert sha(dest) == sha(source)
        operations.append(dict(operation='preserve_original_before_publication_edit', original_name=name,
            old_path=str(source), new_path=str(dest), sha256=sha(dest), bytes=dest.stat().st_size,
            historical_checksum_resolution=str(dest), current_path_is_publication_edition=True))
    for name in ['raw-captures.tar.gz', 'miss-snapshots.pkl.gz', 'report-initial.json', 'inspection.json']:
        source, dest = HERE / name, VM_ONLY / name
        assert source.is_file() and not dest.exists()
        before = sha(source); size = source.stat().st_size
        assert before == production[name]['sha256']
        source.rename(dest)
        assert dest.stat().st_size == size and sha(dest) == before and not source.exists()
        operations.append(dict(operation='move_without_deletion', original_name=name, old_path=str(source),
            new_path=str(dest), sha256=before, bytes=size, historical_checksum_resolution=str(dest)))
    storage = dict(schema='resense-h1-publication-storage-map-v1', replay_repeated=False, git_operations=False,
        vm_only_directory=str(VM_ONLY), operations=operations, original_production_receipts=receipts,
        receipt_semantics='Immutable production record. Resolve historical names through operations; do not rewrite SHA256SUMS.',
        retained_vm_capture_files={name: dict(path=str(WORK / name), sha256=sha(WORK / name),
            bytes=(WORK / name).stat().st_size) for name in ['plain.pkl.gz', 'traced.pkl.gz', 'traced-attempt1.pkl.gz']},
        retained_source_archive=dict(path=str(HERE / 'source-tools-input-metadata.tar.gz'),
            sha256=sha(HERE / 'source-tools-input-metadata.tar.gz'), published=False),
        cache_policy='Original decoded/source caches remain in place on the evaluation VM; not published.')
    for name, info in receipts.items(): assert sha(HERE / name) == info['sha256']
    write_json(HERE / 'storage-map.json', storage)
    print(json.dumps(dict(moved=[(r['original_name'], r['bytes']) for r in operations
                                 if r['operation'] == 'move_without_deletion'], preserved_receipts=receipts), indent=2))


def build():
    report = json.loads((HERE / 'report.json').read_text())
    ieee = json.loads((HERE / 'ieee-exact-check.json').read_text())
    manifest = json.loads((HERE / 'manifest-before.json').read_text())
    archive_manifest = json.loads((HERE / 'archive-manifest.json').read_text())
    core = json.loads((HERE / 'core-rule-checks.json').read_text())
    source_rows = {r['k']: r for r in report['matching']}
    misses = {r['k']: r for r in report['all_misses']}
    cache = Path('/tmp/opencode/r3-h1/baseline/cache/roundT_squareT_pressureGate_squareT')
    baseline = Path(str(cache) + '_baseline.json')
    icp_path = Path('/tmp/opencode/r3-h1/baseline/icp_roundT_squareT_pressureGate_squareT.json')
    for p in [baseline, icp_path, cache / 'meta.json']:
        assert sha(p) == manifest['inputs'][str(p)]
    capture_hashes = {}
    for mode in ['plain', 'traced']:
        path = WORK / (mode + '.pkl.gz')
        capture_hashes[mode] = sha(path)
        assert capture_hashes[mode] == archive_manifest['raw']['members'][path.name]['sha256']
    visible, miss_records, full_records = [], [], []
    for rec in stream(WORK / 'traced.pkl.gz'):
        k, result = rec['k'], rec['frame_result']
        assert ieee_hash(result) == ieee['rows'][k]['ieee_raw_sha256']
        hashes = dict(k=k, full_snapshot_ieee_sha256=ieee_hash(rec),
            frame_result_ieee_sha256=ieee['rows'][k]['ieee_raw_sha256'], legacy_raw_hash=rec['raw_hash'],
            whole_processed_cloud=dict(dtype=result['xyz'].dtype.str, shape=list(result['xyz'].shape),
                byte_sha256=hashlib.sha256(result['xyz'].tobytes()).hexdigest(),
                ieee_sha256=ieee_hash(result['xyz']), published=False))
        full_records.append(hashes)
        if k not in source_rows: continue
        first = rec['input_target']['first_index']
        placement = dict(rounded_evaluator_input=rec['info'], exact=rec['exact'], metadata=rec['metadata'],
            injected_input_fingerprint=rec['input_hash'], fixed_previous_latency=rec['previous_latency_fixed'])
        output = {key: value for key, value in result.items() if key not in ['xyz', 'corridor_idx', 'candidates']}
        support = dict(input_target=rec['input_target'], processed_target=result['xyz'][first:],
            target_corridor_indices=result['corridor_idx'][result['corridor_idx'] >= first])
        visible.append(dict(k=k, placement=placement, output=output, target_support=support,
            matching=source_rows[k], source_snapshot=hashes,
            omitted_fields=dict(whole_xyz=hashes['whole_processed_cloud'],
                corridor_idx_ieee_sha256=ieee_hash(result['corridor_idx']),
                candidates_ieee_sha256=ieee_hash(result['candidates']))))
        if k in misses:
            miss_records.append(dict(k=k, attribution=misses[k], branch_events=rec['events'],
                candidates=result['candidates'], tracker_states=rec['tracks'], thin=rec['thin'],
                low_height=rec['low_height'], target_support_ref=k,
                core_checks=[c for c in core if c['k'] == k], source_snapshot=hashes))
    assert len(full_records) == 340 and len(visible) == 177 and len(miss_records) == 63
    bundle = dict(schema='resense-h1-portable-evidence-v1', source_commit=report['source_commit'],
        derivation='Projection of retained successful replay captures; no replay/detector/Git operation.',
        scope='Detector-baseline-axis injection; no independent in-gauge truth.',
        omitted='Whole raw/processed scene clouds are VM-only. Target points and candidate-local support are included.',
        encoding='ndarray dtype.str + shape + base64 C-order bytes; nonfinite float64 IEEE bits; tuple tag; no rounding.',
        source_capture_sha256=capture_hashes,
        full_snapshot_hash_algorithm='package_audit.py ieee_hash / build_publication.py ieee_hash; every non-timing field retained in VM capture',
        placement_inputs=dict(icp=json.loads(icp_path.read_text()), baseline_rows=json.loads(baseline.read_text()),
            frame_metadata=json.loads((cache / 'meta.json').read_text()), flags=dict(obj=[.3,.3,2.8], start=150, d0=230., end=340)),
        full_snapshot_records=full_records, visible_rows=visible, miss_snapshots=miss_records,
        registered_controls=report['controls'], effective_config=json.loads((HERE / 'effective-config.json').read_text()))
    out_path = HERE / 'publication-evidence.json.gz'
    with out_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=9, mtime=0) as compressed:
            encoded = json.JSONEncoder(separators=(',', ':'), ensure_ascii=False, allow_nan=False)
            for chunk in encoded.iterencode(pack(bundle)): compressed.write(chunk.encode('utf-8'))
    # Independent disk round-trip; projection hashes checked against original target data.
    decoded = json.loads(gzip.decompress(out_path.read_bytes()))
    assert len(decoded['visible_rows']) == 177 and len(decoded['miss_snapshots']) == 63
    write_json(HERE / 'publication-build-checks.json', dict(replay_repeated=False, git_operations=False,
        visible_rows=177, miss_snapshots=63, full_snapshot_hashes=340,
        branch_events=sum(len(r['branch_events']) for r in miss_records),
        candidate_local_support_points=sum(len(e.get('state', {}).get('blob', {}).get('pts', []))
            for r in miss_records for e in r['branch_events']),
        compressed_bytes=out_path.stat().st_size, sha256=sha(out_path),
        source_captures_verified_against_production_archive_manifest=True,
        all_frame_result_ieee_hashes_verified=True, whole_clouds_published=False,
        storage_map_sha256=sha(HERE / 'storage-map.json')))
    print('BUILT', out_path.name, out_path.stat().st_size, sha(out_path), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('command', choices=['relocate', 'build'])
    args = parser.parse_args(); {'relocate': relocate, 'build': build}[args.command]()
