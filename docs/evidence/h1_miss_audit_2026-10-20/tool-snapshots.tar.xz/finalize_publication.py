#!/usr/bin/env python3
"""Publication-only receipts and exact allowlist; no detector/replay/Git commands."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

from verify_publication import HERE, check_data, check_vm, checksum_check, load_bundle, privacy_check, sha


def write(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')


def main():
    bundle, text = load_bundle()
    portable = check_data(bundle)
    vm = check_vm(bundle)
    history = vm.pop('historical_receipts')
    write(HERE / 'historical-receipt-verification.json', history)
    names = [
        'README.md', 'PUBLICATION.md', 'PROTOCOL.md', 'ACCEPTANCE.json', 'report.json',
        'ieee-exact-check.json', 'core-rule-checks.json', 'effective-config.json', 'raw-examples.png',
        'publication-evidence.json.gz', 'publication-build-checks.json', 'publication-checks.json',
        'storage-map.json', 'historical-receipt-verification.json',
        'SHA256SUMS', 'artifact-manifest.json', 'archive-manifest.json', 'checksum-verification.json',
        'manifest-before.json', 'manifest-after-replay.json', 'manifest-final.json', 'runtime-libraries.json',
        'freeze-before.json', 'audit.py', 'verify_audit.py', 'build_publication.py',
        'verify_publication.py', 'finalize_publication.py']
    assert len(names) == len(set(names))
    privacy = privacy_check([n for n in names if n != 'publication-checks.json'], text)
    write(HERE / 'publication-checks.json', dict(schema='resense-h1-publication-checks-v1',
        portable=portable, vm_projection=vm, privacy=privacy,
        original_production_checksums_resolved=33, replay_repeated=False, git_operations=False,
        publication_has_full_raw_capture=False))
    payload = {name: dict(bytes=(HERE / name).stat().st_size, sha256=sha(HERE / name)) for name in sorted(names)}
    original_names = set(json.loads((HERE / 'artifact-manifest.json').read_text())['files'])
    historical = ['SHA256SUMS', 'artifact-manifest.json', 'archive-manifest.json', 'checksum-verification.json',
                  'ACCEPTANCE.json', 'manifest-before.json', 'manifest-after-replay.json', 'manifest-final.json',
                  'runtime-libraries.json', 'freeze-before.json']
    metadata = ['publication-manifest.json', 'SHA256SUMS-publication']
    excluded = {p.name: dict(bytes=p.stat().st_size, role='VM-only; not intended for publication')
        for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in set(names + metadata)}
    manifest = dict(schema='resense-h1-publication-manifest-v1', status='PREPARED_NOT_UPLOADED',
        source_commit=bundle['source_commit'], replay_repeated=False, git_operations=False,
        payload_files=payload, metadata_files=metadata, intended_file_count=len(names) + len(metadata),
        payload_bytes=sum(v['bytes'] for v in payload.values()), maximum_file_bytes=max(v['bytes'] for v in payload.values()),
        historical_production_records=historical,
        historical_path_semantics='Resolve old production names via storage-map.json only on VM; SHA256SUMS remains unchanged.',
        original_production_sha256sums_sha256=history['original_sha256sums_sha256'],
        integrity='SHA256SUMS-publication covers every intended file except itself, including this manifest.',
        no_whole_clouds_published=True, full_raw_capture_published=False,
        compressed_evidence='publication-evidence.json.gz', full_snapshot_hashes=340,
        visible_rows=177, miss_snapshots=63, actual_captured_miss_branch_events=portable['branch_events'],
        other_current_directory_files_excluded=excluded,
        moved_vm_only_files=[op['original_name'] for op in json.loads((HERE / 'storage-map.json').read_text())['operations']
                             if op['operation'] == 'move_without_deletion'])
    write(HERE / 'publication-manifest.json', manifest)
    with (HERE / 'SHA256SUMS-publication').open('x') as f:
        for name, item in payload.items(): f.write(item['sha256'] + '  ' + name + '\n')
        f.write(sha(HERE / 'publication-manifest.json') + '  publication-manifest.json\n')
    checks = checksum_check()
    privacy_check(names + metadata, text)
    verified = subprocess.run(['sha256sum', '-c', 'SHA256SUMS-publication'], cwd=HERE, capture_output=True, text=True)
    assert verified.returncode == 0, verified.stdout + verified.stderr
    # Prove the allowlisted set alone is sufficient, in isolated Python without site-packages.
    destination = Path('/tmp/opencode/h1-miss-audit/publication-portability-check')
    assert destination.parent.is_dir() and not destination.exists()
    destination.mkdir()
    for name in names + metadata:
        shutil.copyfile(HERE / name, destination / name)
    child = subprocess.run([sys.executable, '-I', '-S', str(destination / 'verify_publication.py')],
                           cwd=destination, capture_output=True, text=True)
    assert child.returncode == 0, child.stdout + child.stderr
    child_result = json.loads(child.stdout)
    assert child_result['data']['visible_rows_checked'] == 177
    assert child_result['data']['miss_branch_records'] == 63
    assert child_result['publication_checksums'] == checks
    write(Path('/tmp/opencode/h1-miss-audit/publication-standalone-verification.json'), dict(
        command=['python', '-I', '-S', 'verify_publication.py'], returncode=child.returncode,
        result=child_result, stdout_sha256=__import__('hashlib').sha256(child.stdout.encode()).hexdigest()))
    print(verified.stdout, end='')
    print('PUBLICATION_CHECKS', json.dumps(checks))
    print('ISOLATED_STDLIB_ONLY', child.returncode)
    print('HISTORICAL_PRODUCTION_RECEIPTS', len(history['rows']), 'MATCH')
    print('SHA256SUMS_PUBLICATION_SHA256', sha(HERE / 'SHA256SUMS-publication'))
    print('EXACT_INTENDED_FILES')
    for name in sorted(names + metadata): print(str((HERE / name).stat().st_size) + '\t' + name)


if __name__ == '__main__': main()
