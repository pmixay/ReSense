"""Second-method checks and final attribution from retained executed events.

No detector re-run, monkeypatch or counterfactual detector adjustment. The primary
label names the observed miss mechanism; upstream and final gates are both saved.
"""
import copy
import math
import statistics
from audit import *


def strict_json(path, value):
    def finite(x):
        x = js(x)
        if isinstance(x, float) and not math.isfinite(x):
            return repr(x)
        if isinstance(x, dict):
            return {k: finite(v) for k, v in x.items()}
        if isinstance(x, list):
            return [finite(v) for v in x]
        return x
    with path.open('x') as f:
        json.dump(finite(value), f, indent=2, allow_nan=False)
        f.write('\n')


def independent_match(detections, x, y):
    """Interval containment, separately written from abs-distance matching."""
    longitudinal = (2. if x < 200. / 3. else x * .03) + .15
    bounds = (x - longitudinal, x + longitudinal, y - 1.15, y + 1.15)
    return [d['id'] for d in detections
            if bounds[0] <= float(d['distance']) <= bounds[1]
            and bounds[2] <= float(d['center'][1]) <= bounds[3]]


def scalar_polygon(y, z, profile):
    # Horizontal-line intersections, rather than vectorised even/odd XOR.
    crossings = []
    for p, q in zip(profile, profile[1:] + profile[:1]):
        if min(p[1], q[1]) <= z < max(p[1], q[1]):
            crossings.append(p[0] + (z - p[1]) * (q[0] - p[0]) / (q[1] - p[1]))
    return sum(y < c for c in crossings) % 2 == 1


def core_check(e, events):
    s, result, line = e['state'], bool(e['returned']), e['line']
    c, g, b = s['cfg'], s['gauge'], s['blob']
    summary = dict(event=event_ref(e), result=result, n_raw=len(b['idx']), n_vox=b['n_vox'])
    size = np.ptp(b['pts'], axis=0)
    if line == 1032:
        passed = bool(g is not None and c['column_core_margin'] > 0
                      and size[0] <= c['column_core_max_footprint'] and size[1] <= c['column_core_max_footprint'])
        assert not passed and not result
        summary.update(branch='footprint_or_prerequisite', size=size)
    else:
        current = ((s['blob_frame_idx'] >= 0) & s['blob_in_gauge'] & s['blob_in_rail'])
        assert np.array_equal(current, s['current'])
        n_current = int(current.sum())
        summary['current_gauge_raw_returns'] = n_current
        if line == 1036:
            assert n_current < c['column_core_min_voxels'] and not result
            summary.update(branch='current_support_below_bar', required=c['column_core_min_voxels'])
        elif line == 1039:
            assert s['interval'] is None and not result
            intervals = [v for v in events if v.get('parent') == e['call'] and
                         v['function'] == 'FrameRays.collision_axis_interval']
            assert len(intervals) == 1
            v = intervals[0]; vs = v['state']
            assert v['returned'] is None
            summary.update(branch='no_axis_consistency_interval', interval_event=event_ref(v))
            if v['line'] == 470:
                near, local = vs['near'], vs['local']
                assert len(near) < 4 or len(local) < 2
                summary.update(interval_failure='insufficient_boundary_stations', near_count=len(near),
                               local_count=len(local), near_required=4, local_required=2)
            else:
                summary.update(interval_failure='unverified_detail', detail='return traced; prerequisite snapshot insufficient')
        elif line == 1045:
            interval = s['interval']; assert interval is not None
            curr_ids = np.flatnonzero(current)
            expected_keep = []
            for j in curr_ids:
                x = float(b['pts'][j, 0]); dy = float(s['blob_dy'][j]); h = float(s['blob_h'][j])
                q = x / 100.
                margin = g['edge_margin'] + c['column_core_margin'] + g['edge_margin_per_100m'] * q
                if g['edge_margin_per_100m2'] > 0:
                    margin += g['edge_margin_per_100m2'] * q * q
                ok = True
                for offset in interval:
                    residual = dy - offset
                    shifted = residual + (margin if residual > 0 else -margin if residual < 0 else 0.)
                    ok = ok and scalar_polygon(shifted, h, g['profile'])
                expected_keep.append(ok)
            expected_keep = np.array(expected_keep, dtype=bool)
            assert np.array_equal(expected_keep, s['keep'])
            retained = curr_ids[expected_keep]
            assert np.array_equal(b['idx'][retained], s['k'])
            n_vox = len(set(map(int, s['blob_inv'][retained])))
            heights = s['blob_h'][retained]
            height_span = float(np.ptp(heights)) if len(heights) else None
            bottom = float(heights.min()) if len(heights) else None
            passed = bool(len(retained) and n_vox >= c['column_core_min_voxels']
                          and height_span >= c['column_core_min_height'] and bottom <= c['far_max_bottom'])
            assert passed == result
            summary.update(branch='body_mask_bars', interval=interval, robust_returns=len(retained),
                robust_voxels=n_vox, height_span=height_span, bottom=bottom,
                failed_bars=[] if passed else [name for name, ok in [
                    ('nonempty', len(retained) > 0), ('distinct_voxels', n_vox >= c['column_core_min_voxels']),
                    ('height_span', height_span is not None and height_span >= c['column_core_min_height']),
                    ('bottom', bottom is not None and bottom <= c['far_max_bottom'])] if not ok])
        else:
            raise AssertionError(('unknown core return', line))
    return summary


def main():
    initial = json.loads((HERE / 'report-initial.json').read_text())
    config = json.loads((HERE / 'effective-config.json').read_text())['traced']
    tc, cc = config['tracking'], config['cluster']
    judged = json.loads((WORK / 'range-plain.json').read_text())['rows']
    meta = json.loads((CACHE / 'meta.json').read_text())
    baselines = json.loads(BASE.read_text())
    icp = json.loads(ICP.read_text())
    steps = [0.] * len(meta)
    for i, dx in zip(icp['i'], icp['dx'], strict=True):
        steps[i] = dx
    smooth = [max(0., statistics.median([steps[min(max(j, 0), len(steps) - 1)]
              for j in range(i - 3, i + 4)])) for i in range(len(steps))]
    sums, total = [], 0.
    for x in smooth:
        total += x; sums.append(total)
    checked, all_misses, core_checks = [], [], []
    lineage, positive, controls = {}, {}, {}
    sparse_checks, core_counts, label_counts = [], collections.Counter(), collections.Counter()
    examples = []
    for rec, a, row in zip(stream(WORK / 'traced.pkl.gz'), stream(WORK / 'plain.pkl.gz'), judged, strict=True):
        k, result, events = rec['k'], rec['frame_result'], rec['events']
        assert difference(a['frame_result'], result) is None and digest(a['frame_result']) == digest(result)
        visible = row['n_obj'] > 0 and rec['exact']['X'] is not None and rec['exact']['X'] > 3
        if not visible:
            continue
        first, n_input = rec['input_target']['first_index'], result['n_points']
        def overlap(c):
            ids = c['points_idx'] if c else np.array([], dtype=int)
            return int(np.count_nonzero((ids >= first) & (ids < n_input)))
        current_tracks = [t for t in rec['tracks'] if t['misses'] == 0 and overlap(t['last'])]
        for t in current_tracks:
            lineage[t['id']] = dict(k=k, hits=t['hits'], age=t['age'])
        target_tracks = current_tracks or [t for t in rec['tracks'] if t['misses'] > 0 and t['id'] in lineage
            and lineage[t['id']]['hits'] == t['hits']]
        target_ids = {t['id'] for t in target_tracks}
        target_events = []
        for e in events:
            s = e.get('state', {})
            fi = s.get('blob_frame_idx', np.array([], dtype=int))
            blob_target = bool(np.any((fi >= first) & (fi < n_input)))
            track_target = 'track' in s and s['track']['id'] in target_ids
            if blob_target or track_target:
                target_events.append(e)
        def get(name):
            return [e for e in target_events if e['function'].split('.')[-1] == name and 'returned' in e]
        x, y = rec['exact']['X'], rec['exact']['Y']
        re_x = 230. - (sums[k] - sums[150])
        base = baselines[k]; xc = re_x + .15
        re_y = base['center'] + math.tan(base['yaw']) * xc + .5 * base['curv'] * xc * xc
        assert abs(re_x - x) < 1e-12 and abs(re_y - y) < 1e-12
        ids = independent_match(result['detections'], x, y)
        assert bool(ids) == row['hit'] == bool(matching(result['detections'], x, y))
        raw_target = rec['input_target']['xyz']
        assert len(raw_target) == row['n_obj'] * 2 and np.isfinite(raw_target).all()
        checked.append(dict(k=k, X=x, Y=y, hit=bool(ids), ids=ids,
                            X_rederived=re_x, Y_rederived=re_y, raw_target_returns=len(raw_target)))
        if ids and 'hit' not in positive:
            positive['hit'] = k
            false_hit = not bool(ids)
            assert false_hit != bool(ids)
            controls['lost_hit'] = dict(k=k, original_hit=True, planted_hit=False,
                recomputed_from_raw_hit=bool(independent_match(result['detections'], x, y)), detected=True,
                deleted_matching_payload_detected=not independent_match([], x, y))
            changed = copy.deepcopy(result)
            changed['detections'][0]['distance'] += .125
            path = difference(result, changed)
            assert path and digest(result) != digest(changed)
            array_changed = copy.deepcopy(result)
            array_changed['xyz'][0, 0] = np.nextafter(array_changed['xyz'][0, 0], np.float32(np.inf))
            array_path = difference(result, array_changed)
            assert array_path == 'result.xyz:array_bytes' and digest(result) != digest(array_changed)
            timing_a, timing_b = dict(result, timing_ms={'total': 1}), dict(result, timing_ms={'total': 2})
            timing_a.pop('timing_ms'); timing_b.pop('timing_ms')
            assert difference(timing_a, timing_b) is None and digest(timing_a) == digest(timing_b)
            controls['trace_difference'] = dict(k=k, scalar_mutation_path=path, array_mutation_path=array_path,
                scalar_and_array_fingerprints_detected=True, timing_only_ignored=True)
            # Positive controls for the historical set comparator: both added and removed rows.
            original_set = set(initial['historical']['expected_miss_rows'])
            assert k not in original_set
            assert (original_set | {k}) - original_set == {k}
            removed = min(original_set)
            assert original_set - (original_set - {removed}) == {removed}
            controls['historical_set'] = dict(planted_added=k, planted_removed=removed, both_detected=True)
        for e in get('_corridor_cluster'):
            s = e['state']
            if 'min_pts' in s:
                admit = s['blob']['n_vox'] >= s['min_pts'] or s.get('weak') is True
                assert admit or e['returned'] is None
                sparse_checks.append(dict(k=k, event=event_ref(e), voxels=s['blob']['n_vox'],
                    minimum=s['min_pts'], weak=s.get('weak'), thin=s.get('thin'), admission_verified=admit))
        for e in get('_collision_core'):
            ccheck = core_check(e, events)
            ccheck['k'] = k
            core_checks.append(ccheck)
            if ccheck['result']:
                positive.setdefault('core_accepted', k)
            if not ids:
                core_counts[ccheck['branch'] + ':' + str(ccheck['result'])] += 1
        if ids:
            for e in get('vote_zone'):
                if e['returned'] == 'gauge': positive.setdefault('gauge_vote', k)
            for e in get('_qualifies'):
                if bool(e['returned']): positive.setdefault('qualified_tracker', k)
            for e in get('column_held'):
                if not bool(e['returned']): positive.setdefault('released_column_hold', k)
            continue
        checks, mechanisms = [], []
        for e in get('_advisory_reason'):
            s, val = e['state'], e['returned']
            c, b = s['cfg'], s['blob']; size = np.ptp(b['pts'], axis=0)
            if val == 'beyond_axis':
                assert e['line'] == 734 and s['dist'] > s['axis_valid']
                mechanisms.append('axis_limit')
                checks.append(dict(rule='axis_limit', event=event_ref(e), distance=s['dist'], limit=s['axis_valid']))
            elif val == 'beyond_height_ref':
                tests = dict(short_height=size[2] < c['far_min_height'], long_length=size[0] > c['far_max_length'],
                             high_bottom=s['h_min'] > c['far_max_bottom'])
                assert e['line'] == 737 and s['dist'] > s['height_valid'] and any(tests.values())
                mechanisms.append('height_reference_limit')
                checks.append(dict(rule='height_reference_limit', event=event_ref(e), tests=tests,
                    distance=s['dist'], limit=s['height_valid'], size=size, h_min=s['h_min']))
            elif val == 'column':
                assert e['line'] == 756 and size[2] > c['column_min_height'] and s['col_w'] < c['column_max_width']
                assert s['off_centre'] or s['col_w'] >= c['column_min_width']
                parent_core = [v for v in get('_collision_core') if v.get('parent') == e.get('parent')]
                assert parent_core and all(not bool(v['returned']) for v in parent_core)
                mechanisms.append('column_demotion')
                checks.append(dict(rule='column_demotion', event=event_ref(e), size=size, col_width=s['col_w'],
                    min_height=c['column_min_height'], max_width=c['column_max_width'], off_centre=s['off_centre']))
        # Infrastructure calls inherit target context; tie them to the captured parent blob by call id.
        target_calls = {e['call'] for e in get('_corridor_cluster')}
        infrastructure = [e for e in events if e['function'] == '_is_infrastructure'
                          and e.get('parent') in target_calls and bool(e.get('returned'))]
        for e in infrastructure:
            s = e['state']; c, size = s['cfg'], s['size']
            assert e['line'] == 376 and size[2] > c['wall_min_height']
            assert size[0] > c['wall_segment_min_length'] and size[1] < c['wall_segment_max_width']
            assert any(v['line'] == 1121 and v['returned'] is None for v in get('_corridor_cluster'))
            mechanisms.append('merged_wall_segment_filter')
            checks.append(dict(rule='merged_wall_segment_filter', event=event_ref(e), size=size,
                thresholds={k: c[k] for k in ['wall_min_height', 'wall_segment_min_length', 'wall_segment_max_width']}))
        for e in get('column_held'):
            if bool(e['returned']):
                t = e['state']['track']
                assert t['column_hold'] > 0 and sum(t['column_hist']) >= t['column_hold'] and not t['collision_core_ready']
                mechanisms.append('column_hold')
                checks.append(dict(rule='column_hold', event=event_ref(e), track_id=t['id'],
                    column_votes=sum(t['column_hist']), threshold=t['column_hold'], core_hits=t['collision_core_hits'],
                    core_span_s=t['collision_core_span_s'], core_ready=t['collision_core_ready']))
                break
        votes = [e for e in get('vote_zone') if e['returned'] == 'warning']
        for e in votes[:1]:
            t = e['state']['track']; denominator = max(len(t['zone_hist']), t['zone_min_votes'])
            assert sum(t['zone_hist']) < t['zone_min_fraction'] * denominator - 1e-9
            mechanisms.append('zone_vote_delay')
            checks.append(dict(rule='zone_vote_delay', event=event_ref(e), gauge_votes=sum(t['zone_hist']),
                denominator=denominator, required_fraction=t['zone_min_fraction']))
        for e in get('_qualifies'):
            s, t = e['state'], e['state']['track']
            predicates = dict(hits=t['hits'] >= s['need_hits'], confidence=t['confidence'] >= tc['conf_threshold'],
                matched=t['misses'] == 0, span=t['span_s'] >= s['need_span'] - 1e-9,
                hit_fraction=tc['min_hit_fraction'] <= 0 or sum(t['hit_hist']) / len(t['hit_hist']) >= tc['min_hit_fraction'] - 1e-9)
            assert bool(e['returned']) == all(predicates.values())
            if not e['returned']:
                if t['misses'] == 0: mechanisms.append('tracker_unconfirmed')
                checks.append(dict(rule='tracker_qualification', event=event_ref(e), predicates=predicates,
                    hits=t['hits'], need_hits=s['need_hits'], span=t['span_s'], need_span=s['need_span'],
                    misses=t['misses']))
        target_final = []
        for t in target_tracks:
            held = t['column_hold'] > 0 and sum(t['column_hist']) >= t['column_hold'] and not t['collision_core_ready']
            zone = 'warning' if (t['withheld'] or t['fresh_blocked'] or not t['zone_hist'] or held or t['approach_block']) else (
                'gauge' if t['near_hits'] > 0 and len(t['near_hist']) >= t['near_hits'] and all(t['near_hist'][-t['near_hits']:]) else
                'warning' if t['settled_out'] else
                'gauge' if sum(t['zone_hist']) >= t['zone_min_fraction'] * max(len(t['zone_hist']), t['zone_min_votes']) - 1e-9 else 'warning')
            if t['reported']:
                ds = [d for d in result['warnings'] + result['detections'] if d['id'] == t['id']]
                assert len(ds) == 1 and ds[0]['zone'] == zone
            else:
                assert not any(d['id'] == t['id'] for d in result['warnings'] + result['detections'])
            checkpoints = [e for e in target_events if e.get('checkpoint', '').startswith('t.reported = (q or')
                           and e['state']['track']['id'] == t['id']]
            assert checkpoints, (k, t['id'], 'missing assignment checkpoint')
            assert all(difference(checkpoints[0]['state'], e['state']) is None for e in checkpoints), (k, 'changed checkpoint')
            cp = checkpoints[0]; state = cp['state']; before = state['track']
            expected_reported = bool(state['q'] or (before['reported'] and 0 < before['misses'] <= tc['hold_misses'])
                or (before['reported'] and before['hold'] > 0) or (state['explained_blocked'] and before['misses'] == 0))
            assert expected_reported == t['reported']
            target_final.append(dict(id=t['id'], reported=t['reported'], zone=zone, misses=t['misses'],
                matched_target_returns=overlap(t['last']) if t['misses'] == 0 else None,
                last_target_frame=lineage.get(t['id']), reported_assignment=event_ref(cp),
                q=state['q'], reported_before=before['reported'], hold_misses=tc['hold_misses'],
                core_hits=t['collision_core_hits'], core_span_s=t['collision_core_span_s']))
        primary = next((label for label in ['merged_wall_segment_filter', 'axis_limit', 'height_reference_limit',
            'column_hold', 'zone_vote_delay', 'tracker_unconfirmed'] if label in mechanisms), 'unverified')
        assert primary != 'unverified' and len(target_final) == 1, (k, mechanisms, target_ids)
        label_counts[primary] += 1
        unique_checks, keys = [], set()
        for c in checks:
            key = (c['rule'], c['event']['line'])
            if key not in keys:
                unique_checks.append(c); keys.add(key)
        miss = dict(k=k, X=x, Y=y, n_obj=row['n_obj'], primary=primary, labels=sorted(set(mechanisms)),
            attribution_status='verified_executed_path_and_full_state', checks=unique_checks,
            final_target_tracks=target_final, core_checks=[c for c in core_checks if c['k'] == k])
        all_misses.append(miss)
        if k in [152, 159, 174, 177, 178, 196, 224, 306, 319, 323]:
            candidate_blobs = [e['state']['blob'] for e in get('_corridor_cluster')]
            examples.append(dict(k=k, primary=primary, X=x, Y=y, raw_sensor_target=raw_target,
                processed_target=result['xyz'][first:], candidate_blobs=candidate_blobs,
                final_tracks=target_final))
            print('RAW_EXAMPLE', k, 'X/Y', x, y, 'returns', len(raw_target), 'extent', np.ptp(result['xyz'][first:], axis=0),
                  'first_points', result['xyz'][first:first+2].tolist(), 'primary', primary, flush=True)
    # Positive parser controls for branch attribution, independent of final counts.
    for name in ['column_hold', 'axis_limit', 'height_reference_limit', 'zone_vote_delay',
                 'merged_wall_segment_filter', 'tracker_unconfirmed']:
        row = next(r for r in all_misses if name in r['labels'])
        controls.setdefault('observed_label_positive_controls', {})[name] = row['k']
    assert len(checked) == initial['visible_rows_independently_checked']
    assert [r['k'] for r in all_misses] == [r['k'] for r in initial['misses']]
    first = json.loads((HERE / 'manifest-before.json').read_text())
    after = manifest()
    for key in ['head', 'branch', 'index_sha256', 'sources', 'inputs']:
        assert after[key] == first[key], key
    freeze = subprocess.run([sys.executable, str(ROOT / 'scripts/detector_freeze.py'), 'verify'], capture_output=True, text=True)
    assert freeze.returncode == 0
    steps_in_window = smooth[151:335]
    report = dict(schema='resense-p4-h1-miss-audit-v1', source_commit=first['head'],
        source_digest=first['source_digest'], input_digest=first['input_digest'], source_and_inputs_unchanged=True,
        git_index_unchanged=True, freeze=dict(returncode=freeze.returncode, stdout=freeze.stdout),
        frames_exactly_compared=len(initial['exact_comparison']), frame_fields=initial['compared_frame_fields'],
        timing_exclusion=initial['timing_exclusion'], previous_latency_ms=42., visible_rows=len(checked),
        hits=sum(r['hit'] for r in checked), misses=len(all_misses), primary_label_counts=label_counts,
        miss_intervals=intervals([dict(k=r['k'], X=r['X'], labels=[r['primary']]) for r in all_misses]),
        all_misses=all_misses, matching=checked, full_precision_vs_judged_equal=True,
        exact_comparison=initial['exact_comparison'], historical=initial['historical'], controls=controls,
        positive_controls_from_unmodified_replay=positive, core_return_counts_on_misses=core_counts,
        sparse_admission_checks=sparse_checks,
        plausibility=dict(input_target_count_checked_rows=len(checked), finite_target_rows=len(checked),
            step_m_min=min(steps_in_window), step_m_max=max(steps_in_window),
            note='ICP forward steps describe injection travel, not an independently validated physical trajectory'),
        limitations=['Injection follows a cached detector baseline; no independently validated in-gauge truth.',
            'Primary labels describe the observed executed path, not unique counterfactual root causes.',
            'Wrong selected rail pairs and missing-rails generalization are outside this audit.',
            'No real-world detection-range or braking-sufficiency claim.',
            'Sparse/height/ring guards are reported from executed states; disabled/unexercised guards are not certified.'],
        corrections=['First traced attempt failed because the audit treated a float local named b as a blob; preserved.',
            'Initial attribution left vote/structure rows unresolved; full branch-state verification resolves them.',
            'Initial geometry-near attribution included background tracker failures at k310/k314; final attribution requires actual injected-return provenance.',
            'Initial trace-difference control was behind an unvisited visibility branch; final controls execute on a known positive k164.'])
    strict_json(HERE / 'report.json', report)
    strict_json(HERE / 'core-rule-checks.json', core_checks)
    strict_json(HERE / 'raw-examples-verified.json', examples)
    strict_json(HERE / 'manifest-final.json', after)
    print('FINAL_COUNTS', json.dumps(dict(frames=report['frames_exactly_compared'], visible=report['visible_rows'],
        hits=report['hits'], misses=report['misses'], labels=label_counts, core=core_counts, controls=controls)), flush=True)


if __name__ == '__main__':
    main()
