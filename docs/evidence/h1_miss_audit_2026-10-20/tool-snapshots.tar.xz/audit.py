#!/usr/bin/env python3
"""Read-only current-source P4 A-axis replay and executed-branch evidence.

Only output directories in PROTOCOL.md are writable. Run `replay`, then `report`.
Raw .pkl.gz streams contain dictionaries/numpy arrays, not live detector objects.
"""
import argparse
import collections
import dataclasses
import gzip
import hashlib
import inspect
import json
import linecache
import os
from pathlib import Path
import pickle
import struct
import subprocess
import sys
import tarfile
import time

ROOT = Path('/home/aiops/resense')
EVIDENCE_ROOT = ROOT / 'docs/evidence/h1_miss_audit_2026-10-20'
WORK_ROOT = Path('/tmp/opencode/h1-miss-audit')
HERE = Path(os.environ.get('H1_AUDIT_EVIDENCE', str(EVIDENCE_ROOT)))
WORK = Path(os.environ.get('H1_AUDIT_WORK', str(WORK_ROOT)))
assert HERE.resolve().is_relative_to(EVIDENCE_ROOT.resolve())
assert WORK.resolve().is_relative_to(WORK_ROOT.resolve())
CACHE = Path('/tmp/opencode/r3-h1/baseline/cache/roundT_squareT_pressureGate_squareT')
ICP = Path('/tmp/opencode/r3-h1/baseline/icp_roundT_squareT_pressureGate_squareT.json')
BASE = Path(str(CACHE) + '_baseline.json')
JUDGE = ROOT / 'docs/evidence/judgement_2026-10-13/scripts'
EXPECTED_HEAD = 'f56ad5e62d9d051811c804734c7731b6951eae90'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(JUDGE))
import numpy as np
import range_test as evaluator
from resense.detector import FrameResult, Detector, Candidates
from resense.clustering import Cluster, FrameRays, _Blob
from resense.tracking import Track, Tracker


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def raw(v, omit_timing=False):
    if dataclasses.is_dataclass(v):
        return {f.name: raw(getattr(v, f.name), omit_timing)
                for f in dataclasses.fields(v) if not (omit_timing and f.name == 'timing_ms')}
    if isinstance(v, np.ndarray):
        return v
    if isinstance(v, dict):
        return {k: raw(x, omit_timing) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return type(v)(raw(x, omit_timing) for x in v)
    if isinstance(v, np.generic):
        return v  # preserve scalar dtype in fingerprints/pickles
    return v


def digest(v):
    """Typed, length-delimited exact non-timing raw-field fingerprint."""
    h = hashlib.sha256()
    def add(x):
        def atom(tag, b):
            h.update(tag + struct.pack('>Q', len(b)) + b)
        if dataclasses.is_dataclass(x):
            add(raw(x, True))
        elif isinstance(x, np.ndarray):
            atom(b'A', str(x.dtype).encode()); add(x.shape); atom(b'B', x.tobytes(order='C'))
        elif isinstance(x, np.generic):
            atom(b'N', str(x.dtype).encode() + b':' + x.tobytes())
        elif isinstance(x, dict):
            atom(b'D', str(len(x)).encode())
            for k in sorted(x):
                add(k); add(x[k])
        elif isinstance(x, (list, tuple)):
            atom(b'L' if isinstance(x, list) else b'T', str(len(x)).encode())
            for y in x:
                add(y)
        else:
            atom(type(x).__name__.encode() + b':', repr(x).encode())
    add(v)
    return h.hexdigest()


def difference(a, b, path='result'):
    """Independent structural comparison; excludes nothing on its own."""
    if type(a) is not type(b):
        return path + ':type'
    if isinstance(a, np.ndarray):
        if a.dtype != b.dtype or a.shape != b.shape or a.tobytes() != b.tobytes():
            return path + ':array_bytes'
    elif isinstance(a, np.generic):
        if a.dtype != b.dtype or a.tobytes() != b.tobytes():
            return path + ':numpy_scalar'
    elif isinstance(a, dict):
        if a.keys() != b.keys():
            return path + ':keys'
        for k in a:
            found = difference(a[k], b[k], path + '.' + str(k))
            if found:
                return found
    elif isinstance(a, (list, tuple)):
        if len(a) != len(b):
            return path + ':length'
        for i, (x, y) in enumerate(zip(a, b)):
            found = difference(x, y, path + '[' + str(i) + ']')
            if found:
                return found
    elif repr(a) != repr(b):
        return path + ':value'
    return None


def js(v):
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, np.generic):
        return v.item()
    if dataclasses.is_dataclass(v):
        return js(raw(v))
    if isinstance(v, dict):
        return {str(k): js(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [js(x) for x in v]
    return v


def save(path, data):
    with Path(path).open('x') as f:
        json.dump(js(data), f, indent=2, allow_nan=True)
        f.write('\n')


def manifest():
    # No branch/index mutations. Include all tracked source/tool bytes, runtime binaries,
    # and every decoded cache member, including those beyond --end.
    tracked = git('ls-files').splitlines()
    paths = [ROOT / p for p in tracked if p.startswith(('resense/', 'native/', 'configs/',
             'ros2_ws/src/resense_ros/', 'scripts/')) and (ROOT / p).is_file()]
    paths += list(JUDGE.glob('*.py'))
    for name in ['h1_axis_range_2026-10-19/trace_ranges.py',
                 'h1_reference_2026-10-19/trace_ranges.py',
                 'h1_reference_2026-10-19/trace_core.py',
                 'h1_core_2026-10-19/trace_axis.py']:
        paths.append(ROOT / 'docs/evidence' / name)
    paths += list((ROOT / 'native').rglob('*.so'))
    paths += list((ROOT / 'resense').glob('*.so'))
    paths += [ROOT / 'CLAUDE.md', ROOT / 'docs/DETECTOR_FREEZE.md',
              ROOT / 'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json']
    sources = {str(p): sha(p) for p in sorted(set(paths))}
    inputs = {str(p): sha(p) for p in sorted(CACHE.iterdir()) if p.is_file()}
    inputs.update({str(ICP): sha(ICP), str(BASE): sha(BASE)})
    index = ROOT / '.git/index'
    return dict(head=git('rev-parse', 'HEAD'), branch=git('branch', '--show-current'),
                status=git('status', '--short'), index_sha256=sha(index),
                sources=sources, source_digest=digest(sources), inputs=inputs,
                input_digest=digest(inputs), cache_resolved=str(CACHE.resolve()),
                runtime=dict(python=sys.version, executable=sys.executable,
                    executable_sha256=sha(sys.executable), numpy=np.__version__,
                    environment={k: os.environ.get(k) for k in ['RESENSE_REPO', 'PYTHONPATH',
                    'OPENBLAS_CORETYPE', 'OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
                    'LD_LIBRARY_PATH', 'PYTHONDONTWRITEBYTECODE']}))


def matching(detections, x, y, length=.3, width=.3):
    """Scalar raw-data implementation, independent of evaluator's rounded info/hit."""
    if x is None or y is None or x <= 3:
        return []
    allowance = max(2., 3. * x / 100.) + length / 2.
    return [d.get('id', i) for i, d in enumerate(detections) if abs(float(d['distance']) - x) <= allowance
            and abs(float(d['center'][1]) - y) <= 1. + width / 2.]


class Trace:
    def __init__(self, x, y, first, n_input):
        self.x, self.y, self.first, self.n_input = x, y, first, n_input
        self.events, self.active, self.serial = [], {}, 0
        self.files = {str(ROOT / 'resense' / n) for n in ['clustering.py', 'tracking.py', 'detector.py']}
        self.functions = {'_corridor', '_low_stage', '_cluster', '_hanging', '_rail_reference',
            '_mount_cross_check', '_dual_zone', '_far_both_sides', '_confirm', '_far_thin',
            'find_clusters', '_corridor_cluster', '_low_cluster', '_collision_core',
            '_advisory_reason', '_is_infrastructure', '_split_part', '_gauge_part',
            '_off_structure_parts', 'top_is_free', '_own_rays_pass',
            'collision_axis_anchor', 'collision_axis_interval', '_qualifies',
            '_fresh_stop_ok', '_uncorroborated_spare', '_note', '_keeps', '_near',
            '_carried_along', '_cable_kind', '_cable_confirmed', '_cable_confirmation',
            '_approaching', '_clean_gauge', 'column_held', 'rule_zone', 'zone', 'vote_zone',
            'near_escalated', '_continue_thin', '_continue_low_height', 'update'}

    def cl_target(self, c):
        return (isinstance(c, Cluster) and
                bool(np.any((c.points_idx >= self.first) & (c.points_idx < self.n_input))))

    def near(self, t):
        return (isinstance(t, Track) and self.x is not None and
                abs(float(t.centroid[0]) - self.x) < 10 and
                abs(float(t.centroid[1]) - self.y) < 3)

    def blob_target(self, frame):
        s = frame.f_locals
        if not isinstance(s.get('b'), _Blob):
            return False
        fi = s.get('frame_idx')
        if fi is None and frame.f_back:
            fi = frame.f_back.f_locals.get('frame_idx')
        if fi is None:
            return False
        ids = fi[s['b'].idx]
        return bool(np.any((ids >= self.first) & (ids < self.n_input)))

    def snapshot(self, frame):
        s = frame.f_locals
        out = {}
        scalars = ('dist', 'lateral', 'lat_rules', 'axis_valid', 'height_valid', 'zone', 'reason',
            'core', 'thin', 'weak', 'min_pts', 'gauge_min', 'ring_count', 'n_gauge', 'factor',
            'factor_range', 'weak_from', 'keep_thin', 'h_min', 'h_max', 'col_w', 'off_centre',
            'interval', 'anchor', 'lower', 'upper', 'window', 'a', 'q', 'was_reported', 'earned_stop',
            'was_blocked', 'fresh_blocked', 'explained_blocked', 'need_span', 'need_hits', 'source',
            'eligible', 'approaching', 'provisional', 'clean', 'explained', 'low_ok', 'rail_within',
            'dt', 'kdt', 'step', 'block', 'keep', 'size', 'current', 'k', 'seen_free', 'n', 'spare_hist')
        for k in scalars:
            if k in s and (s[k] is None or isinstance(s[k], (str, bool, int, float, np.generic,
                                                         np.ndarray, list, tuple))):
                out[k] = raw(s[k])
        for k in ['cfg', 'gauge', 'low_cfg']:
            if dataclasses.is_dataclass(s.get(k)):
                out[k] = raw(s[k])
        t = s.get('t', s.get('self'))
        if isinstance(t, Track):
            out['track'] = raw(t)
        if isinstance(s.get('cl'), Cluster):
            out['cluster'] = raw(s['cl'])
        b = s.get('b')
        if isinstance(b, _Blob):
            out['blob'] = raw(b)
            parent = frame.f_back.f_locals if frame.f_back else {}
            for k in ['dy', 'h', 'in_gauge', 'in_rail', 'inv', 'frame_idx', 'ring']:
                arr = s.get(k, parent.get(k))
                if isinstance(arr, np.ndarray) and arr.size and b.idx.size and arr.shape[0] > int(b.idx.max()):
                    out['blob_' + k] = arr[b.idx]
        rays = s.get('rays', s.get('self'))
        if isinstance(rays, FrameRays):
            out['rays_state'] = {k: raw(getattr(rays, k)) for k in ['_core_anchor',
                '_core_anchor_checked', '_core_rail_stations', '_core_boundaries']}
        if frame.f_code.co_name == 'collision_axis_interval':
            for k in ['x', 'b', 'spread']:
                if k in s:
                    out[k] = s[k]
            for k in ['near', 'local', 'stations', 'values']:
                if k in s:
                    out[k] = s[k]
        if frame.f_code.co_name == 'find_clusters':
            fi = s.get('frame_idx')
            if isinstance(fi, np.ndarray):
                m = (fi >= self.first) & (fi < self.n_input)
                out['injected_candidates'] = {k: s[k][m] for k in ['xyz', 'dy', 'h', 'in_gauge',
                    'frame_idx', 'labels', 'inv'] if isinstance(s.get(k), np.ndarray)}
                if 'vlabels' in s:
                    out['voxel_labels_counts'] = np.unique(s['vlabels'], return_counts=True)
        # Freeze now; detector objects/arrays can be mutated later in the same frame.
        return pickle.loads(pickle.dumps(out, protocol=5))

    def __call__(self, frame, event, arg):
        code = frame.f_code
        if event == 'call':
            if code.co_filename not in self.files or code.co_name not in self.functions:
                return None
            self.serial += 1
            parent = self.active.get(id(frame.f_back), {})
            s = frame.f_locals
            target = (self.blob_target(frame) or self.cl_target(s.get('cl'))
                      or self.near(s.get('t', s.get('self'))) or parent.get('target', False))
            self.active[id(frame)] = dict(call=self.serial, parent=parent.get('call'), target=target,
                function=code.co_qualname, file=str(Path(code.co_filename).relative_to(ROOT)), lines=[])
            return self
        rec = self.active.get(id(frame))
        if rec is None:
            return None
        if event == 'line':
            rec['lines'].append(frame.f_lineno)
            if code is Tracker.update.__code__:
                s = frame.f_locals
                text = linecache.getline(code.co_filename, frame.f_lineno).strip()
                if self.near(s.get('t')) and (text.startswith(('t.reported =', 'q = False',
                        'q = self.', 't.fresh_blocked =', 't.approach_block ='))):
                    self.events.append(dict(function=code.co_qualname, file=rec['file'],
                        checkpoint=text, line=frame.f_lineno, state=self.snapshot(frame)))
        elif event == 'return':
            s = frame.f_locals
            t = s.get('t', s.get('self'))
            stage = code.co_name in {'_corridor', '_low_stage', '_cluster', '_hanging', '_rail_reference',
                                    '_mount_cross_check', '_dual_zone', '_far_both_sides', '_confirm', 'find_clusters'}
            parent = self.active.get(id(frame.f_back), {})
            relevant = (stage or rec['target'] or self.blob_target(frame) or self.cl_target(s.get('cl')) or self.near(t)
                or code.co_name in {'collision_axis_interval', 'collision_axis_anchor', 'top_is_free'}
                or parent.get('target', False))
            if relevant and code is not Tracker.update.__code__:
                rec.update(line=frame.f_lineno, executed_return=linecache.getline(code.co_filename,
                    frame.f_lineno).strip(), state=self.snapshot(frame))
                if isinstance(arg, Candidates):
                    ids = (arg.idx >= self.first) & (arg.idx < self.n_input)
                    rec['returned'] = raw(arg.subset(ids))
                elif isinstance(arg, (Cluster, bool, str, int, float, np.generic)) or arg is None:
                    rec['returned'] = raw(arg)
                elif isinstance(arg, tuple) and all(isinstance(z, (int, float, np.generic)) for z in arg):
                    rec['returned'] = arg
                elif isinstance(arg, (list, tuple)):
                    if code.co_name == '_corridor':
                        cand, dy, h, mask, limits = arg
                        ids = (cand.idx >= self.first) & (cand.idx < self.n_input)
                        rec['returned'] = dict(candidates=raw(cand.subset(ids)),
                            target_dy=dy[self.first:], target_h=h[self.first:],
                            target_corridor=mask[self.first:], limits=limits)
                    else:
                        def small(x):
                            if isinstance(x, (Cluster, Track)):
                                return raw(x) if (self.cl_target(x) if isinstance(x, Cluster) else self.near(x)) else None
                            if isinstance(x, (tuple, list)):
                                return [small(z) for z in x]
                            return None
                        rec['returned'] = small(arg)
                self.events.append(rec)
            self.active.pop(id(frame), None)
        return self


def replay():
    assert HERE.is_dir() and WORK.is_dir() and (HERE / 'PROTOCOL.md').is_file()
    assert BASE.is_file(), 'evaluator baseline must already exist; creation outside scope forbidden'
    before = manifest()
    assert before['head'] == EXPECTED_HEAD and before['branch'] == 'main'
    if (HERE / 'manifest-before.json').exists():
        original_before = json.loads((HERE / 'manifest-before.json').read_text())
        for key in ['head', 'branch', 'index_sha256', 'sources', 'inputs']:
            assert before[key] == original_before[key], key
        save(HERE / 'manifest-before-resume.json', before)
    else:
        save(HERE / 'manifest-before.json', before)
    freeze = subprocess.run([sys.executable, str(ROOT / 'scripts/detector_freeze.py'), 'verify'],
                            capture_output=True, text=True)
    receipt = 'freeze-before-resume.json' if (HERE / 'freeze-before.json').exists() else 'freeze-before.json'
    save(HERE / receipt, dict(returncode=freeze.returncode, stdout=freeze.stdout, stderr=freeze.stderr))
    assert freeze.returncode == 0
    original = evaluator.run_frame
    schemas = {}
    for mode in ['plain', 'traced']:
        if mode == 'plain' and (WORK / 'plain-index.json').exists():
            print('REUSE_COMPLETE_PLAIN_CAPTURE_SAME_SOURCE_AND_INPUTS', flush=True)
            continue
        rows = []
        capture_path = WORK / (mode + '.pkl.gz')
        with gzip.open(capture_path, 'xb', compresslevel=1) as capture:
            def run_frame(rep, xyz, inten, ring, metadata, index):
                caller = sys._getframe(1).f_locals
                info = dict(caller['info'])
                visible = info.get('n_obj', 0) > 0
                exact = dict(X=float(caller['X']) if info['X'] is not None else None,
                             Y=float(caller['yc']) if 'Y' in info else None,
                             Zb=float(caller['zb']) if 'Zb' in info else None)
                first = len(xyz) - 2 * info['n_obj']
                trace = Trace(exact['X'], exact['Y'], first, len(xyz)) if mode == 'traced' and visible else None
                previous = rep.detector._previous_latency_ms
                if previous is not None:
                    rep.detector._previous_latency_ms = 42.
                if index == 0:
                    schemas[mode] = raw(rep.detector.cfg)
                if trace:
                    sys.settrace(trace)
                try:
                    result = original(rep, xyz, inten, ring, metadata, index)
                finally:
                    sys.settrace(None)
                result_raw = raw(result, True)
                tracks = [raw(t) for t in rep.detector.tracker.tracks
                          if exact['X'] is not None and abs(float(t.centroid[0]) - exact['X']) < 10
                          and exact['Y'] is not None and abs(float(t.centroid[1]) - exact['Y']) < 3]
                rec = dict(k=index, info=info, exact=exact, metadata=metadata,
                    input_hash=digest(dict(xyz=xyz, intensity=inten, ring=ring, metadata=metadata)),
                    raw_hash=digest(result_raw), frame_result=result_raw,
                    input_target=dict(first_index=first, xyz=xyz[first:], intensity=inten[first:], ring=ring[first:]),
                    previous_latency_fixed=previous is not None, tracks=tracks,
                    thin=[raw(c) for c in rep.detector._thin if visible and np.any(c.points_idx >= first)],
                    low_height=[raw(c) for c in rep.detector._low_height if visible and np.any(c.points_idx >= first)],
                    events=trace.events if trace else [])
                pickle.dump(rec, capture, protocol=5)
                rows.append({k: rec[k] for k in ['k', 'info', 'exact', 'input_hash', 'raw_hash', 'previous_latency_fixed']})
                if index % 50 == 0:
                    print('PROGRESS', mode, index, flush=True)
                return result
            evaluator.run_frame = run_frame
            sys.argv = [str(evaluator.__file__), str(CACHE), str(ICP), str(WORK / ('range-' + mode)),
                '--obj', '0.3,0.3,2.8', '--start', '150', '--d0', '230', '--end', '340']
            evaluator.main()
        save(WORK / (mode + '-index.json'), rows)
        print('CAPTURE', mode, capture_path.stat().st_size, flush=True)
    save(HERE / 'effective-config.json', schemas)
    after = manifest()
    save(HERE / 'manifest-after-replay.json', after)
    for key in ['head', 'branch', 'index_sha256', 'sources', 'inputs']:
        assert before[key] == after[key], key
    print('REPLAY_FINISHED', flush=True)


def stream(path):
    with gzip.open(path, 'rb') as f:
        while True:
            try:
                yield pickle.load(f)
            except EOFError:
                break


def intervals(rows):
    out = []
    for r in rows:
        if not out or r['k'] != out[-1]['end'] + 1:
            out.append(dict(start=r['k'], end=r['k'], count=1, X_start=r['X'], X_end=r['X'],
                            labels=collections.Counter(r.get('labels', []))))
        else:
            out[-1]['end'] = r['k']; out[-1]['X_end'] = r['X']; out[-1]['count'] += 1
            out[-1]['labels'].update(r.get('labels', []))
    return out


def historical():
    path = ROOT / 'docs/evidence/h1_reference_2026-10-19/raw-evidence.tar.gz'
    with tarfile.open(path) as tar:
        judged = json.load(tar.extractfile('probes-e-candidate/A-axis.json'))
        plain = json.load(tar.extractfile('trace-e-A-axis-plain.json'))
        traced = json.load(tar.extractfile('trace-e-A-axis-traced.json'))
    expected = [r['k'] for r in judged['rows'] if r['X'] is not None and r['X'] > 3 and r['n_obj'] > 0 and not r['hit']]
    assert all([r['k'] for r in other['rows'] if r['X'] is not None and r['X'] > 3 and r['n_obj'] > 0
                and not r['hit']] == expected for other in [plain, traced])
    # Independently use historical full-precision detection coordinates (rounded injection info).
    tracepath = ROOT / 'docs/evidence/h1_reference_2026-10-19/trace-ranges-e.json'
    captures = json.loads(tracepath.read_text())['cases']['A-axis']['rows']
    reconstructed = [r['i'] for r in captures if r['info']['X'] is not None and r['info']['X'] > 3
        and r['info']['n_obj'] > 0 and not matching(r['detections'], r['info']['X'], r['info'].get('Y'))]
    assert reconstructed == expected
    return dict(archive=str(path), archive_sha256=sha(path), expected_miss_rows=expected,
                judged_summary=judged['summary'], three_archived_outputs_row_sets_equal=True,
                full_detection_rederived_row_set_equal=True, trace_sha256=sha(tracepath))


def event_ref(e):
    return {k: e[k] for k in ['function', 'file', 'line', 'executed_return', 'checkpoint', 'call', 'lines'] if k in e}


def attribute(rec):
    """Labels are tied to captured returns/checkpoints, with all evidence retained."""
    events = rec['events']
    labels, proof = [], []
    for e in events:
        name = e['function'].split('.')[-1]
        s, value = e.get('state', {}), e.get('returned')
        if name == '_advisory_reason' and isinstance(value, str) and value:
            label = {'column': 'column_demotion', 'beyond_axis': 'axis_limit',
                     'beyond_height_ref': 'height_reference_limit'}.get(value, 'advisory_' + value)
            labels.append(label); proof.append(dict(label=label, event=event_ref(e), state=s))
        if name == '_corridor_cluster' and value is None:
            line = e['line']; text = e['executed_return']
            # The executed return and exact locals distinguish these exits, not candidate reason.
            source = linecache.getline(str(ROOT / e['file']), line - 1).strip()
            label = ('sparse_rejected' if source == 'if not (ordinary or cross_ring):' else
                     'cluster_filtered_unverified')
            labels.append(label); proof.append(dict(label=label, event=event_ref(e), state=s,
                                                    preceding_source=source))
        if name == 'column_held' and bool(value):
            labels.append('column_hold'); proof.append(dict(label='column_hold', event=event_ref(e), state=s))
        if name == '_qualifies' and value is False:
            t = s['track']
            if t['misses'] == 0:
                labels.append('tracker_unconfirmed')
                proof.append(dict(label='tracker_unconfirmed', event=event_ref(e), state=s))
        if name == '_collision_core':
            label = 'core_accepted' if value else 'core_rejected'
            proof.append(dict(label=label, event=event_ref(e), state=s))
        if name == '_fresh_stop_ok' and value is False:
            labels.append('fresh_stop_gate'); proof.append(dict(label='fresh_stop_gate', event=event_ref(e), state=s))
        if name == 'update' and e.get('checkpoint') == 'q = False':
            labels.append('tracker_q_veto'); proof.append(dict(label='tracker_q_veto', event=event_ref(e), state=s))
    labels = sorted(set(labels))
    if not labels:
        labels = ['unverified']
    return labels, proof


def report():
    plain_range = json.loads((WORK / 'range-plain.json').read_text())
    traced_range = json.loads((WORK / 'range-traced.json').read_text())
    out = dict(protocol_sha256=sha(HERE / 'PROTOCOL.md'), scope='detector-baseline-axis injection; no external axis truth',
        fixed_previous_latency_ms=42., timing_exclusion=['FrameResult.timing_ms only'],
        compared_frame_fields=[f.name for f in dataclasses.fields(FrameResult) if f.name != 'timing_ms'],
        exact_comparison=[], matching_rows=[], misses=[], controls={}, historical=historical(),
        evaluator_summary=plain_range['summary'])
    miss_snapshots = HERE / 'miss-snapshots.pkl.gz'
    examples, nonzero = [], collections.Counter()
    rows_checked, first_positive = 0, None
    with gzip.open(miss_snapshots, 'xb', compresslevel=3) as misses:
        for a, b, row, tr in zip(stream(WORK / 'plain.pkl.gz'), stream(WORK / 'traced.pkl.gz'),
                                plain_range['rows'], traced_range['rows'], strict=True):
            k = a['k']; assert k == b['k'] == row['k'] == tr['k']
            diff = difference(a['frame_result'], b['frame_result'])
            out['exact_comparison'].append(dict(k=k, raw_hash=a['raw_hash'], traced_raw_hash=b['raw_hash'], difference=diff,
                input_equal=a['input_hash'] == b['input_hash'], injection_state_equal=difference(a['exact'], b['exact']) is None))
            assert diff is None and a['raw_hash'] == b['raw_hash'] and a['input_hash'] == b['input_hash']
            assert a['info'] == b['info'] and a['exact'] == b['exact']
            assert row == tr
            if row['n_obj'] <= 0 or a['exact']['X'] is None or a['exact']['X'] <= 3:
                continue
            dets = a['frame_result']['detections']
            exact_ids = matching(dets, a['exact']['X'], a['exact']['Y'])
            judged_ids = matching(dets, row['X'], row.get('Y'))
            checked = dict(k=k, X=a['exact']['X'], Y=a['exact']['Y'], n_obj=row['n_obj'],
                evaluator_hit=row['hit'], exact_hit=bool(exact_ids), matching_detection_ids=exact_ids,
                rounded_rederived_hit=bool(judged_ids), rounded_coordinates=dict(X=row['X'], Y=row.get('Y')),
                raw_detections=[dict(id=d['id'], distance=d['distance'], center=d['center']) for d in dets])
            assert bool(judged_ids) == row['hit']
            out['matching_rows'].append(checked); rows_checked += 1
            for e in b['events']:
                if e.get('returned') is not None and isinstance(e.get('returned'), (bool, str)):
                    nonzero[e['function'] + ':' + repr(e['returned'])] += 1
            if exact_ids and first_positive is None:
                first_positive = checked
            if not exact_ids:
                labels, proof = attribute(b)
                checked.update(labels=labels, attribution_status='unverified' if any('unverified' in x for x in labels) else 'executed_rules_verified',
                    proof=proof, target_candidates=[c for c in a['frame_result']['candidates']
                        if np.any(c['points_idx'] >= a['input_target']['first_index'])], tracks=a['tracks'])
                out['misses'].append(checked)
                pickle.dump(b, misses, protocol=5)
                if len(examples) < 3 or (labels and not any(e['labels'] == labels for e in examples)):
                    target = a['input_target']; first = target['first_index']
                    example = dict(k=k, labels=labels, X=a['exact']['X'], Y=a['exact']['Y'], n_obj=row['n_obj'],
                        raw_sensor_target=target['xyz'], processed_target=a['frame_result']['xyz'][first:],
                        candidates=checked['target_candidates'], tracks=a['tracks'])
                    examples.append(example)
            if k == 150:
                original = a['frame_result']
                changed = dict(original, obstacle=not original['obstacle'])
                detected = difference(original, changed)
                assert detected == 'result.obstacle:value' and digest(original) != digest(changed)
                timing_a, timing_b = dict(original, timing_ms={'total': 1.}), dict(original, timing_ms={'total': 999.})
                timing_a.pop('timing_ms'); timing_b.pop('timing_ms')
                assert difference(timing_a, timing_b) is None and digest(timing_a) == digest(timing_b)
                out['controls']['trace_difference'] = dict(frame=k, planted='flipped obstacle', detected=detected,
                    fingerprint_detected=True, timing_only_ignored=True)
    assert first_positive is not None
    # Positive lost-hit control compares independent raw matching to a planted damaged evaluator label.
    planted = dict(first_positive, evaluator_hit=False)
    detected = planted['exact_hit'] != planted['evaluator_hit']
    assert detected
    removed = matching([], first_positive['X'], first_positive['Y'])
    assert not removed
    out['controls']['lost_hit'] = dict(frame=first_positive['k'], original_matching_ids=first_positive['matching_detection_ids'],
        planted_evaluator_hit=False, independent_hit=first_positive['exact_hit'], mismatch_detected=detected,
        deleted_all_detections_rederived_hit=False)
    out['frames_compared'] = len(out['exact_comparison'])
    out['visible_rows_independently_checked'] = rows_checked
    out['fresh_full_precision_hits'] = sum(r['exact_hit'] for r in out['matching_rows'])
    out['fresh_full_precision_misses'] = len(out['misses'])
    out['rounded_vs_exact_differences'] = [r['k'] for r in out['matching_rows'] if r['exact_hit'] != r['evaluator_hit']]
    out['miss_intervals'] = intervals(out['misses'])
    out['label_counts_nonexclusive'] = collections.Counter(x for r in out['misses'] for x in r['labels'])
    out['positive_executed_paths'] = nonzero
    current = {r['k'] for r in out['misses']}; old = set(out['historical']['expected_miss_rows'])
    out['historical'].update(fresh_added_misses=sorted(current - old), fresh_removed_misses=sorted(old - current),
                             exact_miss_set_equal=current == old)
    save(HERE / 'raw-examples.json', examples)
    save(HERE / 'report-initial.json', out)
    print(json.dumps(js({k: out[k] for k in ['frames_compared', 'visible_rows_independently_checked',
        'fresh_full_precision_hits', 'fresh_full_precision_misses', 'rounded_vs_exact_differences',
        'miss_intervals', 'label_counts_nonexclusive', 'controls']}), indent=2), flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['replay', 'report'])
    args = p.parse_args()
    {'replay': replay, 'report': report}[args.command]()
