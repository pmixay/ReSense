#!/usr/bin/env python3
"""Offline portable-evidence checks (stdlib); --vm checks retained original captures.

Read-only: no replay, detector import, Git, or file mutation. The VM extension
requires NumPy to decode the original captures, not the production detector.
"""
import argparse
import base64
import collections
import copy
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import struct

HERE = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()


class Array:
    def __init__(self, dtype, shape, data):
        self.dtype, self.shape, self.bytes = dtype, tuple(shape), data
        kind, size = dtype[1], int(dtype[2:])
        formats = {('f', 4): 'f', ('f', 8): 'd', ('i', 1): 'b', ('i', 2): 'h',
            ('i', 4): 'i', ('i', 8): 'q', ('u', 1): 'B', ('u', 2): 'H',
            ('u', 4): 'I', ('u', 8): 'Q', ('b', 1): '?'}
        code = formats[(kind, size)]
        order = '>' if dtype[0] == '>' else '<'
        self.flat = [v[0] for v in struct.iter_unpack(order + code, data)]
        assert len(self.flat) == math.prod(shape) and len(data) == size * math.prod(shape)
    def __len__(self): return self.shape[0]
    def rows(self):
        assert len(self.shape) == 2
        n = self.shape[1]
        return [self.flat[i:i+n] for i in range(0, len(self.flat), n)]


def unpack(v):
    if isinstance(v, list): return [unpack(x) for x in v]
    if isinstance(v, dict):
        if '__ndarray__' in v:
            return Array(v['dtype'], v['shape'], base64.b64decode(v['base64'], validate=True))
        if '__numpy_scalar__' in v:
            return Array(v['__numpy_scalar__'], [1], base64.b64decode(v['base64'], validate=True)).flat[0]
        if '__float64_bits__' in v: return struct.unpack('<d', bytes.fromhex(v['__float64_bits__']))[0]
        if '__tuple__' in v: return tuple(unpack(x) for x in v['__tuple__'])
        return {k: unpack(x) for k, x in v.items()}
    return v


def vals(x): return x.flat if isinstance(x, Array) else x
def size(points):
    return [max(p[i] for p in points) - min(p[i] for p in points) for i in range(3)]
def match(dets, x, y):
    limit = max(2., .03 * x) + .15
    return [d['id'] for d in dets if x - limit <= d['distance'] <= x + limit
            and y - 1.15 <= vals(d['center'])[1] <= y + 1.15]


def polygon(y, z, profile):
    intersections = []
    for a, b in zip(profile, profile[1:] + profile[:1]):
        if min(a[1], b[1]) <= z < max(a[1], b[1]):
            intersections.append(a[0] + (z - a[1]) * (b[0] - a[0]) / (b[1] - a[1]))
    return sum(y < p for p in intersections) % 2 == 1


def core_event_check(e):
    s = e['state']; c, g = s['cfg'], s['gauge']; b = s['blob']
    points = b['pts'].rows(); ext = size(points)
    if e['line'] == 1032:
        assert not e['returned'] and (g is None or c['column_core_margin'] <= 0
            or ext[0] > c['column_core_max_footprint'] or ext[1] > c['column_core_max_footprint'])
        return 'footprint_or_prerequisite'
    fi, ing, inr = (vals(s['blob_' + key]) for key in ['frame_idx', 'in_gauge', 'in_rail'])
    current = [i >= 0 and a and b for i, a, b in zip(fi, ing, inr)]
    assert current == vals(s['current'])
    if e['line'] == 1036:
        assert not e['returned'] and sum(current) < c['column_core_min_voxels']
        return 'current_support_below_bar'
    if e['line'] == 1039:
        assert s['interval'] is None and not e['returned']
        return 'no_axis_consistency_interval'
    assert e['line'] == 1045
    dy, h, inv = (vals(s['blob_' + key]) for key in ['dy', 'h', 'inv'])
    indices = [i for i, keep in enumerate(current) if keep]
    keep = []
    for i in indices:
        q = points[i][0] / 100.
        margin = g['edge_margin'] + c['column_core_margin'] + g['edge_margin_per_100m'] * q
        if g['edge_margin_per_100m2'] > 0: margin += g['edge_margin_per_100m2'] * q * q
        ok = True
        for offset in s['interval']:
            residual = dy[i] - offset
            shifted = residual + (margin if residual > 0 else -margin if residual < 0 else 0.)
            ok = ok and polygon(shifted, h[i], g['profile'])
        keep.append(ok)
    assert keep == vals(s['keep']), 'captured core mask differs from independent polygon test'
    retained = [i for i, ok in zip(indices, keep) if ok]
    assert [vals(b['idx'])[i] for i in retained] == vals(s['k'])
    n_vox = len({inv[i] for i in retained})
    passed = bool(retained and n_vox >= c['column_core_min_voxels']
        and max(h[i] for i in retained) - min(h[i] for i in retained) >= c['column_core_min_height']
        and min(h[i] for i in retained) <= c['far_max_bottom'])
    assert passed == bool(e['returned'])
    return 'body_mask_bars'


def validate_miss(r, visible, tracking_cfg):
    att = r['attribution']; events = r['branch_events']
    first = visible['target_support']['input_target']['first_index']
    last = visible['source_snapshot']['whole_processed_cloud']['shape'][0]
    ids = {t['id'] for t in att['final_target_tracks']}
    calls = {e['call']: e for e in events if 'call' in e}
    def target(e):
        s = e.get('state', {})
        fi = vals(s.get('blob_frame_idx', []))
        return (any(first <= i < last for i in fi)
                or s.get('track', {}).get('id') in ids)
    def get(name):
        return [e for e in events if e['function'].split('.')[-1] == name and target(e) and 'returned' in e]
    primary = att['primary']
    if primary == 'column_hold':
        es = [e for e in get('column_held') if e['returned']]
        assert es
        t = es[-1]['state']['track']
        assert t['column_hold'] > 0 and sum(t['column_hist']) >= t['column_hold'] and not t['collision_core_ready']
    elif primary == 'axis_limit':
        es = [e for e in get('_advisory_reason') if e['returned'] == 'beyond_axis' and e['line'] == 734]
        assert es and es[0]['state']['dist'] > es[0]['state']['axis_valid']
    elif primary == 'height_reference_limit':
        es = [e for e in get('_advisory_reason') if e['returned'] == 'beyond_height_ref' and e['line'] == 737]
        assert es
        s = es[0]['state']; c = s['cfg']; ext = size(s['blob']['pts'].rows())
        assert s['dist'] > s['height_valid'] and (ext[2] < c['far_min_height']
            or ext[0] > c['far_max_length'] or s['h_min'] > c['far_max_bottom'])
    elif primary == 'zone_vote_delay':
        es = [e for e in get('vote_zone') if e['returned'] == 'warning']
        assert es
        t = es[-1]['state']['track']
        assert sum(t['zone_hist']) < t['zone_min_fraction'] * max(len(t['zone_hist']), t['zone_min_votes']) - 1e-9
        assert any(e['returned'] == 'warning' and e['line'] == 153 for e in get('rule_zone'))
    elif primary == 'tracker_unconfirmed':
        es = [e for e in get('_qualifies') if not e['returned']]
        assert es
        s = es[-1]['state']; t = s['track']
        assert t['misses'] == 0 and (t['hits'] < s['need_hits']
            or t['confidence'] < tracking_cfg['conf_threshold'] or t['span_s'] < s['need_span'] - 1e-9)
    elif primary == 'merged_wall_segment_filter':
        es = [e for e in events if e['function'] == '_is_infrastructure' and e.get('returned') is True
              and e.get('line') == 376 and target(calls.get(e.get('parent'), {}))]
        assert es
        s = es[0]['state']; c = s['cfg']; ext = vals(s['size'])
        assert ext[2] > c['wall_min_height'] and ext[0] > c['wall_segment_min_length'] and ext[1] < c['wall_segment_max_width']
        assert any(e['returned'] is None and e['line'] == 1121 for e in get('_corridor_cluster'))
    else: raise AssertionError(('unverified label', primary))
    # Every published attribution proof points to an actual captured event.
    for check in att['checks']:
        ref = check['event']
        assert any(e['function'] == ref['function'] and e.get('line') == ref['line']
            and ('call' not in ref or e.get('call') == ref['call']) for e in events)
    actual_core = [e for e in get('_collision_core')]
    assert len(actual_core) == len(r['core_checks'])
    for e, check in zip(actual_core, r['core_checks']):
        assert core_event_check(e) == check['branch'] and bool(e['returned']) == check['result']
        if e['line'] == 1039:
            interval = [v for v in events if v.get('parent') == e['call'] and v['function'] == 'FrameRays.collision_axis_interval']
            assert len(interval) == 1 and interval[0]['line'] == 470
            s = interval[0]['state']
            assert len(vals(s['near'])) < 4 or len(vals(s['local'])) < 2
    # Verify final report assignment against actual q/hold state; final warning payload remains visible.
    for t in att['final_target_tracks']:
        es = [e for e in events if e.get('checkpoint', '').startswith('t.reported = (q or')
              and e['state'].get('track', {}).get('id') == t['id']]
        assert es
        s = es[0]['state']; before = s['track']
        predicted = bool(s['q'] or (before['reported'] and 0 < before['misses'] <= tracking_cfg['hold_misses'])
            or (before['reported'] and before['hold'] > 0) or (s['explained_blocked'] and before['misses'] == 0))
        assert predicted == t['reported']
        payload = [d for d in visible['output']['detections'] + visible['output']['warnings'] if d['id'] == t['id']]
        assert len(payload) == int(t['reported'])
        if payload: assert payload[0]['zone'] == t['zone'] == 'warning'
    return len(actual_core)


PRIVATE_ADDRESS = re.compile(r'\b(?:192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b')
SSH_CONNECTION = re.compile(r'\b[A-Za-z_][A-Za-z0-9_.-]*@(?:[A-Za-z0-9_.-]+)')


def privacy_check(names, bundle_text):
    scanned = []
    for name in names:
        if name.endswith(('.md', '.json', '.py')) or name.startswith('SHA256SUMS'):
            text = (HERE / name).read_text()
            assert not PRIVATE_ADDRESS.search(text), ('private address', name)
            assert not SSH_CONNECTION.search(text), ('SSH connection string', name)
            scanned.append(name)
    assert not PRIVATE_ADDRESS.search(bundle_text) and not SSH_CONNECTION.search(bundle_text)
    positive = 'operator' + '@' + '.'.join(['192', '168', '2', '9'])
    assert PRIVATE_ADDRESS.search(positive) and SSH_CONNECTION.search(positive)
    return dict(files=scanned, compressed_evidence_decompressed_scanned=True, planted_private_connection_detected=True)


def load_bundle():
    text = gzip.decompress((HERE / 'publication-evidence.json.gz').read_bytes()).decode()
    return unpack(json.loads(text)), text


def check_data(bundle):
    visible = {r['k']: r for r in bundle['visible_rows']}
    misses = bundle['miss_snapshots']
    assert len(visible) == 177 and len(misses) == 63 and len(bundle['full_snapshot_records']) == 340
    report = json.loads((HERE / 'report.json').read_text())
    tc = bundle['effective_config']['traced']['tracking']
    meta = bundle['placement_inputs']['frame_metadata']; base = bundle['placement_inputs']['baseline_rows']
    icp = bundle['placement_inputs']['icp']
    steps = [0.] * len(meta)
    for i, dx in zip(icp['i'], icp['dx'], strict=True): steps[i] = dx
    smooth = [max(0., statistics.median(steps[min(max(j, 0), len(steps)-1)] for j in range(i-3, i+4)))
              for i in range(len(steps))]
    sums, total = [], 0.
    for step in smooth: total += step; sums.append(total)
    hits = 0
    for k, r in visible.items():
        p, m = r['placement'], r['matching']; x, y = p['exact']['X'], p['exact']['Y']
        rx = 230. - (sums[k] - sums[150]); xc = rx + .15
        ry = base[k]['center'] + math.tan(base[k]['yaw']) * xc + .5 * base[k]['curv'] * xc * xc
        assert abs(rx - x) < 1e-12 and abs(ry - y) < 1e-12
        ids = match(r['output']['detections'], x, y)
        assert ids == m['ids'] and bool(ids) == m['hit']
        hits += bool(ids)
        target = r['target_support']['input_target']
        assert len(target['xyz']) == m['raw_target_returns'] == 2 * p['rounded_evaluator_input']['n_obj']
        assert len(r['target_support']['processed_target']) == len(target['xyz'])
        assert all(math.isfinite(v) for v in target['xyz'].flat)
        assert 'xyz' not in r['output'] and not r['source_snapshot']['whole_processed_cloud']['published']
    core_count, labels = 0, collections.Counter()
    for r in misses:
        assert not visible[r['k']]['matching']['hit']
        core_count += validate_miss(r, visible[r['k']], tc)
        labels[r['attribution']['primary']] += 1
    assert hits == 114 and labels == report['primary_label_counts'] and core_count == 61
    miss_set = {k for k, r in visible.items() if not r['matching']['hit']}
    assert miss_set == {r['k'] for r in misses} == set(report['historical']['expected_miss_rows'])
    # Data-oriented positive controls exercise these same checking paths.
    positive = visible[164]
    assert match(positive['output']['detections'], positive['placement']['exact']['X'], positive['placement']['exact']['Y'])
    assert not match([], positive['placement']['exact']['X'], positive['placement']['exact']['Y'])
    damaged = copy.deepcopy(next(r for r in misses if r['attribution']['primary'] == 'column_hold'))
    damaged['branch_events'] = [e for e in damaged['branch_events'] if not e['function'].endswith('.column_held')]
    missing_branch_detected = False
    try: validate_miss(damaged, visible[damaged['k']], tc)
    except AssertionError: missing_branch_detected = True
    assert missing_branch_detected
    candidate = next(e for r in misses for e in r['branch_events']
                     if e['function'] == '_collision_core' and e.get('line') == 1045 and len(vals(e['state']['keep'])))
    damaged = copy.deepcopy(candidate); damaged['state']['keep'].flat[0] = not damaged['state']['keep'].flat[0]
    mask_change_detected = False
    try: core_event_check(damaged)
    except AssertionError: mask_change_detected = True
    assert mask_change_detected
    all_arrays = []
    def collect(x):
        if isinstance(x, Array): all_arrays.append(x)
        elif isinstance(x, dict):
            for value in x.values(): collect(value)
        elif isinstance(x, (list, tuple)):
            for value in x: collect(value)
    collect(bundle)
    whole_shapes = {tuple(r['whole_processed_cloud']['shape']) for r in bundle['full_snapshot_records']}
    contains_whole_cloud_shape = lambda shapes: any(s in whole_shapes for s in shapes)
    assert not contains_whole_cloud_shape(a.shape for a in all_arrays)
    assert contains_whole_cloud_shape([next(iter(whole_shapes))])
    return dict(status='PASS', replay_repeated=False, git_operations=False, visible_rows_checked=177,
        full_precision_hits=114, visible_misses=63, verified_primary_counts=dict(labels),
        miss_branch_records=63, core_miss_calls_checked=core_count,
        branch_events=sum(len(r['branch_events']) for r in misses),
        encoded_arrays_checked=len(all_arrays), largest_candidate_or_target_point_array=max(
            [a.shape[0] for a in all_arrays if len(a.shape) == 2 and a.shape[1] == 3]),
        whole_raw_clouds_present=False, full_snapshot_hash_records=340,
        historical_miss_set_equal=True, controls=dict(lost_hit_and_payload=True,
            deleted_actual_branch_detected=missing_branch_detected, changed_core_mask_detected=mask_change_detected,
            planted_whole_cloud_shape_detected=True),
        limitation='Portable records verify target matching and miss attribution; full-scene exact replay equality is a production receipt plus VM-only capture hashes.')


def verify_historical():
    storage = json.loads((HERE / 'storage-map.json').read_text())
    for name, record in storage['original_production_receipts'].items():
        assert sha(HERE / name) == record['sha256'], ('historical receipt changed', name)
    mapping = {r['original_name']: r['new_path'] for r in storage['operations']}
    rows = []
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = Path(mapping.get(name, HERE / name))
        assert sha(path) == expected, (name, path)
        rows.append(dict(historical_name=name, resolved_path=str(path), sha256=expected, matched=True))
    return dict(status='PASS_ALL_ORIGINAL_PRODUCTION_CHECKSUMS_RESOLVED',
        original_sha256sums_sha256=sha(HERE / 'SHA256SUMS'), receipts_preserved_byte_for_byte=True,
        historical_paths=True, rows=rows)


def check_vm(bundle):
    from build_publication import WORK, ieee_hash, pack, stream
    records = {r['k']: r for r in bundle['full_snapshot_records']}
    original_encoded = json.loads(gzip.decompress((HERE / 'publication-evidence.json.gz').read_bytes()))
    visible = {r['k']: r for r in original_encoded['visible_rows']}
    misses = {r['k']: r for r in original_encoded['miss_snapshots']}
    for mode, value in bundle['source_capture_sha256'].items(): assert sha(WORK / (mode + '.pkl.gz')) == value
    n, ne, ns = 0, 0, 0
    for rec in stream(WORK / 'traced.pkl.gz'):
        k = rec['k']; hashes = records[k]
        assert ieee_hash(rec) == hashes['full_snapshot_ieee_sha256']
        assert ieee_hash(rec['frame_result']) == hashes['frame_result_ieee_sha256']
        assert hashlib.sha256(rec['frame_result']['xyz'].tobytes()).hexdigest() == hashes['whole_processed_cloud']['byte_sha256']
        n += 1
        if k in visible:
            v = visible[k]; first = rec['input_target']['first_index']
            assert v['target_support']['input_target'] == pack(rec['input_target'])
            assert v['target_support']['processed_target'] == pack(rec['frame_result']['xyz'][first:])
            for key, value in rec['frame_result'].items():
                if key not in ['xyz', 'corridor_idx', 'candidates']: assert v['output'][key] == pack(value)
            ns += 1
        if k in misses:
            m = misses[k]
            assert m['branch_events'] == pack(rec['events'])
            assert m['tracker_states'] == pack(rec['tracks'])
            assert m['candidates'] == pack(rec['frame_result']['candidates'])
            assert m['thin'] == pack(rec['thin']) and m['low_height'] == pack(rec['low_height'])
            ne += 1
    assert (n, ns, ne) == (340, 177, 63)
    return dict(status='PASS_EXACT_PROJECTION_FROM_EXISTING_VM_CAPTURES', full_snapshot_hashes_verified=n,
        target_support_and_outputs_exact=ns, all_captured_miss_events_states_exact=ne, replay_repeated=False,
        historical_receipts=verify_historical())


def checksum_check():
    manifest = json.loads((HERE / 'publication-manifest.json').read_text())
    intended = set(manifest['payload_files']) | set(manifest['metadata_files'])
    assert not any((HERE / n).stat().st_size > 20_000_000 for n in intended)
    for name, info in manifest['payload_files'].items():
        assert (HERE / name).stat().st_size == info['bytes'] and sha(HERE / name) == info['sha256']
    checksummed = set()
    for line in (HERE / 'SHA256SUMS-publication').read_text().splitlines():
        expected, name = line.split('  ', 1); assert sha(HERE / name) == expected; checksummed.add(name)
    assert checksummed == intended - {'SHA256SUMS-publication'}
    total = sum((HERE / name).stat().st_size for name in intended)
    assert total <= 15_000_000
    # Positive checksum control: one changed byte must change the expected hash.
    data = (HERE / 'PUBLICATION.md').read_bytes()
    assert hashlib.sha256(data + b' ').hexdigest() != manifest['payload_files']['PUBLICATION.md']['sha256']
    return dict(files=len(intended), total_bytes=total, max_file_bytes=max((HERE / n).stat().st_size for n in intended),
                all_checksums_equal=True, planted_changed_byte_detected=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--vm', action='store_true'); p.add_argument('--data-only', action='store_true')
    args = p.parse_args(); bundle, text = load_bundle()
    result = {'data': check_data(bundle)}
    if not args.data_only:
        result['publication_checksums'] = checksum_check()
        manifest = json.loads((HERE / 'publication-manifest.json').read_text())
        result['privacy'] = privacy_check(list(manifest['payload_files']) + manifest['metadata_files'], text)
    if args.vm: result['vm'] = check_vm(bundle)
    print(json.dumps(result, indent=2))
