import datetime,gzip,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/home/resense/ReSense')
source=Path('/home/resense/data/final_lidar_cecab1b')
out=root/'docs/evidence/n1_n4_2026-10-18/final_core_cecab1b'
raw=Path('/home/resense/data/n4_final_cecab1b');raw.mkdir(exist_ok=True)
assert not (raw/'report.json').exists()
old=json.loads((root/'docs/evidence/n1_n4_2026-10-18/final_core_7b7b02c/image_receipt.json').read_text())
files={name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in old['verified_files']}
probe="import pathlib,hashlib,json; from resense.config import DetectorConfig; from resense import _native; import resense.config; names="+repr(files)+"; actual={n:hashlib.sha256((pathlib.Path('/opt/resense')/n).read_bytes()).hexdigest() for n in names}; assert actual==names; assert DetectorConfig().calibration.orientation_replay_frames==0; assert DetectorConfig.from_yaml('/opt/resense/ros2_ws/install/resense_ros/share/resense_ros/config/detector.yaml').calibration.orientation_replay_frames==0; print(json.dumps({'files':actual,'installed_config':resense.config.__file__,'installed_config_sha256':hashlib.sha256(pathlib.Path(resense.config.__file__).read_bytes()).hexdigest(),'native_status':_native.status(),'native_files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(resense.config.__file__).parent.glob('*.so')}}))"
image_id=subprocess.check_output(['docker','image','inspect','resense:lidar-cecab1b','--format','{{.Id}}'],text=True).strip()
probe_result=json.loads(subprocess.check_output(['docker','run','--rm','--network','none','-w','/','resense:lidar-cecab1b','python3','-c',probe],text=True))
assert probe_result['installed_config_sha256']==files['resense/config.py']
assert probe_result['native_status'].startswith('native')
assert list(probe_result['native_files'].values())==['dc549d0583f92c3acd93c455bf94bab4bbedae35a9580d82ad24786473661d5c']
(out/'image_receipt.json').write_text(json.dumps({'core_commit':'cecab1b696b8c2e101207601acd8faed96c8bfb8','base_image_id':old['image_id'],'image_id':image_id,'image_tag':'resense:lidar-cecab1b','verified_files':files,'node_import_context':probe_result,'dockerfile_sha256':hashlib.sha256((out/'Dockerfile').read_bytes()).hexdigest()},indent=2)+'\n')
command=['docker','run','--rm','--name','resense-n4-cecab1b','--network','none','--ipc=host','-v','/home/resense/data/n4_smoke:/bags:ro','-v','/home/resense/data/n2/falcon_first100:/falcon:ro','-v',str(raw)+':/out','resense:lidar-cecab1b','python3','scripts/check_interactive_replay.py','/bags','--out','/out','--falcon-bag','/falcon']
receipt={'source_commit':'cecab1b696b8c2e101207601acd8faed96c8bfb8','image_id':image_id,'command':command,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'isolated_window_sha256':hashlib.sha256((root/'docs/evidence/lidar_adaptation_2026-10-18/default_off/isolated_window.json').read_bytes()).hexdigest()}
with (raw/'runner.log').open('w') as log:
 result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
receipt.update(returncode=result.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
receipt['raw_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raw.iterdir() if p.is_file()}
for p in raw.iterdir():
 if not p.is_file(): continue
 if p.suffix in ('.log','.jsonl'): (out/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 else: (out/p.name).write_bytes(p.read_bytes())
(out/'run_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(result.returncode)
