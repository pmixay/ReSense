"""Separate final receipt/summary check; no import of the review implementation."""
import collections
import gzip
import hashlib
import json
from pathlib import Path
import pickle
import struct
import subprocess
import sys
sys.dont_write_bytecode = True

ROOT=Path('/home/aiops/resense')
HERE=ROOT/'docs/evidence/h1_final_review_2026-10-20'
RAIL=ROOT/'docs/evidence/h1_rail_limits_2026-10-20'
MISS=ROOT/'docs/evidence/h1_miss_audit_2026-10-20'
r=json.loads((HERE/'report.json').read_text())
assert r['audit_completed'] and r['h1_feature_acceptance']=='BLOCKED' and not r['h1_closed']
print('SOURCE MAPS',r['sources']['audit_source_comparisons'])
print('MISS',r['miss_audit']['hits'],r['miss_audit']['miss_count'],r['miss_audit']['primary_counts'])
print('ALL LABELS',r['miss_audit']['all_label_counts'])
print('CORE MISS EXITS',r['miss_audit']['core_exits'])
print('REFERENCE',r['reference']['direct_first_failed_counts'],r['reference']['validation_observations'],
      {k:v['pass_tracks'] for k,v in r['reference']['landmarks'].items()},r['reference']['raw_support_centroids'])
print('PACKAGE',r['publication'])
print('SECONDARY',r['author_standalone_secondary']['vm']['full_snapshot_hashes_verified'],
      len(r['author_standalone_secondary']['vm']['historical_receipts']['rows']))

# All A-row decisions from original raw detection positions, an independently
# expressed interval matcher; do not use the report's hit/count input.
raw=[]
with gzip.open('/tmp/opencode/h1-miss-audit/plain.pkl.gz','rb') as f:
    while True:
        try: a=pickle.load(f)
        except EOFError: break
        x,y=a['exact']['X'],a['exact']['Y']
        if a['info']['n_obj']<=0 or x is None or x<=3: continue
        w=.15+(2. if x<200/3 else x*.03)
        hits=[d['id'] for d in a['frame_result']['detections'] if x-w<=d['distance']<=x+w and y-1.15<=d['center'][1]<=y+1.15]
        raw.append((a['k'],hits))
reported=[(v['k'],v['ids']) for v in r['miss_audit']['visible_rows']]
assert raw==reported
assert (len(raw),sum(bool(ids) for _,ids in raw))==(177,114)

# Every directed decision, plus the model axis at the target, is checked against
# the existing independent captures. This is a second expression, no fresh replay.
direct=[]
for case in r['directed']['rows']:
    data=json.loads((RAIL/(case['name']+'.json')).read_text())
    states=[]
    for published,frame in zip(case['rows'],data['frames'],strict=True):
        spec=data['inputs'][frame['input']]['geometry']; d=spec.get('distance',67.); y=spec.get('lateral',.68)
        ds=[o for o in frame['output']['detections'] if d-1<o['distance']<d+1 and y-.5<o['center'][1]<y+.5]
        assert bool(ds)==published['target_STOP']
        assert bool(frame['output']['detections'])==published['global_STOP']
        assert any(c['collision_core'] for c in frame['output']['candidates'])==published['all_candidate_core']
        states.append(frame['i'])
    direct.append((case['name'],len(states)))
assert len(direct)==31 and sum(n for _,n in direct)==518

for name in ['wrong_0.6_1.5_67.0','wrong_0.4_-0.68_67.0','wrong_0.6_1.5_17.0','actual_floor_held','loss_target_remains','loss_target_absent']:
    data=json.loads((RAIL/(name+'.json')).read_text()); final=data['frames'][-1]
    print('RAW CASE',name,'INPUT',data['inputs'][final['input']]['target_bounds'],'FINAL MODEL',
          {k:final['output']['track'][k] for k in ['center','yaw','curvature','rail_slabs','floor_held']})

# Script byte identity and source/index identity are checked again independently.
source_sha=hashlib.sha256((HERE/'review_h1.py').read_bytes()).hexdigest()
assert source_sha==r['checked_inputs'][str(HERE/'review_h1.py')]['sha256']
for name,h in r['sources']['current']['files'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
assert hashlib.sha256((ROOT/'.git/index').read_bytes()).hexdigest()==r['sources']['current']['index_sha256']
assert subprocess.check_output(['git','--no-optional-locks','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==r['sources']['current']['head']
result=dict(status='PASS',method='Separate script; no review implementation imported',
            independent_raw_visible_matching_rows=len(raw),independent_directed_output_rows=sum(n for _,n in direct),
            directed_sequences=len(direct),report_sha256=hashlib.sha256((HERE/'report.json').read_bytes()).hexdigest(),
            script_sha256=source_sha,index_sha256=r['sources']['current']['index_sha256'],source_files_checked=len(r['sources']['current']['files']))
with (HERE/'crosscheck.json').open('x') as f: json.dump(result,f,indent=2); f.write('\n')
print(json.dumps(result))
