#!/usr/bin/env python3
"""Fresh H1 acceptance review. Inputs read-only; exclusive report in this directory.

No author audit module is imported. Only directed synthetic NPZ sequences are
replayed; original A captures are compared, not replayed. No G3 or full battery.
Temporary freeze controls are confined to /tmp/opencode/h1-final-review.
"""
from __future__ import annotations
import argparse
import base64
import collections
import copy
import dataclasses
import datetime
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import pickle
import shutil
import sqlite3
import statistics
import struct
import subprocess
import sys
import tarfile
import time
import uuid

sys.dont_write_bytecode = True
import numpy as np

ROOT = Path('/home/aiops/resense')
OUT = ROOT / 'docs/evidence/h1_final_review_2026-10-20'
TMP = Path('/tmp/opencode/h1-final-review')
E = ROOT / 'docs/evidence'
REF = E / 'h1_independent_2026-10-20'
MISS = E / 'h1_miss_audit_2026-10-20'
RAIL = E / 'h1_rail_limits_2026-10-20'
WORK = Path('/tmp/opencode/h1-miss-audit')
HEAD = 'f56ad5e62d9d051811c804734c7731b6951eae90'
SEAL = 'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json'
READS = {}


def need(ok, context):
    if not ok:
        raise AssertionError(context)


def sha(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def receipt(path):
    path = Path(path).resolve()
    s = path.stat()
    value = dict(bytes=s.st_size, sha256=sha(path), stat=[s.st_size, s.st_mtime_ns, s.st_ino])
    if str(path) in READS:
        need(READS[str(path)] == value, ('input changed', str(path)))
    READS[str(path)] = value
    return value


def load(path):
    receipt(path)
    return json.loads(Path(path).read_text())


def git(*args, binary=False):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ROOT), *args],
                                   text=not binary, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


def unpack(v):
    if isinstance(v, list): return [unpack(x) for x in v]
    if isinstance(v, dict):
        if '__ndarray__' in v:
            return np.frombuffer(base64.b64decode(v['base64'], validate=True),
                                 dtype=v['dtype']).reshape(v['shape']).copy()
        if '__numpy_scalar__' in v:
            return np.frombuffer(base64.b64decode(v['base64'], validate=True), dtype=v['__numpy_scalar__'])[0]
        if '__tuple__' in v: return tuple(unpack(x) for x in v['__tuple__'])
        if '__float64_bits__' in v: return struct.unpack('<d', bytes.fromhex(v['__float64_bits__']))[0]
        return {k: unpack(x) for k, x in v.items()}
    return v


def equal(a, b):
    if type(a) is not type(b): return False
    if isinstance(a, np.ndarray):
        return a.dtype.str == b.dtype.str and a.shape == b.shape and a.tobytes() == b.tobytes()
    if isinstance(a, np.generic): return a.dtype.str == b.dtype.str and a.tobytes() == b.tobytes()
    if isinstance(a, float): return struct.pack('>d', a) == struct.pack('>d', b)
    if isinstance(a, dict): return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (tuple, list)): return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def capture_hash(value):
    """Published length-delimited IEEE format, implemented here without author imports."""
    h = hashlib.sha256()
    def put(tag, data): h.update(tag + len(data).to_bytes(8, 'little') + data)
    def walk(v):
        if isinstance(v, np.ndarray):
            put(b'array', str((v.dtype.str, v.shape)).encode()); put(b'bytes', v.tobytes())
        elif isinstance(v, np.generic): put(b'np', v.dtype.str.encode() + v.tobytes())
        elif isinstance(v, float): put(b'f64', struct.pack('<d', v))
        elif isinstance(v, dict):
            put(b'dict', str(len(v)).encode())
            for k in sorted(v): walk(k); walk(v[k])
        elif isinstance(v, (tuple, list)):
            put(b'tuple' if isinstance(v, tuple) else b'list', str(len(v)).encode())
            for x in v: walk(x)
        else: put(type(v).__name__.encode(), repr(v).encode())
    walk(value)
    return h.hexdigest()


def stream(path):
    with gzip.open(path, 'rb') as f:
        while True:
            try: yield pickle.load(f)
            except EOFError: return


def fingerprint(v):
    if dataclasses.is_dataclass(v): return {f.name: fingerprint(getattr(v, f.name)) for f in dataclasses.fields(v)}
    if isinstance(v, np.ndarray):
        return dict(dtype=v.dtype.str, shape=list(v.shape), sha256=hashlib.sha256(v.tobytes()).hexdigest())
    if isinstance(v, np.generic): return fingerprint(np.asarray(v))
    if isinstance(v, float): return dict(f64=struct.pack('>d', v).hex())
    if isinstance(v, dict): return {str(k): fingerprint(x) for k, x in v.items()}
    if isinstance(v, (tuple, list)): return [fingerprint(x) for x in v]
    return v


def source_snapshot():
    seal = json.loads((ROOT/SEAL).read_text())
    names = set(git('ls-files', 'resense', 'native', 'configs', 'ros2_ws', 'setup.py', 'pyproject.toml').splitlines()) | set(seal['files'])
    files = {n: sha(ROOT/n) for n in sorted(names)}
    for n, h in files.items():
        need(hashlib.sha256(git('show', f'{HEAD}:{n}', binary=True)).hexdigest() == h, ('HEAD source', n))
    return dict(head=git('rev-parse', 'HEAD').strip(), index_sha256=sha(ROOT/'.git/index'), files=files)


def check_sources(before):
    need(before['head'] == HEAD, 'unexpected HEAD')
    seal = load(ROOT/SEAL)
    need(all(before['files'][n] == h for n, h in seal['files'].items()), 'sealed source bytes')
    need(hashlib.sha256(json.dumps(seal['files'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
         == seal['source_sha256'], 'seal inventory digest')
    ref = load(REF/'report.json')
    miss = load(MISS/'manifest-before.json')
    rail = load(RAIL/'manifest-before.json')
    comparisons = {}
    for label, sources in [('reference', {n: v['sha256'] for n, v in ref['current_git_source']['production_files'].items()}),
                            ('miss', {str(Path(n).relative_to(ROOT)): h for n, h in miss['sources'].items()}),
                            ('rail', rail['files'])]:
        common = set(seal['files']) & set(sources)
        for n in common: need(sources[n] == before['files'][n], (label, n))
        native_binaries = {n: h for n, h in sources.items() if n.startswith(('resense/', 'native/')) and n.endswith('.so')}
        for n, h in native_binaries.items(): need(receipt(ROOT/n)['sha256'] == h, (label, 'native binary', n))
        comparisons[label] = dict(sealed_files_equal=len(common), named_source_files=len(sources),
                                  sealed_files_not_in_author_source_map=sorted(set(seal['files'])-set(sources)),
                                  native_binaries_equal=native_binaries)
    report = load(MISS/'report.json')
    need(report['source_commit'] == HEAD and miss['head'] == HEAD and rail['head'] == HEAD
         and ref['current_git_source']['head'] == HEAD, 'audit commits')
    need(report['source_digest'] == miss['source_digest'], 'miss report source digest link')
    h = hashlib.sha256()
    def atom(tag, raw): h.update(tag+struct.pack('>Q', len(raw))+raw)
    atom(b'D', str(len(miss['sources'])).encode())
    for n in sorted(miss['sources']):
        for v in (n, miss['sources'][n]): atom(b'str:', repr(v).encode())
    need(h.hexdigest() == miss['source_digest'], 'miss source map digest')
    # This is the stdlib verifier, not an evidence-author tool or data rerun.
    command = ['python3', '-B', str(ROOT/'scripts/detector_freeze.py'), 'verify']
    good = subprocess.run(command, capture_output=True, text=True)
    need(good.returncode == 0, ('freeze', good.stderr))
    temp = TMP / ('freeze-control-' + uuid.uuid4().hex)
    temp.mkdir()
    for n in set(seal['files']) | {SEAL, 'scripts/detector_freeze.py', seal['baseline']['path'], seal['validation']['path']}:
        dest = temp/n; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT/n, dest)
    control_cmd = ['python3', '-B', str(temp/'scripts/detector_freeze.py'), 'verify']
    clean = subprocess.run(control_cmd, capture_output=True, text=True)
    need(clean.returncode == 0, ('clean control', clean.stderr))
    with (temp/'resense/track.py').open('ab') as f: f.write(b'\n# deliberately planted review-only byte change\n')
    tampered = subprocess.run(control_cmd, capture_output=True, text=True)
    need(tampered.returncode != 0 and 'changed detector file: resense/track.py' in tampered.stderr,
         ('tampered source escaped freeze', tampered.stdout, tampered.stderr))
    return dict(current=before, seal_digest=seal['source_sha256'], audit_source_comparisons=comparisons,
                stdlib_freeze=dict(returncode=good.returncode, stdout=good.stdout),
                positive_control=dict(clean_copy_passed=True, tampered_copy_rejected=True, stderr=tampered.stderr),
                full_battery_rerun=False)


def package_check():
    manifest = load(MISS/'publication-manifest.json')
    names = set(manifest['payload_files']) | set(manifest['metadata_files'])
    for n, v in manifest['payload_files'].items():
        need(Path(n).name == n, ('unsafe allowlist', n))
        r = receipt(MISS/n)
        need(r['sha256'] == v['sha256'] and r['bytes'] == v['bytes'] and r['bytes'] <= 20_000_000, ('publication', n))
    listed = {}
    receipt(MISS/'SHA256SUMS-publication')
    for line in (MISS/'SHA256SUMS-publication').read_text().splitlines():
        h, n = line.split('  ', 1); need(n not in listed, ('duplicate checksum', n)); listed[n] = h
        need(receipt(MISS/n)['sha256'] == h, ('publication checksum', n))
    need(set(listed) == names - {'SHA256SUMS-publication'}, 'allowlist/checksum coverage')
    need('source-tools-input-metadata.tar.gz' not in names and 'raw-captures.tar.gz' not in names,
         'VM-only archive unexpectedly allowlisted')
    rail_manifest = load(RAIL/'artifact-manifest.json')
    for n, v in rail_manifest['files'].items():
        r = receipt(RAIL/n)
        need(r['sha256'] == v['sha256'] and r['bytes'] == v['bytes'] and r['bytes'] < 20_000_000, ('rail artifact', n))
    text = gzip.decompress((MISS/'publication-evidence.json.gz').read_bytes())
    bundle = unpack(json.loads(text))
    controls = dict(changed_byte_detected=hashlib.sha256((MISS/'PUBLICATION.md').read_bytes()+b'!').hexdigest()
                    != manifest['payload_files']['PUBLICATION.md']['sha256'])
    return bundle, dict(allowlisted_files=len(names), total_bytes=sum((MISS/n).stat().st_size for n in names),
                        largest_bytes=max((MISS/n).stat().st_size for n in names),
                        rail_manifest_files=len(rail_manifest['files']), controls=controls)


def raw_matches(dets, x, y, dx=None, dy=1.15):
    limit = max(2., .03*x)+.15 if dx is None else dx
    return [i for i, d in enumerate(dets) if abs(float(d['distance'])-x) <= limit
            and abs(float(np.asarray(d['center'])[1])-y) <= dy]


def core_from_event(e):
    s = e['state']; c = s['cfg']; g = s['gauge']; p = np.asarray(s['blob']['pts'])
    ext = np.ptp(p, axis=0)
    if e['line'] == 1032:
        need(not e['returned'] and (g is None or c['column_core_margin'] <= 0 or max(ext[:2]) > c['column_core_max_footprint']), 'core prereq')
        return 'footprint', False
    keep_current = (s['blob_frame_idx'] >= 0) & s['blob_in_gauge'] & s['blob_in_rail']
    need(equal(keep_current, s['current']), 'core current mask')
    if e['line'] == 1036:
        need(keep_current.sum() < c['column_core_min_voxels'] and not e['returned'], 'core support')
        return 'current_support', False
    if e['line'] == 1039:
        need(s['interval'] is None and not e['returned'], 'core no interval')
        return 'no_interval', False
    need(e['line'] == 1045, ('unknown core exit', e['line']))
    # Default profile is a rectangle. Direct four inequalities are independent of
    # both production XOR polygon code and the author's crossing-number verifier.
    need(np.array_equal(g['profile'], [[-1.05, .12], [1.05, .12], [1.05, 3.], [-1.05, 3.]]), 'profile changed')
    idx = np.flatnonzero(keep_current); x = p[idx, 0].astype(float)
    margin = g['edge_margin'] + c['column_core_margin'] + g['edge_margin_per_100m']*x/100
    margin += max(0., g['edge_margin_per_100m2'])*(x/100)**2
    h = s['blob_h'][idx]; mask = np.ones(len(idx), bool)
    for delta in s['interval']:
        d = s['blob_dy'][idx]-delta; z = d + np.sign(d)*margin
        mask &= (z >= -1.05) & (z < 1.05) & (h >= .12) & (h < 3.)
    need(equal(mask, s['keep']), 'independent rectangular erosion')
    retained = idx[mask]
    need(equal(s['blob']['idx'][retained], s['k']), 'retained indices')
    passed = bool(len(retained) and len(set(s['blob_inv'][retained])) >= c['column_core_min_voxels']
                  and np.ptp(s['blob_h'][retained]) >= c['column_core_min_height']
                  and min(s['blob_h'][retained]) <= c['far_max_bottom'])
    need(passed == bool(e['returned']), 'core body bars')
    return 'body_bars', passed


def zone(t):
    held = t['column_hold'] > 0 and sum(t['column_hist']) >= t['column_hold'] and not t['collision_core_ready']
    if t['withheld'] or t['fresh_blocked'] or not t['zone_hist'] or held or t['approach_block']: return 'warning'
    if t['near_hits'] > 0 and len(t['near_hist']) >= t['near_hits'] and all(t['near_hist'][-t['near_hits']:]): return 'gauge'
    if t['settled_out']: return 'warning'
    return 'gauge' if sum(t['zone_hist']) >= t['zone_min_fraction']*max(len(t['zone_hist']), t['zone_min_votes'])-1e-9 else 'warning'


def derive_miss(rec, target_tracks, tc):
    first = rec['input_target']['first_index']; last = rec['frame_result']['n_points']
    tids = {t['id'] for t in target_tracks}; events = rec['events']
    def target(e):
        s = e.get('state', {}); fi = np.asarray(s.get('blob_frame_idx', []))
        return bool(np.any((fi >= first) & (fi < last))) or s.get('track', {}).get('id') in tids
    target_events = [e for e in events if target(e)]
    def get(name): return [e for e in target_events if e['function'].split('.')[-1] == name and 'returned' in e]
    labels = set(); proofs = []; cores = []
    def add(label, e, detail):
        labels.add(label); proofs.append(dict(label=label, function=e['function'], line=e.get('line'), call=e.get('call'), detail=detail))
    for e in get('_advisory_reason'):
        s = e['state']; c = s['cfg']; ext = np.ptp(s['blob']['pts'], axis=0)
        if e['returned'] == 'beyond_axis':
            need(e['line'] == 734 and s['dist'] > s['axis_valid'], 'actual axis exit')
            add('axis_limit', e, dict(distance=s['dist'], limit=s['axis_valid']))
        elif e['returned'] == 'beyond_height_ref':
            need(e['line'] == 737 and s['dist'] > s['height_valid'] and
                 (ext[2] < c['far_min_height'] or ext[0] > c['far_max_length'] or s['h_min'] > c['far_max_bottom']), 'actual height exit')
            add('height_reference_limit', e, dict(extent=ext.tolist(), distance=s['dist'], limit=s['height_valid']))
        elif e['returned'] == 'column':
            need(e['line'] == 756 and ext[2] > c['column_min_height'] and s['col_w'] < c['column_max_width']
                 and (s['off_centre'] or s['col_w'] >= c['column_min_width']), 'actual column exit')
            siblings = [v for v in get('_collision_core') if v.get('parent') == e.get('parent')]
            need(siblings and all(not v['returned'] for v in siblings), 'column/core relation')
            add('column_demotion', e, dict(height=float(ext[2]), width=s['col_w']))
    calls = {e['call'] for e in get('_corridor_cluster')}
    for e in events:
        if e['function'] == '_is_infrastructure' and e.get('parent') in calls and e.get('returned'):
            s = e['state']; c = s['cfg']; ext = np.asarray(s['size'])
            need(e['line'] == 376 and ext[2] > c['wall_min_height'] and ext[0] > c['wall_segment_min_length']
                 and ext[1] < c['wall_segment_max_width'], 'actual merged wall exit')
            need(any(v['line'] == 1121 and v['returned'] is None for v in get('_corridor_cluster')), 'parent early return')
            add('merged_wall_segment_filter', e, dict(extent=ext.tolist()))
    for e in get('column_held'):
        if e['returned']:
            t = e['state']['track']
            need(t['column_hold'] > 0 and sum(t['column_hist']) >= t['column_hold'] and not t['collision_core_ready'], 'actual held')
            add('column_hold', e, dict(votes=sum(t['column_hist']), threshold=t['column_hold'],
                                     core_hits=t['collision_core_hits'], core_span=t['collision_core_span_s']))
            break
    for e in get('vote_zone'):
        if e['returned'] == 'warning':
            t = e['state']['track']; denom = max(len(t['zone_hist']), t['zone_min_votes'])
            need(sum(t['zone_hist']) < t['zone_min_fraction']*denom-1e-9, 'actual vote')
            add('zone_vote_delay', e, dict(votes=sum(t['zone_hist']), denominator=denom, fraction=t['zone_min_fraction']))
            break
    for e in get('_qualifies'):
        s = e['state']; t = s['track']
        conditions = [t['hits'] >= s['need_hits'], t['confidence'] >= tc['conf_threshold'], t['misses'] == 0,
                      t['span_s'] >= s['need_span']-1e-9,
                      tc['min_hit_fraction'] <= 0 or sum(t['hit_hist'])/len(t['hit_hist']) >= tc['min_hit_fraction']-1e-9]
        need(all(conditions) == bool(e['returned']), 'actual qualification')
        if not e['returned'] and t['misses'] == 0:
            add('tracker_unconfirmed', e, dict(hits=t['hits'], need_hits=s['need_hits'], span=t['span_s'], need_span=s['need_span']))
    for e in get('_collision_core'):
        reason, result = core_from_event(e)
        if reason == 'no_interval':
            q = [v for v in events if v.get('parent') == e['call'] and v['function'] == 'FrameRays.collision_axis_interval']
            need(len(q) == 1 and q[0]['line'] == 470 and (len(q[0]['state']['near']) < 4 or len(q[0]['state']['local']) < 2), 'actual interval exit')
        cores.append(dict(line=e['line'], branch=reason, result=result))
    final = []
    for t in target_tracks:
        cps = [e for e in target_events if e.get('checkpoint', '').startswith('t.reported = (q or')
               and e['state']['track']['id'] == t['id']]
        need(cps and all(equal(cps[0]['state'], e['state']) for e in cps), 'assignment checkpoint')
        s = cps[0]['state']; old = s['track']
        reported = bool(s['q'] or (old['reported'] and 0 < old['misses'] <= tc['hold_misses'])
                        or (old['reported'] and old['hold'] > 0) or (s['explained_blocked'] and old['misses'] == 0))
        payload = [d for d in rec['frame_result']['warnings']+rec['frame_result']['detections'] if d['id'] == t['id']]
        need(reported == t['reported'] and len(payload) == int(reported), 'reported/payload')
        if payload: need(payload[0]['zone'] == zone(t) == 'warning', 'final warning zone')
        final.append(dict(id=t['id'], reported=reported, zone=zone(t), misses=t['misses'],
                          core_hits=t['collision_core_hits'], core_span_s=t['collision_core_span_s']))
    order = ['merged_wall_segment_filter', 'axis_limit', 'height_reference_limit', 'column_hold', 'zone_vote_delay', 'tracker_unconfirmed']
    primary = next((v for v in order if v in labels), None)
    need(primary is not None and len(final) == 1, 'unresolved attribution')
    # Repeated property reads carry identical evidence; keep a compact necessary record.
    unique = {(p['label'], p['function'], p['line']): p for p in proofs}
    return dict(k=rec['k'], primary=primary, labels=sorted(labels), executed_proofs=list(unique.values()), core=cores, final=final)


def review_misses(bundle):
    published = {r['k']: r for r in bundle['visible_rows']}
    misspub = {r['k']: r for r in bundle['miss_snapshots']}
    hashes = {r['k']: r for r in bundle['full_snapshot_records']}
    report = load(MISS/'report.json')
    tc = bundle['effective_config']['traced']['tracking']
    for mode, h in bundle['source_capture_sha256'].items(): need(receipt(WORK/(mode+'.pkl.gz'))['sha256'] == h, ('capture sha', mode))
    inp = bundle['placement_inputs']; meta = inp['frame_metadata']; steps = [0.]*len(meta)
    for i, dx in zip(inp['icp']['i'], inp['icp']['dx'], strict=True): steps[i] = dx
    travel = np.cumsum([max(0., sorted(steps[max(0, min(j, len(steps)-1))] for j in range(i-3, i+4))[3]) for i in range(len(steps))])
    rows = []; missrows = []; lineage = {}; fields = set(); core_counts = collections.Counter(); positive = {}; examples = []
    full_rows = []
    for a, r in zip(stream(WORK/'plain.pkl.gz'), stream(WORK/'traced.pkl.gz'), strict=True):
        k = r['k']; result = r['frame_result']; fields.update(result)
        need(a['k'] == k and equal(a['frame_result'], result), ('raw plain/traced full field difference', k))
        need(equal(a['tracks'], r['tracks']), ('raw plain/traced tracker difference', k))
        need(a['input_hash'] == r['input_hash'] and a['raw_hash'] == r['raw_hash'] and
             equal(a['exact'], r['exact']) and equal(a['input_target'], r['input_target']), ('input arm equality', k))
        need(capture_hash(r) == hashes[k]['full_snapshot_ieee_sha256'], ('full snapshot hash', k))
        need(capture_hash(result) == hashes[k]['frame_result_ieee_sha256'], ('result hash', k))
        need(hashlib.sha256(result['xyz'].tobytes()).hexdigest() == hashes[k]['whole_processed_cloud']['byte_sha256'], ('cloud hash', k))
        full_rows.append(dict(k=k, all_fields_and_tracker_equal=True, full_snapshot_hash_equal=True,
                              detections=len(result['detections']), warnings=len(result['warnings'])))
        if k not in published: continue
        v = published[k]; x = 230.-float(travel[k]-travel[150]); b = inp['baseline_rows'][k]; xc = x+.15
        y = b['center']+math.tan(b['yaw'])*xc+.5*b['curv']*xc*xc
        need(abs(x-r['exact']['X']) < 1e-12 and abs(y-r['exact']['Y']) < 1e-12, ('placement', k))
        idx = raw_matches(result['detections'], x, y); ids = [result['detections'][i]['id'] for i in idx]
        need(ids == v['matching']['ids'] and bool(idx) == v['matching']['hit'], ('matching', k))
        first = r['input_target']['first_index']; n = result['n_points']
        need(equal(v['target_support']['input_target'], r['input_target']) and
             equal(v['target_support']['processed_target'], result['xyz'][first:]), ('published target raw projection', k))
        for key in v['output']: need(equal(v['output'][key], result[key]), ('published output projection', k, key))
        need(len(r['input_target']['xyz']) == r['info']['n_obj']*2 and np.isfinite(r['input_target']['xyz']).all(), ('target returns', k))
        def overlap(t):
            fi = np.asarray(t['last']['points_idx']) if t['last'] else np.array([])
            return bool(np.any((fi >= first) & (fi < n)))
        current = [t for t in r['tracks'] if t['misses'] == 0 and overlap(t)]
        for t in current: lineage[t['id']] = t['hits']
        target_tracks = current or [t for t in r['tracks'] if t['misses'] > 0 and lineage.get(t['id']) == t['hits']]
        rows.append(dict(k=k, X=x, Y=y, hit=bool(idx), ids=ids, raw_target_returns=len(r['input_target']['xyz'])))
        if idx:
            positive.setdefault('matching', k)
            need(not raw_matches([], x, y), 'deleted hit matcher control')
            for e in r['events']:
                if e['function'].endswith('column_held') and e.get('returned') is False: positive.setdefault('released_hold', k)
                if e['function'].endswith('_qualifies') and e.get('returned') is True: positive.setdefault('qualified', k)
            if k == 164:
                damage = copy.deepcopy(result); damage['xyz'][0, 0] = np.nextafter(damage['xyz'][0, 0], np.float32(np.inf))
                need(not equal(result, damage), 'float ULP escaped comparator')
                damage = copy.deepcopy(result); damage['detections'] = []
                need(not equal(result, damage), 'removed positive payload escaped comparator')
            continue
        m = misspub[k]
        for key, original in [('branch_events', r['events']), ('tracker_states', r['tracks']),
                              ('candidates', result['candidates']), ('thin', r['thin']), ('low_height', r['low_height'])]:
            need(equal(m[key], original), ('miss projection', k, key))
        derived = derive_miss(r, target_tracks, tc)
        need(derived['primary'] == m['attribution']['primary'] and derived['labels'] == m['attribution']['labels'], ('all causal labels', k))
        for label in derived['labels']: positive.setdefault(label, k)
        core_counts.update(f"{c['branch']}:{c['result']}" for c in derived['core'])
        if any(c['result'] for c in derived['core']): positive.setdefault('core_true', k)
        if k == 319:
            core = next(e for e in r['events'] if e['function'] == '_collision_core' and e.get('returned') is True)
            damaged = copy.deepcopy(core); damaged['state']['keep'][0] = not damaged['state']['keep'][0]
            rejected = False
            try: core_from_event(damaged)
            except AssertionError as exc: rejected = str(exc) == 'independent rectangular erosion'
            need(rejected, 'changed core-mask positive control')
        missrows.append(derived)
        if k in (152, 159, 174, 177, 178, 196, 224, 306, 319, 323):
            p = result['xyz'][first:]
            examples.append(dict(k=k, primary=derived['primary'], first_xyz=p[:2].tolist(), extent=np.ptp(p,axis=0).tolist()))
            print('RAW_MISS', k, derived['primary'], 'first_xyz', p[:2].tolist(), 'extent', np.ptp(p, axis=0).tolist(), flush=True)
    need(len(full_rows) == 340 and len(rows) == 177 and len(missrows) == 63, 'capture scope')
    expected = set(report['historical']['expected_miss_rows']); actual = {r['k'] for r in missrows}
    need(expected == actual, 'historical exact miss set')
    need((actual | {164})-actual == {164} and actual-(actual-{152}) == {152}, 'set comparator controls')
    # The same verifier must reject deletion of an actually executed primary branch.
    with gzip.open(WORK/'traced.pkl.gz', 'rb') as f:
        for _ in range(225): control = pickle.load(f)
    ts = [t for t in control['tracks'] if t['id'] == misspub[224]['attribution']['final_target_tracks'][0]['id']]
    bad = copy.deepcopy(control); bad['events'] = [e for e in bad['events'] if not e['function'].endswith('column_held')]
    try:
        altered = derive_miss(bad, ts, tc)
        branch_deleted = 'column_hold' not in altered['labels']
    except AssertionError:
        branch_deleted = True
    need(branch_deleted, 'deleted actual branch not detected')
    need(not equal(-0., 0.) and not equal(np.array([1.], np.float32), np.array([1.], np.float64)), 'exact comparator controls')
    return dict(frames=340, non_timing_fields=sorted(fields), exact_raw_comparison_rows=full_rows,
                visible_rows=rows, misses=missrows, primary_counts=dict(collections.Counter(r['primary'] for r in missrows)),
                all_label_counts=dict(collections.Counter(v for r in missrows for v in r['labels'])), core_exits=dict(core_counts),
                hits=sum(r['hit'] for r in rows), miss_count=len(missrows), captured_miss_events=sum(len(r['branch_events']) for r in misspub.values()),
                raw_examples=examples, positive_controls=positive, planted_controls=dict(ULP=True, removed_positive_detection=True,
                signed_zero=True, dtype=True, deleted_actual_column_branch=True, changed_core_mask=True, historical_added_removed=True),
                historical_miss_rows_equal=True, interpretation='All labels are observed executed paths, not unique counterfactual root causes; placement remains detector-baseline-relative.')


def model_shape(m, x):
    if m is None: return np.zeros_like(x)
    return math.tan(m['yaw'])*x + .5*m['curvature']*x*x + .5*m['curv_step']*np.maximum(x-m['curv_knot'], 0)**2


def floor_height(m, x):
    u = np.clip(x, *m['floor_range']); return np.polyval(m['floor_coef'], u)+np.polyval(np.polyder(m['floor_coef']), u)*(x-u)


def rederive_fit(points, e):
    c = e['cfg']; prior = e['prior']; pc = e['prior_center']; step = c['rails_bin']; half = c['rails_search_halfwidth']
    f = e['result']; a, b = c['rails_range']; p = points[(points[:, 0] > a) & (points[:, 0] < b)]
    x = p[:, 0].astype(float); y = p[:, 1].astype(float)-model_shape(prior, x); h = p[:, 2]-floor_height(e['floor'], x)
    sel = (abs(y-pc) < half) & (h > -.4) & (h < .8); x, y, h = x[sel], y[sel], h[sel]
    if len(x) < 200:
        need(f['score'] == -1. and f['xm'] is None, 'insufficient fit'); return None
    edges = np.arange(pc-half, pc+half+step, step); centers = (edges[:-1]+step/2)
    bins = np.searchsorted(edges, y, side='right')-1
    k = max(1, round(.25/step)); hs = round(.5*c['rails_spacing']/step)
    def profile(mask, minimum):
        result = np.full(len(centers), np.nan)
        for j in range(len(result)):
            values = h[mask & (bins == j)]
            if len(values) >= minimum:
                # The two algebraically equivalent interpolation expressions do
                # not have identical IEEE rounding. Preserve the documented
                # weighted-order-statistic rule: ULP ties can choose a ridge bin.
                rank = (c['rails_percentile']/100.)*(len(values)-1)
                low = math.floor(rank); high = min(low+1, len(values)-1); frac = rank-low
                values = np.partition(values, [low, high])
                result[j] = values[low]*(1.-frac)+values[high]*frac
        ridge = np.full(len(result), np.nan)
        ridge[k:-k] = result[k:-k]-(result[:-2*k]+result[2*k:])/2
        return result, ridge
    heights, ridge = profile(np.ones(len(x), bool), 8)
    best = -1.; chosen = None; gc = pc
    for j in range(hs, len(centers)-hs):
        jj = [j-hs, j+hs]
        if all(np.isfinite(ridge[t]) and c['rails_head_height'][0] < heights[t] < c['rails_head_height'][1] for t in jj):
            score = min(ridge[t] for t in jj)
            if score > best: best, chosen, gc = score, jj, centers[j]
    need(abs(best-f['score']) < 2e-7, ('raw fit global score', best, f['score']))
    if chosen is None:
        need(f['xm'] is None, 'no global pair'); return None
    if best < c['rails_min_score']:
        need(f['xm'] is None, 'subthreshold pair'); return None
    need(abs(float(np.mean(heights[chosen]))-f['rail_offset']) < 2e-7, 'raw head offset')
    stations = []; mids = []; weights = []; dev = max(1, round(c['rails_yaw_max_dev']/step))
    cuts = np.linspace(a, b, c['rails_yaw_slabs']+1)
    for lo, hi in zip(cuts[:-1], cuts[1:]):
        mask = (x >= lo) & (x < hi)
        if sum(mask) < 100: continue
        p, r = profile(mask, 4); peaks = []; w = []
        for center in chosen:
            start, end = max(k, center-dev), min(len(p)-k, center+dev+1)
            rr = r[start:end]
            if not np.isfinite(rr).any(): break
            j = start+int(np.nanargmax(rr))
            if not (r[j] >= .5*c['rails_min_score'] and c['rails_head_height'][0] < p[j] < c['rails_head_height'][1]): break
            frac = 0.
            if np.isfinite(r[j-1:j+2]).all():
                denom = r[j-1]-2*r[j]+r[j+1]
                if denom < -1e-9: frac = np.clip((r[j-1]-r[j+1])/(2*denom), -.5, .5)
            peaks.append(centers[j]+frac*step); w.append(r[j])
        if len(peaks) == 2:
            stations.append((lo+hi)/2); mids.append(np.mean(peaks)); weights.append(min(w))
    need(len(mids) == f['n_slabs'], 'slab count')
    if len(mids) < max(2, c['rails_yaw_min_slabs']):
        need(f['xm'] is None, 'insufficient slabs'); return None
    xx = np.array(stations); yy = np.array(mids)+model_shape(prior, xx); ww = np.array(weights)
    need(np.allclose(xx, f['xm'], atol=1e-9, rtol=0) and np.allclose(yy, f['mids'], atol=1e-7, rtol=0)
         and np.allclose(ww, f['wts'], atol=2e-7, rtol=0), ('raw slab geometry', yy.tolist(), f['mids'], ww.tolist(), f['wts']))
    # Solve the 2x2 weighted normal equations rather than author's covariance or production polyfit.
    yy = yy-.5*(prior['curvature'] if prior else 0.)*xx**2
    mat = np.array([[sum(ww), sum(ww*xx)], [sum(ww*xx), sum(ww*xx*xx)]])
    v = np.linalg.solve(mat, np.array([sum(ww*yy), sum(ww*xx*yy)]))
    need(abs(v[0]-f['center']) < 1e-7 and abs(v[1]-f['tan_yaw']) < 1e-8, 'raw fitted center/tangent')
    return dict(center=float(v[0]), tan_yaw=float(v[1]), mids=f['mids'], xm=f['xm'])


def surface_sample(point, label, s):
    length = math.sqrt(sum(float(v)**2 for v in point)); ray = [float(v)/length for v in point]
    bed = s.get('bed', -2.18); wall = s.get('walls', 4.1)
    surfaces = [(0, z/ray[a]) for a, z in [(0, 247.), (1, wall), (1, -wall), (2, 2.29), (2, bed)] if z*ray[a] > 0]
    boxes = []
    if s.get('target', True):
        d = s.get('distance', 67.); y = s.get('lateral', .68); w = s.get('width', .46)/2
        boxes.append((1, [d-w, y-w, -1.83], [d+w, y+w, s.get('top', 3.22)-1.83]))
    if s.get('shadow', False):
        d = s.get('shadow_distance', 7.); w = s.get('shadow_halfwidth', 2.)
        boxes.append((2, [d, -w, bed], [d+2, w, s.get('shadow_top', 2.29)]))
    for center, height, width, start, lab in [(0. if s.get('host', True) else None, s.get('host_height', .35), .08, s.get('host_start', 3.), 10),
             (s.get('distractor'), s.get('distractor_height', .46), s.get('distractor_width', .08), s.get('distractor_start', 3.), 20)]:
        if center is None: continue
        for j, side in enumerate([-1, 1]):
            y = center+side*.795; boxes.append((lab+j, [start, y-width/2, bed], [247., y+width/2, bed+height]))
    for lab, low, high in boxes:
        bounds = [sorted([low[i]/ray[i], high[i]/ray[i]]) for i in range(3)]
        enter, leave = max(v[0] for v in bounds), min(v[1] for v in bounds)
        if 0 < enter <= leave: surfaces.append((lab, enter))
    nearest = min(t for _, t in surfaces)
    error = abs(nearest-length)
    # Boundary ties within float32 rounding have the same physical surface.
    need(error < 1e-4 and any(lab == label and abs(t-nearest) < 1e-4 for lab, t in surfaces), ('nearest geometry', point, label, error))
    return error


def directed_review():
    sys.path.insert(0, str(ROOT))
    from resense.config import DetectorConfig
    from resense.detector import Detector
    from resense.frame import Frame
    summaries = sum([load(RAIL/n) for n in ['run-summary.json', 'additional-controls-summary.json', 'floor-summary.json', 'near-control-summary.json']], [])
    expected = {r['name']: r for r in load(RAIL/'ACCEPTANCE.json')['cases']}
    cases = []; fitcache = {}; rawcache = {}; allfit = geometry_samples = scans = 0; maxerr = 0.; controls = {}
    for summary in summaries:
        data = load(RAIL/(summary['name']+'.json')); det = Detector(DetectorConfig()); rows = []
        geometry = {}
        for name, inp in data['inputs'].items():
            if name not in rawcache:
                receipt(RAIL/name)
                with np.load(RAIL/name, allow_pickle=False) as f: rawcache[name] = {k: f[k] for k in f.files}
            raw = rawcache[name]; p = raw['xyz']; lab = raw['labels']; s = inp['geometry']
            for k in ('xyz', 'ring', 'labels'): need(fingerprint(raw[k]) == inp[k], ('NPZ identity', summary['name'], k))
            target = p[lab == 1]; head = s.get('bed', -2.18)+s.get('host_height', .35)
            count = int(sum((abs(target[:, 1]) <= 1.05) & (target[:, 2]-head >= .12) & (target[:, 2]-head <= 3.)))
            need(count == inp['raw_host_body_points'] and abs(head-inp['host_head_z']) < 1e-12, 'truth head/body')
            if not s.get('host', True): need(not np.isin(lab, [10, 11]).any(), 'rail-free geometry')
            for label in np.unique(lab):
                idx = np.flatnonzero(lab == label)
                for j in idx[np.linspace(0, len(idx)-1, min(9, len(idx)), dtype=int)]:
                    maxerr = max(maxerr, surface_sample(p[j], label, s)); geometry_samples += 1
            geometry[name] = dict(spec=s, host_head_z=head, analytic_lateral_gap_m=abs(s.get('lateral', .68))-s.get('width', .46)/2-1.05,
                                  target_count=len(target), raw_body_points=count,
                                  target_bounds=None if not len(target) else [target.min(0).tolist(), target.max(0).tolist()],
                                  actual_rail_returns=int(np.isin(lab, [10, 11, 20, 21]).sum()))
        for frame in data['frames']:
            raw = rawcache[frame['input']]; s = data['inputs'][frame['input']]['geometry']; out = frame['output']; i = frame['i']
            if det._previous_latency_ms is not None: det._previous_latency_ms = 42.
            r = det.process(Frame(xyz=raw['xyz'], intensity=np.full(len(raw['xyz']), 35, np.float32), ring=raw['ring'], stamp=i*.1))
            actual = {f.name: fingerprint(getattr(r, f.name)) for f in dataclasses.fields(r) if f.name != 'timing_ms'}
            actual['tracker'] = fingerprint(det.tracker.tracks)
            need(equal(actual, frame['exact']), ('fresh directed ALL output fields and tracker', summary['name'], i))
            receipt(RAIL/frame['processed']) if str((RAIL/frame['processed']).resolve()) not in READS else None
            with np.load(RAIL/frame['processed'], allow_pickle=False) as pp: points = pp['xyz']
            need(fingerprint(points) == out['xyz'] and equal(r.xyz, points), 'processed cloud bytes')
            distance = s.get('distance', 67.); lateral = s.get('lateral', .68)
            ds = raw_matches(out['detections'], distance, lateral, dx=1., dy=.5)
            ws = raw_matches(out['warnings'], distance, lateral, dx=1., dy=.5)
            cs = [j for j, c in enumerate(out['candidates']) if abs(c['distance']-distance) < 1 and abs(c['centroid'][1]-lateral) < .5]
            need(ds == frame['target_detection_indices'] and ws == frame['target_warning_indices'] and cs == frame['target_candidates'], 'all directed target accounting')
            fits = []
            for e in frame['events']:
                if e['function'] != 'estimate_rails' or e['caller'] == 'observe_mount': continue
                need(e['xyz_sha'] == hashlib.sha256(points.tobytes()).hexdigest(), 'fit raw source')
                key = json.dumps(e, sort_keys=True)
                if key not in fitcache: fitcache[key] = rederive_fit(points, e)
                fit = fitcache[key]; allfit += 1
                if fit and 'planted_wrong_fit_center_rejected' not in controls:
                    damaged = copy.deepcopy(e); damaged['result']['center'] += .1
                    rejected = False
                    try: rederive_fit(points, damaged)
                    except AssertionError as exc: rejected = str(exc) == 'raw fitted center/tangent'
                    need(rejected, 'planted fit center escaped raw reconstruction')
                    controls['planted_wrong_fit_center_rejected'] = True
                selected = 'absent_or_insufficient'
                if fit:
                    mids = fit['mids']
                    if max(abs(y) for y in mids) < .12: selected = 'host'
                    elif s.get('distractor') is not None and max(abs(y-s['distractor']) for y in mids) < .12: selected = 'distractor'
                    else: selected = 'mixed_or_other'
                fits.append(dict(caller=e['caller'], selected=selected, reconstructed=fit))
            tracks = [t for t in frame['tracker'] if abs(t['centroid'][0]-distance) < 1 and abs(t['centroid'][1]-lateral) < .5]
            for t in tracks:
                payload = [d for d in out['detections']+out['warnings'] if d['id'] == t['id']]
                need(len(payload) == int(t['reported']), 'directed tracker output')
                if payload: need(payload[0]['zone'] == zone(t), 'directed vote/zone')
            shadow = [e for e in frame['events'] if e['function'] == '_floor_shadow']
            if data['name'] in ('actual_floor_held', 'actual_floor_recovery') and s.get('shadow', False):
                need(shadow and shadow[-1]['result'][-1] is True, 'actual floor-shadow executed hold')
            rows.append(dict(i=i, all_fields_and_tracker_fresh_equal=True, target_STOP=bool(ds), target_warning=bool(ws),
                             global_STOP=out['obstacle'], all_candidate_core=any(c['collision_core'] for c in out['candidates']),
                             target_core=any(out['candidates'][j]['collision_core'] for j in cs), selected_fits=fits,
                             floor_held=out['track']['floor_held'], reported_rail_slabs=out['track']['rail_slabs'],
                             executed_floor_shadow_hold=None if not shadow else shadow[-1]['result'][-1],
                             actual_raw_rail_returns=geometry[frame['input']]['actual_rail_returns'],
                             raw_target_count=geometry[frame['input']]['target_count'],
                             target_tracker=[dict(id=t['id'], hits=t['hits'], misses=t['misses'], reported=t['reported'], zone=zone(t),
                                  zone_votes=sum(t['zone_hist']), zone_denominator=max(len(t['zone_hist']), t['zone_min_votes']),
                                  core_hits=t['collision_core_hits'], core_ready=t['collision_core_ready'], hold=t['hold']) for t in tracks]))
            scans += 1
        start = 0
        for stage, (count, spec) in zip(expected[data['name']]['stages'], data['stages'], strict=True):
            stage_rows = rows[start:start+count]
            for key, field in [('target_STOP', 'target_STOP'), ('global_STOP', 'global_STOP'), ('all_candidate_core', 'all_candidate_core'), ('floor_held', 'floor_held')]:
                need([q['i'] for q in stage_rows if q[field]] == stage[key], ('stage output rows', data['name'], key))
            selected = collections.Counter(f['selected'] for q in stage_rows for f in q['selected_fits'] if f['caller'] == 'estimate_track')
            need(dict(selected) == stage['selected_track_pairs'], ('stage selected actual pair', data['name']))
            start += count
        cases.append(dict(name=data['name'], input_geometry=geometry, rows=rows))
        print('DIRECTED', data['name'], len(rows), 'STOP', [q['i'] for q in rows if q['target_STOP']], flush=True)
    byname = {c['name']: c for c in cases}
    for n in ['correct_0.68', 'paired_host_near_center', 'wrong_inside_control_67.0']:
        need(any(q['target_core'] and q['target_STOP'] for q in byname[n]['rows']), ('known core/STOP positive', n)); controls[n] = True
    control = copy.deepcopy(byname['correct_0.68']['rows'][4]); control['target_STOP'] = False
    need(control != byname['correct_0.68']['rows'][4], 'directed removed hit positive control')
    # Distinguish a current measurement, historical STOP vote, stale Track.last,
    # and floor-held support. These are verified row-by-row, not inferred by names.
    remain = byname['loss_target_remains']['rows'][14:]
    for q in remain:
        need(not q['all_candidate_core'], 'new core after rail removal')
        t = q['target_tracker'][0]
        need(t['misses'] == 0 and t['core_hits'] == 0 and not t['core_ready'], 'measured hit versus stale core')
        need(q['target_STOP'] == (t['zone_votes'] >= .6*t['zone_denominator']-1e-9), 'retained zone vote')
    held = byname['actual_floor_held']['rows'][14:]
    need(all(q['floor_held'] and q['reported_rail_slabs'] == 3 and q['actual_raw_rail_returns'] == 0 and q['raw_target_count'] == 0 for q in held), 'held support interpretation')
    need([q['i'] for q in held if q['target_STOP']] == [14] and [q['i'] for q in held if q['global_STOP']] == [14]+list(range(18,28)), 'target/global STOP distinction')
    need(not any(q['floor_held'] for q in byname['loss_shadow_held']['rows']), 'misleading historical case name')
    return dict(cases=len(cases), scans=scans, all_fresh_fields_and_tracker_equal=True, fit_calls=allfit,
                unique_fit_recomputations=len(fitcache), geometry_samples=geometry_samples, maximum_surface_error_m=maxerr,
                positive_controls=controls, rows=cases, no_rail_interpretation_verified=True,
                excluded='Calibration observe_mount trial fits; component-only supplied models; no real-world frequency inference.')


def reference_review():
    old = load(REF/'report.json')
    archive_path = E/'h1_trajectory_2026-10-19/raw-evidence.tar.gz'; receipt(archive_path)
    with tarfile.open(archive_path) as tar:
        def member(n):
            raw = tar.extractfile(n).read()
            prior = next(r for r in old['inputs']['archive_members'] if r['member'] == n)
            need(hashlib.sha256(raw).hexdigest() == prior['sha256'], ('reference member hash', n))
            return json.loads(raw)
        data = member('direct-gicp-regularized-all.json'); control = member('validation-reconstruction.json')['controls']
        def gate(row, point=None):
            a, b, r = [np.array(row[n]['T']) for n in ['primary', 'alternate', 'reverse']]
            p = np.array(row['near_point'] if point is None else point); cycle = a@r
            angle = math.degrees(math.acos(float(np.clip((np.trace(cycle[:3,:3])-1)/2, -1, 1))))
            values = [math.dist((a@p)[:3], (b@p)[:3]), math.dist(cycle[:3,3], [0,0,0]), angle,
                      min(row[n]['stages'][-1]['fitness'] for n in ['primary','alternate','reverse'])]
            fail = next((n for n, bad in zip(['seed_disagreement','reverse_translation','reverse_rotation','fitness'],
                        [values[0]>.1, values[1]>.1, values[2]>.05, values[3]<.7]) if bad), None)
            return dict(metrics=values, failure=fail)
        direct = [dict(row=i, **gate(r)) for i, r in enumerate(data['rows'])]
        need(gate(control, [15.,0.,-1.,1.])['failure'] is None, 'known rigid positive')
        for kind in ['seed_disagreement','reverse_translation','reverse_rotation','fitness']:
            bad = copy.deepcopy(control)
            if kind == 'seed_disagreement': bad['alternate']['T'][1][3] += .5
            elif kind == 'reverse_translation': bad['reverse']['T'][1][3] += .5
            elif kind == 'reverse_rotation':
                theta=math.radians(1.); rot=np.array([[math.cos(theta),-math.sin(theta),0],[math.sin(theta),math.cos(theta),0],[0,0,1]])
                t=np.array(bad['reverse']['T']); t[:3,:3]=t[:3,:3]@rot; bad['reverse']['T']=t.tolist()
            else: bad['primary']['stages'][-1]['fitness']=.1
            need(gate(bad, [15.,0.,-1.,1.])['failure'] == kind, ('reference gate fault control', kind))
        landmarks = {}; observations = 0; means = 0
        for seq in ['A','C']:
            tracks=member(f'landmark-tracks-{seq}.json'); sol=member(f'landmark-bundle-{seq}-converged.json'); rows=[]
            for track in tracks['retained']:
                world=[]
                for obs in track['observations']:
                    points=obs['points']; center=[math.fsum(p[j] for p in points)/len(points) for j in range(3)]
                    need(math.dist(center, obs['center']) < 1e-12, 'raw support centroid'); means+=1
                    if track['validation_only']:
                        t=sol['rows'][obs['frame']]['pose']
                        world.append([math.fsum(t[j][k]*center[k] for k in range(3))+t[j][3] for j in range(3)])
                if not track['validation_only']: continue
                anchor=[statistics.median(p[j] for p in world[:5]) for j in range(3)]
                distances=sorted(math.dist(p,anchor) for p in world); pos=.95*(len(distances)-1); lo=math.floor(pos); hi=math.ceil(pos)
                p95=distances[lo]+(pos-lo)*(distances[hi]-distances[lo]); observations+=len(world)
                saved=next(r for r in old['landmark_validation']['sequences'][seq]['validation'] if r['track_id']==track['id'])
                need(abs(p95-saved['residual_p50_p95_max_m'][1]) < 1e-12, 'raw withheld p95')
                rows.append(dict(id=track['id'], observations=len(world), p95=p95, pass_010=p95<=.1))
            landmarks[seq]=dict(rows=rows, pass_tracks=sum(r['pass_010'] for r in rows))
    inventory=[]
    for seq,name in [('A','roundT_squareT_pressureGate_squareT'),('C','roundT_pressureGate_roundT')]:
        path=Path('/tmp/opencode/resense-b4-data/for_hackathon')/name/(name+'_0.db3')
        # Bounded SQL spot check, no fresh claim of hashing all 64 GB of source inputs.
        with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as con:
            con.execute('PRAGMA query_only=ON')
            topics=con.execute('SELECT id,name,type FROM topics ORDER BY id').fetchall()
            counts=dict(con.execute('SELECT topic_id,COUNT(*) FROM messages GROUP BY topic_id'))
            total=con.execute('SELECT COUNT(*) FROM messages').fetchone()[0]
            need(total==sum(counts.values()) and set(counts)<=set(t[0] for t in topics), 'SQL count integrity')
        saved=next(r for r in old['topic_inventory']['bags'] if r['bag']==str(path))
        actual=[dict(id=t[0],name=t[1],type=t[2],messages=counts.get(t[0],0)) for t in topics]
        need(actual==saved['topics'] and total==saved['total_messages'], 'A/C topic spot check')
        need(total>0 and all(t['type']=='sensor_msgs/msg/PointCloud2' for t in actual), 'bounded external reference absence / cloud positive')
        inventory.append(dict(sequence=seq,total=total,topics=actual))
    return dict(direct_rows=direct, direct_first_failed_counts=dict(collections.Counter(r['failure'] for r in direct)),
                direct_pass=sum(r['failure'] is None for r in direct), controls=dict(known_80m_transform_passed=True,four_planted_faults_detected=True),
                raw_support_centroids=means, validation_observations=observations, landmarks=landmarks,
                sql_A_C=inventory, scope='Saved registration matrices/raw feature supports rederived; no new ICP or independent physical axis. Eleven-bag full hashes/live URL provenance reused, not re-run.')


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--out',type=Path,required=True); args=p.parse_args()
    dest=args.out.resolve(); need(dest.parent==OUT and not dest.exists(),'exclusive report path')
    need(os.environ.get('RESENSE_REPO')==str(ROOT) and os.environ.get('OPENBLAS_CORETYPE')=='Haswell'
         and os.environ.get('OMP_NUM_THREADS')=='1' and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1','P4 environment')
    started=time.monotonic(); before=source_snapshot()
    for path in [ROOT/'CLAUDE.md',ROOT/'docs/DETECTOR_FREEZE.md',Path(__file__),REF/'review_reference.py',REF/'README.md',
                 MISS/'README.md',MISS/'PUBLICATION.md',MISS/'verify_publication.py',RAIL/'README.md',RAIL/'ACCEPTANCE_PLAN.md']:
        receipt(path)
    sources=check_sources(before); bundle,package=package_check(); reference=reference_review()
    misses=review_misses(bundle); directed=directed_review()
    # Secondary checker is retained as corroboration only. Independent checks above
    # do not call its parser, matcher, attribution logic, fit or snapshot comparator.
    secondary=subprocess.run([sys.executable,'-B',str(MISS/'verify_publication.py'),'--vm'],capture_output=True,text=True,timeout=900)
    need(secondary.returncode==0,('standalone portable/VM verifier',secondary.stderr))
    standalone=json.loads(secondary.stdout)
    after=source_snapshot(); need(before==after,'source/index/HEAD changed during review')
    for name,r in READS.items():
        s=Path(name).stat(); need([s.st_size,s.st_mtime_ns,s.st_ino]==r['stat'],('input stat changed',name))
    report=dict(schema='resense-h1-fresh-final-review-v1', generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                audit_completed=True,h1_feature_acceptance='BLOCKED',h1_closed=False,
                conclusion='63 misses remain; no independently validated A/C 100-150 m rail reference; actual wrong-pair false STOPs and misses confirmed. No universal safety guarantee.',
                sources=sources,publication=package,reference=reference,miss_audit=misses,directed=directed,
                author_standalone_secondary=standalone,source_and_index_unchanged=True,
                checked_inputs=READS,elapsed_s=time.monotonic()-started,
                limitations=['This review is completed; H1 feature acceptance remains blocked.',
                 'No detector edit, full regression/X3/Falcon battery rerun, reseal, commit, push or G3.',
                 'Synthetic host semantics are fixture truth; 0.20/0.30 m rail-like box ridges do not establish real-world prevalence.',
                 'Actual +/-1.59 m wrong selection, standard 0.35 m-host wrong selection, curves/motion, longer no-rail persistence remain unverified.',
                 'Full-pipeline floor-held case hides target; visible-body held guard is not demonstrated.',
                 'DK6 Falcon and SfBeRHbs8bNJAQ/folder6 source checks are reused provenance, not external spatial truth.',
                 'All 11 raw database hashes were not rehashed here; A/C inventory was independently SQL-checked.'])
    with dest.open('x') as f: json.dump(report,f,indent=2,allow_nan=False); f.write('\n')
    need(dest.stat().st_size<20_000_000,'report portability')
    print(json.dumps(dict(audit_completed=True,H1='BLOCKED',report=str(dest),bytes=dest.stat().st_size,
                         frames=misses['frames'],visible=len(misses['visible_rows']),hits=misses['hits'],misses=misses['miss_count'],
                         directed_cases=directed['cases'],directed_scans=directed['scans'],fit_calls=directed['fit_calls'],
                         elapsed_s=report['elapsed_s'],sha256=sha(dest))))


if __name__=='__main__': main()
