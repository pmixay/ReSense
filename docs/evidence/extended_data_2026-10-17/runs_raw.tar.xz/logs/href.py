import json, sys, urllib.parse, urllib.request
key = urllib.parse.quote("https://disk.yandex.ru/d/SfBeRHbs8bNJAQ", safe="")
info = json.load(urllib.request.urlopen(f"https://cloud-api.yandex.net/v1/disk/public/resources?public_key={key}&limit=200&path=" + urllib.parse.quote("/", safe=""), timeout=60))
for i in info.get("_embedded", {}).get("items", []):
    print(i["name"], i.get("type"), i.get("size"), i.get("modified"), i.get("md5"), i.get("sha256"), i.get("path"), file=sys.stderr)
p = sys.argv[1]
print(json.load(urllib.request.urlopen(f"https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key={key}&path=" + urllib.parse.quote(p, safe=""), timeout=60))["href"])
