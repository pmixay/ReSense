"""Variant (not the jury default): judge_runner's NodeReplica with the Falcon axes given as launch
parameters (sensor.forward=+x, sensor.left=+y, sensor.up=+z); everything else the sealed config."""
import json
import sys

import judge_runner as J

bag, out = sys.argv[1], sys.argv[2]
rep = J.NodeReplica(overrides={"sensor.forward": "+x", "sensor.left": "+y", "sensor.up": "+z"})
n = 0
with open(out + ".jsonl", "w") as fj:
    for db3 in J.db3_files(bag):
        for ts, topic, raw in J.iter_raw(db3):
            msg, stamp, res, dec_ms, det_ms = rep.process_raw(raw, topic, n)
            r = J.record(n, ts / 1e9, stamp, res, dec_ms, det_ms, msg.header.frame_id, topic)
            r["orientation"] = (res.mount or {}).get("orientation")
            fj.write(json.dumps(r) + "\n")
            n += 1
print(json.dumps({"frames": n, "resets": rep.resets}))
