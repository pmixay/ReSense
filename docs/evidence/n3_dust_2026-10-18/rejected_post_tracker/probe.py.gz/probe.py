import dataclasses,gzip,json,sys
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
ROOT=Path('/home/resense/ReSense');sys.path.insert(0,str(ROOT))
from resense.dust import augment_dust,PRESETS
from resense.frame import Frame,axis_matrix
from resense.config import SensorConfig
from resense.track import TrackModel
bag=sys.argv[1];level=sys.argv[2]
folder=ROOT/'docs/evidence/n3_dust_2026-10-18/baseline'
rows=[json.loads(x) for x in gzip.open(folder/f'{bag}_{level}.jsonl.gz','rt')]
meta=json.loads((Path('/home/resense/data/decoded')/bag/'meta.json').read_text())
fields={f.name for f in dataclasses.fields(TrackModel)}
R=axis_matrix(SensorConfig()).astype(np.float32)
results=[]
for i,row in enumerate(rows):
 if row['mount']['orientation']!='configured' or any(row['mount'][k] for k in ('roll_deg','pitch_deg','yaw_deg')):raise ValueError('nonidentity needs full transform')
 with np.load(Path('/home/resense/data/decoded')/bag/f'f_{i:05d}.npz') as d:
  fr=Frame(d['xyz']@R.T,d['inten'],d['ring'],meta[i]['stamp'],meta[i]['frame_id'])
  fr,_,_=augment_dust(fr,PRESETS[level],rail_z=row['augmentation']['rail_z'],seed=20261018,frame_index=i)
 track=TrackModel(**{k:v for k,v in row['track'].items() if k in fields})
 x=fr.xyz[:,0];dy=fr.xyz[:,1]-track.center_y(x);h=fr.xyz[:,2]-track.rail_z(x)
 end=min(60,track.axis_valid);end=5+int((end-5)//5)*5
 selected=(x>=5)&(x<end)&(abs(dy)<1)&(h>=.3)&(h<2.7)&(fr.intensity<=5)
 coords=np.column_stack((x[selected],dy[selected],h[selected]))
 cells=np.floor((coords-np.array([5,-1,.3]))/np.array([5,.5,.5])).astype(int)
 unique=np.unique(cells,axis=0)
 occupation=len(unique)/max(1,int((end-5)/5)*4*5)
 stations=len(np.unique(unique[:,0])) if len(unique) else 0
 diffuse=occupation>=.45 and stations>=6
 demoted=[]; diagnostics=[]
 if diffuse and row['detections']:
  roi=(x>2.5)&(x<100)&(abs(dy)<5)&(h>-.5)&(h<5)
  xyz=fr.xyz[roi];inten=fr.intensity[roi]
  _,distinct=np.unique(np.round(xyz/.03).astype(int),axis=0,return_index=True)
  xyz=xyz[distinct];inten=inten[distinct]
  tree=cKDTree(xyz)
  for det in row['detections']:
   c=np.array(det['center']);size=np.array(det['size'])
   inside=np.all(abs(xyz-c)<=size/2+.05,axis=1)
   pts=xyz[inside]
   # Any strong current return protects this candidate; missing current data keeps hold.
   if len(pts) and np.all(inten[inside]<=5):
    radius=.15+np.linalg.norm(pts,axis=1)*np.tan(np.deg2rad(.2))
    neighbors=tree.query_ball_point(pts,radius,return_length=True)
    supported=int((neighbors>=3).sum())
    if supported<2:demoted.append(det['id'])
    diagnostics.append({'id':det['id'],'points':len(pts),'supported':supported})
 stop=any(d['id'] not in demoted for d in row['detections'])
 results.append({'frame':i,'diffuse':bool(diffuse),'occupation':occupation,'stations':stations,'demoted':demoted,'support':diagnostics,'stop':stop,'old_stop':row['obstacle']})
 if i%50==0:print('frame',i,'diffuse',diffuse,'occupation',round(occupation,2),flush=True)
prev=False;episodes=0
for r in results:
 episodes+=int(r['stop'] and not prev);prev=r['stop']
out={'bag':bag,'level':level,'frames':len(rows),'diffuse_frames':sum(r['diffuse'] for r in results),'stop_frames':sum(r['stop'] for r in results),'stop_episodes':episodes,'demoted_detections':sum(len(r['demoted']) for r in results),'rows':results}
p=ROOT/'docs/evidence/n3_dust_2026-10-18'/f'prototype_{bag}_{level}.json';p.write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='rows'},flush=True)
