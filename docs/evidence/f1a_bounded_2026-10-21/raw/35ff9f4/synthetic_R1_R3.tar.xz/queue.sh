#!/bin/bash
# revision-2 synthetic hard rows: R1 (review families as defined), R1 positive control (r1 = 61b6e1a), R2 (forced
# measured phases, seeds 0/101/202), R3 (A1/A3 ideal-grid families, candidate; control outputs from /data/runs/a1)
set -u
REV=/home/user/review/docs/evidence/f1a_bounded_review_2026-10-21
D=/home/user/ReSense/docs/evidence/f1a_bounded_2026-10-21
O=/data/runs/r2b
. /home/user/venv/bin/activate
FAMS="apb apb_meas ext_meas azoff fine_delta shapes two cant curve moving falcon empty seeds"
env_for() { W=/home/user/wt/$1; export RESENSE_REPO=$W PYTHONPATH=$W:$W/ros2_ws/src/resense_ros OPENBLAS_CORETYPE=Haswell OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1; }
# positive control: r1 = 61b6e1a already run, outputs copied
for side in cand control; do env_for $side; for f in $FAMS; do python $REV/attack.py --family $f --out $O/R1-$f-$side.json --jobs 4 > $O/R1-$f-$side.log 2>&1; echo "R1 $f $side rc=$?"; done; done
$D/run_synth.sh cand $O approach_bed approach_empty empty centre beside approach rail rail_ranges ext_sizes ext_slope ext_rise ext_rest
for seed in 0 101 202; do for side in cand control; do env_for $side; export REVIEW_DIR=$REV
  for f in apb fine_delta shapes two cant curve moving empty ext_meas azoff; do
    python $D/attack_r2.py --family $f --seed $seed --out $O/R2-$f-s$seed-$side.json --jobs 4 > $O/R2-$f-s$seed-$side.log 2>&1; echo "R2 $f s$seed $side rc=$?"; done; done; done
echo QUEUE_DONE
