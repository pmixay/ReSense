import json, os, subprocess, time, hashlib
from pathlib import Path
repo=Path('/home/resense/data/final_lidar_7b7b02c')
out=Path('/home/resense/ReSense/docs/evidence/lidar_adaptation_2026-10-18')
status=Path('/home/resense/data/x3_metadata_fixed_status.json')
state={'status':'waiting_for_pre_correction_x3','pid':os.getpid(),'pgid':os.getpgrp(),'source_commit':'7b7b02c9b535d2b03d053df1b309301b619269ad'}
def save(): status.write_text(json.dumps(state,indent=2)+'\n')
save()
while True:
 try: os.kill(48050,0)
 except ProcessLookupError: break
 time.sleep(10)
prior=out/'x3_candidate.json'
assert prior.exists(), 'Prior X3 did not finish; preserve failure before new run'
json.loads(prior.read_text())
command=['/home/resense/.venv/bin/python',str(repo/'scripts/robustness_battery.py'),'--repo',str(repo),'--cache','/home/resense/data/x3_reference/cache','--reference','/home/resense/data/x3_reference/reference.json','--out',str(out/'x3_metadata_fixed.json'),'-j','1']
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_CORETYPE':'Haswell','PYTHONPATH':str(repo)}
state.update(status='running',command=command,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());save()
with open('/home/resense/data/logs/x3_metadata_fixed.log','w') as log:
 result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
state.update(status='finished',returncode=result.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));save()
