import os,subprocess,json,time,hashlib
from pathlib import Path
root=Path('/home/resense/ReSense')
out=root/'docs/evidence/lidar_adaptation_2026-10-18/default_off'
command=['/home/resense/.venv/bin/python','-m','pytest','-q','-rs','--junitxml='+str(out/'junit-core.xml')]
env={**os.environ,'RESENSE_REQUIRE_SYNTHETIC':'1','RESENSE_RIDE_CACHE':'/home/resense/data/gate_cache/new_data','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_CORETYPE':'Haswell'}
receipt={'command':command,'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'isolated_cpu':True,'cpu_affinity':sorted(os.sched_getaffinity(0)),'tested_helper_hashes':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('docs/evidence/n2_falcon_2026-10-18/retain_playback_subset.py','tests/test_falcon_playback_subset.py')}}
with open('/home/resense/data/logs/tests_lidar_default_off.log','w') as log:
 result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(returncode=result.returncode,finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(out/'core_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')

(out/'core.txt').write_bytes(Path('/home/resense/data/logs/tests_lidar_default_off.log').read_bytes())
