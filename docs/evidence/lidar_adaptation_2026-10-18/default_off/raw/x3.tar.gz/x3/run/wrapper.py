"""Run the immutable, user-selected opt-in default through the complete X3 protocol."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

SOURCE = Path('/home/resense/data/final_lidar_cecab1b')
COMMIT = 'cecab1b696b8c2e101207601acd8faed96c8bfb8'
ROOT = Path('/home/resense/ReSense')
OUT = ROOT / 'docs/evidence/lidar_adaptation_2026-10-18/default_off'
STATUS = Path('/home/resense/data/x3_default_off_status.json')
LOG = Path('/home/resense/data/logs/x3_default_off.log')
NATIVE = '511f7766639f0ddab471a77263f7a343de19d0a8217dd7cd3a11635c8a7db2c8'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

if STATUS.exists() or (OUT / 'x3.json').exists() or (OUT / 'x3.raw').exists():
    raise ValueError('Refusing to overwrite prior X3 evidence')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == COMMIT
keys = json.loads((ROOT / 'docs/evidence/lidar_adaptation_2026-10-18/runtime_identity_metadata_fixed.json').read_text())['source_files']
hashes = {p: sha(SOURCE / p) for p in keys}
libs = {str(p.relative_to(SOURCE)): sha(p) for p in (SOURCE / 'resense').glob('*.so')}
assert len(libs) == 1 and set(libs.values()) == {NATIVE}
env = {**os.environ, 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
       'MKL_NUM_THREADS': '1', 'OPENBLAS_CORETYPE': 'Haswell', 'PYTHONPATH': str(SOURCE)}
for key in list(env):
    if key.startswith('RESENSE_N2_'):
        del env[key]
preflight = subprocess.check_output([
    '/home/resense/.venv/bin/python', '-c',
    'import json;from resense import _native;from resense.config import DetectorConfig;'
    'print(json.dumps({"native":_native.enabled(),"replay_default":DetectorConfig().calibration.orientation_replay_frames}))'
], cwd=SOURCE, env=env, text=True)
preflight = json.loads(preflight)
assert preflight == {'native': True, 'replay_default': 0}
command = ['/home/resense/.venv/bin/python', str(SOURCE / 'scripts/robustness_battery.py'),
           '--repo', str(SOURCE), '--cache', '/home/resense/data/x3_reference/cache',
           '--reference', '/home/resense/data/x3_reference/reference.json',
           '--out', str(OUT / 'x3.json'), '-j', '1']
state = {'status': 'running', 'pid': os.getpid(), 'pgid': os.getpgrp(),
         'source_commit': COMMIT, 'source_files': hashes, 'native_libraries': libs,
         'preflight': preflight, 'command': command, 'started_utc': now(),
         'wrapper_sha256': sha(Path(__file__)),
         'timings_informational_shared_cpu': True}
STATUS.write_text(json.dumps(state, indent=2) + '\n')
with LOG.open('w') as stream:
    result = subprocess.run(command, cwd=SOURCE, env=env, stdout=stream, stderr=subprocess.STDOUT)
state.update(status='finished', returncode=result.returncode, finished_utc=now(),
             source_unchanged=hashes == {p: sha(SOURCE / p) for p in keys},
             native_unchanged=libs == {str(p.relative_to(SOURCE)): sha(p) for p in (SOURCE / 'resense').glob('*.so')})
if (OUT / 'x3.json').exists():
    state['report_sha256'] = sha(OUT / 'x3.json')
STATUS.write_text(json.dumps(state, indent=2) + '\n')
raise SystemExit(result.returncode)
