import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/home/resense/data/final_lidar_cecab1b')
CACHE = Path('/home/resense/data/gate_cache')
OUTPUT = Path('/home/resense/ReSense/docs/evidence/lidar_adaptation_2026-10-18/default_off')
STATUS = Path('/home/resense/data/default_off_gate_status.json')
sys.path.insert(0, str(REPO / 'scripts'))
from cache_io import validate_extended_ride_cache

state = {'pid': os.getpid(), 'pgid': os.getpgrp(), 'source_commit': 'cecab1b696b8c2e101207601acd8faed96c8bfb8',
         'status': 'waiting_for_verified_ride', 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}

def save():
    STATUS.write_text(json.dumps(state, indent=2) + '\n')

save()
while not (CACHE / 'ride_receipt.json').is_file():
    time.sleep(10)
expected = {'originals': ('e23166801794cdeb2dcd77a3cc8b40a906b1d9cefab6f26739e368234e9168be', 3940746006, 2488),
            'set_o': ('d41c2fb28475194a98efeca5d2ee3fd175c0aef350ffb92fff4c26d497e696e9', 1746145824, 1510),
            'ride': ('8124b627a8a70516a4023db522849f1cadae711e7b152b0f701535a69dab99ec', 17078961996, 11271)}
for name, values in expected.items():
    path = CACHE / (name + '_receipt.json')
    receipt = json.loads(path.read_text())
    assert receipt['verified'] and (receipt['sha256'], receipt['bytes'], receipt['total_frames']) == values
    (OUTPUT / ('gate_intake_' + name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
validation = validate_extended_ride_cache(str(CACHE / 'new_data'), load_arrays=False)
command = [sys.executable, str(REPO / 'scripts/regression_gate.py'), '--cache', str(CACHE), '--jobs', '1',
           '--baseline', str(REPO / 'docs/evidence/results/regression_baseline_2026-09-29_shell_off.json'),
           '--out', str(OUTPUT / 'gate.json'), '--work', '/home/resense/data/final_gate_work_cecab1b']
assert not (OUTPUT / 'gate.json').exists()
state.update(status='running', command=command, ride_validation=validation,
             wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
save()
env = {**os.environ, 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
       'OPENBLAS_CORETYPE': 'Haswell', 'PYTHONPATH': str(REPO)}
with open('/home/resense/data/logs/default_off_gate.log', 'w') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
state.update(status='finished', returncode=result.returncode,
             finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
save()
sys.exit(result.returncode)
