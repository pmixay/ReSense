import os,subprocess,time
from pathlib import Path
p=Path('/home/resense/data/raw/falcon_test_second_dark/falcon_test_second_dark_0.db3')
while p.exists():time.sleep(5)
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_CORETYPE':'Haswell','PYTHONPATH':'/home/resense/ReSense'}
for mode in ('originals','set_o','ride'):
 receipt=Path('/home/resense/data/gate_cache')/(mode+'_receipt.json')
 if receipt.exists():continue
 print('Starting full-gate intake',mode,flush=True)
 with open('/home/resense/data/logs/gate_intake_'+mode+'.log','w') as out:
  subprocess.run(['/home/resense/.venv/bin/python','/home/resense/data/prepare_gate.py',mode],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 print('Completed',mode,flush=True)
