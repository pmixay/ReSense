from pathlib import Path
import hashlib,json,os,shutil,sys,tarfile,urllib.request,subprocess
import zstandard
ROOT=Path('/home/resense/ReSense'); DATA=Path('/home/resense/data')
sys.path[:0]=[str(ROOT),str(ROOT/'scripts')]
from cache_frames import cache_bag
from cache_io import validate_extended_ride_cache
from unpack_dataset import open_zst_stream
mode=sys.argv[1]
SPOOL=DATA/'gate_spool'; SPOOL.mkdir(exist_ok=True)
OUT=DATA/'gate_cache'; OUT.mkdir(exist_ok=True)
class HashReader:
 def __init__(self,f): self.f=f;self.h=hashlib.sha256();self.n=0
 def read(self,n=-1):
  b=self.f.read(n);self.h.update(b);self.n+=len(b);return b
 def readable(self):return True
if mode=='originals':
 archive=DATA/'downloads/dataset.zip'
 if not archive.exists():
  url='https://drive.usercontent.google.com/download?id=1WTlR2wDSuEHTOARGK_gZeXDTZ9RZpswu&export=download&confirm=t'
  with urllib.request.urlopen(url,timeout=120) as src,archive.open('wb') as dst:shutil.copyfileobj(src,dst,8<<20)
 h=hashlib.sha256()
 with archive.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 assert h.hexdigest()=='e23166801794cdeb2dcd77a3cc8b40a906b1d9cefab6f26739e368234e9168be'
 raw=open_zst_stream(str(archive));expected=None
elif mode=='set_o':
 raw=HashReader((DATA/'downloads/cloud_with_fake_obj.zst').open('rb'))
 expected=('d41c2fb28475194a98efeca5d2ee3fd175c0aef350ffb92fff4c26d497e696e9',1746145824)
elif mode=='ride':
 raw=HashReader(open_zst_stream('https://disk.yandex.ru/d/N8IUpAyd7jyvow','new_data.zst'))
 expected=('8124b627a8a70516a4023db522849f1cadae711e7b152b0f701535a69dab99ec',17078961996)
else:raise ValueError(mode)
reader=zstandard.ZstdDecompressor().stream_reader(raw,read_across_frames=True)
counts={}
with tarfile.open(fileobj=reader,mode='r|') as tar:
 for m in tar:
  if not m.isfile() or not m.name.endswith('.db3'):continue
  name=Path(m.name).name;bag=Path(m.name).parent.name
  out=OUT/bag;stem=Path(name).stem
  marker=out/(stem+'_stamps.json')
  if marker.exists():
   counts[stem]=json.loads(marker.read_text())['frames'];print('Resume',stem,counts[stem],flush=True);continue
  temp=SPOOL/name
  if shutil.disk_usage(DATA).free<m.size+2_000_000_000:raise RuntimeError('Insufficient disk for '+name)
  with tar.extractfile(m) as src,temp.open('wb') as dst:shutil.copyfileobj(src,dst,8<<20)
  subprocess.run([sys.executable,str(ROOT/'scripts/cache_frames.py'),str(temp),str(out),'--every','1','--int16','--stamps','--zstd'],check=True)
  n=json.loads(marker.read_text())['frames']
  counts[stem]=n
  temp.unlink()
  print('Cached',stem,n,'freeGB',round(shutil.disk_usage(DATA).free/1e9,2),flush=True)
while reader.read(8<<20):pass
if expected:
 assert (raw.h.hexdigest(),raw.n)==expected,(raw.h.hexdigest(),raw.n)
 receipt={'sha256':raw.h.hexdigest(),'bytes':raw.n,'verified':True}
else:receipt={'sha256':h.hexdigest(),'bytes':archive.stat().st_size,'verified':True}
receipt.update(mode=mode,frame_counts=counts,total_frames=sum(counts.values()))
if mode=='ride':receipt['validation']=validate_extended_ride_cache(str(OUT/'new_data'),load_arrays=False)
(OUT/(mode+'_receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print('Complete',mode,sum(counts.values()),flush=True)
if mode=='originals':archive.unlink()
