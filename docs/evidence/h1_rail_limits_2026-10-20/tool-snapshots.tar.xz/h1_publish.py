"""Evidence-only publication packaging. Standard library; never imports/runs detector."""
import argparse
import datetime
import hashlib
import json
import lzma
from pathlib import Path
import shutil
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
TEMP = Path('/tmp/opencode/h1-rail-limits')
STATE = TEMP / 'publication-preparation.json'
LIMIT = 19_500_000


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_new(path, obj):
    assert path.parent.is_dir() and not path.exists(), str(path)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def git_state():
    root = HERE.parents[2]
    frozen = json.loads((HERE / 'manifest-before.json').read_text())['files']
    production = {name: sha(root / name) for name in frozen if name.startswith(
        ('resense/', 'native/', 'configs/', 'ros2_ws/')) or name in
        ('setup.py', 'pyproject.toml', 'scripts/build_native.sh')}
    return dict(head=subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
                index_sha256=sha(root / '.git/index'), production_files=production,
                tracked_status=subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain=v1',
                                                        '--untracked-files=no'], text=True))


class BoundedWriter:
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        if self.stream.tell() + len(data) > LIMIT:
            raise ValueError('xz candidate exceeded bounded 19.5 MB attempt')
        return self.stream.write(data)

    def tell(self):
        return self.stream.tell()

    def flush(self):
        return self.stream.flush()


def archive_reopen(path, originals):
    found = []
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and Path(member.name).name == member.name
            assert member.name not in found and member.name in originals
            assert '__pycache__' not in member.name and not member.name.endswith('.pyc')
            source = HERE / member.name
            expected = originals[member.name]
            digest = hashlib.sha256()
            size = 0
            extracted = archive.extractfile(member)
            with source.open('rb') as raw:
                while True:
                    block = extracted.read(1024 * 1024)
                    if not block:
                        assert not raw.read(1)
                        break
                    assert raw.read(len(block)) == block, member.name
                    digest.update(block)
                    size += len(block)
            assert member.size == size == expected['bytes']
            assert digest.hexdigest() == expected['sha256'] == sha(source)
            found.append(member.name)
    assert sorted(found) == sorted(originals)
    return len(found)


def prepare():
    assert HERE.is_dir() and TEMP.is_dir() and not STATE.exists()
    before = git_state()
    originals = {}
    checksum_bytes = (HERE / 'SHA256SUMS').read_bytes()
    for line in checksum_bytes.decode().splitlines():
        expected, original_path = line.split('  ', 1)
        path = Path(original_path)
        assert path.parent == HERE and path.name not in originals
        assert path.is_file() and not path.is_symlink()
        assert sha(path) == expected, path.name
        originals[path.name] = dict(bytes=path.stat().st_size, sha256=expected)
    path = HERE / 'SHA256SUMS'
    originals[path.name] = dict(bytes=path.stat().st_size, sha256=sha(path))
    assert set(originals) == {p.name for p in HERE.iterdir() if p.is_file() and
                            p.name not in ('h1_publish.py', 'h1_verify_publication.py')}
    # Original README is retained both as a root archive member and a VM temp backup.
    backup = TEMP / 'README-before-publication.md'
    assert not backup.exists()
    shutil.copyfile(HERE / 'README.md', backup)
    candidate = TEMP / 'raw-evidence-full.tar.xz'
    assert not candidate.exists()
    try:
        with candidate.open('xb') as raw:
            with lzma.LZMAFile(BoundedWriter(raw), 'w', preset=9 | lzma.PRESET_EXTREME,
                               check=lzma.CHECK_CRC64) as compressed:
                with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                    for name in sorted(originals):
                        info = tarfile.TarInfo(name)
                        info.size = originals[name]['bytes']
                        info.mode = 0o644
                        info.mtime = 0
                        with (HERE / name).open('rb') as stream:
                            archive.addfile(info, stream)
    except ValueError as error:
        # Partial candidate remains in approved temp, never published as an archive.
        write_new(TEMP / 'publication-size-limit.json', dict(error=str(error),
                  partial_bytes=candidate.stat().st_size, action='logical subsets required'))
        raise
    count = archive_reopen(candidate, originals)
    destination = HERE / 'raw-evidence.tar.xz'
    assert not destination.exists() and destination.parent.is_dir()
    shutil.copyfile(candidate, destination)
    assert sha(candidate) == sha(destination) and destination.stat().st_size < LIMIT
    assert git_state() == before
    state = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 original_files=originals, original_file_count=len(originals),
                 original_total_bytes=sum(r['bytes'] for r in originals.values()),
                 archive=dict(path=destination.name, bytes=destination.stat().st_size,
                              sha256=sha(destination), member_count=count,
                              compression='xz / LZMA2 preset 9 extreme / CRC64',
                              exact_root_filenames=True, every_member_reopened_byte_equal_to_original=True),
                 before_git=before)
    write_new(STATE, state)
    print(json.dumps(dict(original_files=len(originals), original_bytes=state['original_total_bytes'],
                          archive=state['archive'], original_README=originals['README.md']), indent=2))


def finish():
    state = json.loads(STATE.read_text())
    originals = state['original_files']
    for name, receipt in originals.items():
        if name != 'README.md':
            assert sha(HERE / name) == receipt['sha256'], name
    original_readme = (TEMP / 'README-before-publication.md').read_text()
    published_readme = (HERE / 'README.md').read_text()
    # Exact address is drawn from preserved original bytes, never substituted in receipts.
    import re
    private = re.search(r'`([^`]+@\d+\.\d+\.\d+\.\d+)`', original_readme).group(1)
    assert private not in published_readme and private in original_readme
    current = git_state()
    assert current == state['before_git'], 'Git or production changed during publication work'
    names = ['README.md', 'PROTOCOL.md', 'ACCEPTANCE_PLAN.md', 'PUBLICATION.md',
             'raw-examples.png', 'ACCEPTANCE.json', 'raw-evidence.tar.xz',
             'caster-controls.json', 'manifest-before.json', 'manifest-after.json', 'manifest-final.json',
             'artifact-manifest.json', 'container-member-checks.json', 'fresh-raw-recheck-complete.json',
             'raw-anchor-coordinate-check-complete.json', 'run-summary.json', 'additional-controls-summary.json',
             'floor-summary.json', 'near-control-summary.json', 'raw-examples.json',
             'h1_publish.py', 'h1_verify_publication.py']
    names += [name for name in originals if name.endswith('.py')]
    assert len(names) == len(set(names))
    files = {name: dict(bytes=(HERE / name).stat().st_size, sha256=sha(HERE / name)) for name in sorted(names)}
    assert all(r['bytes'] < 20_000_000 for r in files.values())
    payload_bytes = sum(r['bytes'] for r in files.values())
    assert payload_bytes < 20_000_000
    manifest = dict(schema='resense-h1-rail-publication-v1', created_utc=state['created_utc'],
        evidence_path='docs/evidence/h1_rail_limits_2026-10-20',
        measured_head=json.loads((HERE / 'manifest-before.json').read_text())['head'],
        publication_worktree_state=current,
        exact_allowlist=sorted(names + ['publication-manifest.json', 'SHA256SUMS-publication']),
        files=files, payload_bytes_excluding_integrity_envelopes=payload_bytes,
        archive={**state['archive'], 'members': originals},
        historical_checksum_policy=dict(
            original_SHA256SUMS_sha256=originals['SHA256SUMS']['sha256'],
            original_SHA256SUMS_preserved_verbatim_in_archive=True,
            original_artifact_manifest_preserved=True,
            original_README=originals['README.md'], published_README=files['README.md'],
            README_change='Remove private SSH address; add publication/extraction link only',
            extraction='Archive README.md restores historical README; use separate review directory'),
        checks=dict(no_detector_replay=True, git_index_HEAD_production_unchanged=True,
                    original_receipts_unchanged=True, original_members_verified=len(originals),
                    archive_member_byte_comparison=True, no_pycache=True,
                    every_original_retained_on_VM=True))
    write_new(HERE / 'publication-manifest.json', manifest)
    sums = {name: r['sha256'] for name, r in files.items()}
    sums['publication-manifest.json'] = sha(HERE / 'publication-manifest.json')
    target = HERE / 'SHA256SUMS-publication'
    assert not target.exists()
    target.write_text(''.join(digest + '  ' + name + '\n' for name, digest in sorted(sums.items())), encoding='utf-8')
    total = sum((HERE / name).stat().st_size for name in manifest['exact_allowlist'])
    assert total < 20_000_000
    print(json.dumps(dict(allowlist_files=len(manifest['exact_allowlist']), publication_total_bytes=total,
        archive_bytes=state['archive']['bytes'], archive_sha256=state['archive']['sha256'],
        manifest_sha256=sha(HERE / 'publication-manifest.json'),
        publication_checksums_sha256=sha(target)), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('prepare', 'finish'))
    args = parser.parse_args()
    globals()[args.phase]()
