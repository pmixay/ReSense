"""Portable, read-only publication verifier; optional extraction uses GNU tar/sha256sum.

This tool never imports detector code or performs a detector replay.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def check_digest(actual, expected):
    if actual != expected:
        raise ValueError('SHA-256 mismatch')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--extract-check', type=Path,
                        help='new directory under an already existing parent; verifies exact original restoration')
    args = parser.parse_args()
    manifest = json.loads((HERE / 'publication-manifest.json').read_text())
    allowlist = manifest['exact_allowlist']
    assert len(allowlist) == len(set(allowlist)) and all(Path(n).name == n for n in allowlist)
    for name, receipt in manifest['files'].items():
        path = HERE / name
        assert path.stat().st_size == receipt['bytes'] and path.is_file()
        check_digest(sha(path), receipt['sha256'])
    total = sum((HERE / name).stat().st_size for name in allowlist)
    assert all((HERE / name).stat().st_size < 20_000_000 for name in allowlist)
    assert total < 20_000_000
    sums = {}
    for line in (HERE / 'SHA256SUMS-publication').read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert name in allowlist and name not in sums
        check_digest(sha(HERE / name), expected)
        sums[name] = expected
    assert set(sums) == set(allowlist) - {'SHA256SUMS-publication'}
    archive_receipt = manifest['archive']
    archive_path = HERE / archive_receipt['path']
    members = archive_receipt['members']
    found = {}
    historical_sums = None
    with tarfile.open(archive_path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and Path(member.name).name == member.name
            assert member.name not in found and member.name in members
            assert '__pycache__' not in member.name and not member.name.endswith('.pyc')
            extracted = archive.extractfile(member)
            h = hashlib.sha256()
            size = 0
            data = [] if member.name == 'SHA256SUMS' else None
            while True:
                block = extracted.read(1024 * 1024)
                if not block:
                    break
                h.update(block)
                size += len(block)
                if data is not None:
                    data.append(block)
            assert size == member.size == members[member.name]['bytes']
            check_digest(h.hexdigest(), members[member.name]['sha256'])
            found[member.name] = h.hexdigest()
            if data is not None:
                historical_sums = b''.join(data).decode()
    assert set(found) == set(members) and len(found) == archive_receipt['member_count']
    # Historical absolute paths are interpreted as original filenames without modifying their bytes.
    historical_count = 0
    for line in historical_sums.splitlines():
        expected, old_path = line.split('  ', 1)
        check_digest(found[Path(old_path).name], expected)
        historical_count += 1
    assert historical_count == len(found) - 1  # original SHA256SUMS excludes itself
    original_readme = manifest['historical_checksum_policy']['original_README']['sha256']
    published_readme = manifest['files']['README.md']['sha256']
    assert original_readme == found['README.md'] and original_readme != published_readme
    # Positive control: a real known hash is accepted, changing one nibble is rejected.
    check_digest(found['README.md'], original_readme)
    changed = ('0' if original_readme[0] != '0' else '1') + original_readme[1:]
    try:
        check_digest(found['README.md'], changed)
    except ValueError:
        tamper_detected = True
    else:
        raise AssertionError('digest positive control failed')
    external = None
    if args.extract_check is not None:
        dest = args.extract_check.resolve()
        assert dest.parent.is_dir() and not dest.exists()
        subprocess.run(['xz', '--test', str(archive_path)], check=True)
        listed = subprocess.check_output(['tar', '--list', '--xz', '--file', str(archive_path)], text=True).splitlines()
        assert sorted(listed) == sorted(members)
        dest.mkdir()
        subprocess.run(['tar', '--extract', '--xz', '--file', str(archive_path), '--directory', str(dest)], check=True)
        assert {p.name for p in dest.iterdir()} == set(members)
        for name, receipt in members.items():
            path = dest / name
            assert path.stat().st_size == receipt['bytes']
            check_digest(sha(path), receipt['sha256'])
        checks = ''.join(receipt['sha256'] + '  ' + name + '\n' for name, receipt in sorted(members.items()))
        # Independent executable checks every restored file against original raw receipts.
        result = subprocess.run(['sha256sum', '--check', '--strict'], input=checks, cwd=str(dest),
                                text=True, capture_output=True, check=True)
        external = dict(gnu_tar_list_and_extract=True, xz_integrity=True,
                        sha256sum_originals_checked=len(result.stdout.splitlines()),
                        exact_filenames_and_original_README_restored=True)
    print(json.dumps(dict(publication_files=len(allowlist), publication_total_bytes=total,
        archive_bytes=archive_receipt['bytes'], archive_sha256=sha(archive_path),
        archive_members_checked=len(found), original_historical_checksums_checked=historical_count,
        historical_README_sha256=original_readme, publication_README_sha256=published_readme,
        changed_hash_positive_control=tamper_detected, external_extraction=external), indent=2))


if __name__ == '__main__':
    main()
