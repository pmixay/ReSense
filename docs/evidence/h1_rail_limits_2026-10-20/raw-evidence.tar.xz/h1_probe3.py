from h1_explore import *


def main():
    rows=json.loads((HERE/'forcing-screen-2.json').read_text())
    good=[r for r in rows if r['spec']['host'] and r['fit']['mids'] is not None and
        max(abs(x-r['spec']['distractor']) for x in r['fit']['mids'])<.12]
    print('HOST_PRESENT_FOUND',*good,sep='\n')
    # Grid-position/width screen; these are forcing trials, not acceptance cases.
    cfg=DetectorConfig()
    model=TrackModel(np.array([0.,0.,-2.18]),(3.,120.),0.,0.,0.)
    more=[]
    for offset in (.375,.4,.425,.575,.6,.625):
        for rw in (.08,.12,.20,.30):
            for dh in (.35,.40,.46):
                spec=dict(distractor=offset,distractor_height=dh,distractor_width=rw)
                xyz,ring,lab=cast(**spec)
                fit=estimate_rails(xyz,model,cfg.track,0.,prior=model)
                more.append(dict(spec=spec,fit=serial(fit)))
    write('forcing-screen-3.json',more)
    good3=[r for r in more if r['fit']['mids'] is not None and
        max(abs(x-r['spec']['distractor']) for x in r['fit']['mids'])<.12]
    print('HOST_NORMAL_FOUND',*good3,sep='\n')
    specs=[r['spec'] for r in good if r['spec']['host_height']==.2][:2]
    specs += [r['spec'] for r in good3][:4]
    probes=[]
    for spec in specs:
        for lateral in (.68,-.68,1.29):
            xyz,ring,lab=cast(**spec,lateral=lateral)
            det=Detector(cfg)
            ff=[]
            for i in range(14):
                if det._previous_latency_ms is not None: det._previous_latency_ms=42.
                r=det.process(Frame(xyz=xyz,intensity=np.full(len(xyz),35,np.float32),ring=ring,stamp=i*.1))
                fit=estimate_rails(r.xyz,r.track,cfg.track,r.track.center,prior=r.track)
                ff.append(dict(i=i,track=serial(r.track),fit=serial(fit),
                    candidates=[serial(c) for c in r.candidates if abs(c.distance-67)<1],
                    detections=serial(r.detections),warnings=serial(r.warnings)))
            probes.append(dict(spec=spec,lateral=lateral,frames=ff))
            print('FULL3',spec,lateral,'center',r.track.center,'fit',fit.center,fit.mids,
                  'cand',[(c.zone,c.reason,c.collision_core) for c in r.candidates if abs(c.distance-67)<1],
                  'STOP',any(abs(d.distance-67)<1 for d in r.detections))
    write('full-forcing-probes-3.json',probes)


if __name__=='__main__': main()
