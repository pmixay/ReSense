"""Direct raw examples, independent of detector-selected coordinates."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
names=['correct_1.5','wrong_0.6_1.5_67.0','wrong_0.4_-0.68_67.0','no_rails_67.0_-2.18']
fig,axes=plt.subplots(2,4,figsize=(16,7))
examples=[]
for col,name in enumerate(names):
    data=json.loads((HERE/(name+'.json')).read_text());frame=data['frames'][13]
    raw=np.load(HERE/frame['input']);p=raw['xyz'];labels=raw['labels'];spec=data['inputs'][frame['input']]['geometry']
    colors={1:'red',10:'blue',11:'blue',20:'orange',21:'orange'}
    for label,color in colors.items():
        q=p[(labels==label)&(p[:,0]<80)]
        axes[0,col].scatter(q[:,0],q[:,1],s=2,c=color)
    axes[0,col].axhspan(-1.05,1.05,color='green',alpha=.1)
    axes[0,col].set(xlim=(0,75),ylim=(-2.5,2.5),xlabel='raw X (m)',ylabel='raw Y (m)',title=name)
    q=p[labels==1];head=spec.get('bed',-2.18)+spec.get('host_height',.35)
    axes[1,col].scatter(q[:,1],q[:,2]-head,s=9,c='red')
    axes[1,col].plot([-1.05,1.05,1.05,-1.05,-1.05],[.12,.12,3.,3.,.12],color='green',label='true host envelope')
    model=frame['output']['track'];x=spec.get('distance',67.)
    center=model['center']+np.tan(model['yaw'])*x+.5*model['curvature']*x*x
    axes[1,col].axvline(center,color='purple',ls='--',label='selected model axis')
    axes[1,col].set(xlim=(-2,2),ylim=(-.1,3.6),xlabel='raw Y (m)',ylabel='height above true host (m)')
    examples.append(dict(case=name,raw_points=q[::max(1,len(q)//5)][:6].tolist(),host_head_z=head,
        raw_target_y_bounds=[float(q[:,1].min()),float(q[:,1].max())],selected_center_at_target=float(center),
        target_detections=frame['target_detection_indices']))
axes[1,0].legend(fontsize=7)
fig.tight_layout();fig.savefig(HERE/'raw-examples.png',dpi=130);plt.close(fig)
path=HERE/'raw-examples.json';assert not path.exists();path.write_text(json.dumps(examples,indent=2)+'\n')
print(json.dumps(examples,indent=2))
