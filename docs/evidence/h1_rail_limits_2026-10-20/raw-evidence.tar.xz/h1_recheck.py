"""Fresh raw-input replay and separate exact/physical/component checks."""
import copy
import dataclasses
import hashlib
import json
from pathlib import Path
import runpy
import struct
import os
import numpy as np
from resense.config import DetectorConfig
from resense.detector import Detector
from resense.frame import Frame
from h1_verify import HERE,load,save,verify_fit


def encode(v):
    if dataclasses.is_dataclass(v):
        return {f.name:encode(getattr(v,f.name)) for f in dataclasses.fields(v)}
    if isinstance(v,np.ndarray):
        return {'dtype':v.dtype.str,'shape':list(v.shape),'sha256':hashlib.sha256(memoryview(np.ascontiguousarray(v))).hexdigest()}
    if isinstance(v,np.generic): return encode(np.asarray(v))
    if isinstance(v,float): return {'f64':v.hex()}  # decoded below, independent hex-float encoding
    if isinstance(v,dict): return {str(k):encode(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)): return [encode(x) for x in v]
    return v


def compare(actual,record):
    if isinstance(actual,dict):
        if set(actual)=={'f64'}:
            bits=bytes.fromhex(record['f64'])
            return struct.pack('>d',float.fromhex(actual['f64']))==bits
        return isinstance(record,dict) and actual.keys()==record.keys() and all(compare(actual[k],record[k]) for k in actual)
    if isinstance(actual,list): return isinstance(record,list) and len(actual)==len(record) and all(compare(a,b) for a,b in zip(actual,record))
    return type(actual)==type(record) and actual==record


def main():
    summaries=load('run-summary.json')+load('additional-controls-summary.json')+load('floor-summary.json')
    if (HERE/'near-control-summary.json').exists(): summaries+=load('near-control-summary.json')
    cases=[]; examples=[]; checks=[]
    for summary in summaries:
        data=load(summary['name']+'.json')
        d=Detector(DetectorConfig());passed=[]
        for frame in data['frames']:
            raw=np.load(HERE/frame['input'])
            if d._previous_latency_ms is not None: d._previous_latency_ms=42.
            r=d.process(Frame(xyz=raw['xyz'],ring=raw['ring'],intensity=np.full(len(raw['xyz']),35,np.float32),stamp=frame['i']*.1))
            actual={f.name:encode(getattr(r,f.name)) for f in dataclasses.fields(r) if f.name!='timing_ms'}
            actual['tracker']=encode(d.tracker.tracks)
            ok=compare(actual,frame['exact']);assert ok,(summary['name'],frame['i'])
            passed.append(ok)
            if summary['name'] in ('wrong_0.6_1.5_67.0','wrong_0.4_-0.68_67.0',
                    'no_rails_67.0_-2.18','loss_target_remains','loss_target_absent','actual_floor_held','actual_floor_recovery') and frame['i'] in (0,4,13,14,15,17,18,20,21,25,27):
                cand=[r.candidates[j] for j in frame['target_candidates']]
                tracks=[t for t in d.tracker.tracks if abs(t.centroid[0]-67.)<1]
                checks.append(dict(case=summary['name'],i=frame['i'],track=frame['output']['track'],
                    candidates=[dict(zone=c.zone,reason=c.reason,core=c.collision_core,n=c.n,n_gauge=c.n_gauge) for c in cand],
                    tracks=[dict(id=t.id,hits=t.hits,misses=t.misses,reported=t.reported,zone=t.zone,
                         column_hist=t.column_hist,zone_hist=t.zone_hist,core_hits=t.collision_core_hits,
                         core_ready=t.collision_core_ready,hold=t.hold,kept=t.kept) for t in tracks],
                    detections=frame['target_detection_indices'],warnings=frame['target_warning_indices'],
                    executed_core_exits=[dict(line=e['line'],result=e['result']) for e in frame['events'] if e['function']=='_collision_core']))
        cases.append(dict(name=summary['name'],scans=len(passed),exact_fields_and_tracker=all(passed)))
    # Positive controls: an IEEE ULP, signed zero, dtype, and a deleted known target detection.
    target=load('correct_standard.json')['frames'][4]
    record=target['exact'];controls={}
    mutated=copy.deepcopy(record)
    old=struct.unpack('>d',bytes.fromhex(mutated['stamp']['f64']))[0]
    new=np.nextafter(old,np.inf).item()
    mutated['stamp']['f64']=struct.pack('>d',new).hex()
    actual=copy.deepcopy(record)
    def as_actual(v):
        if isinstance(v,dict):
            if set(v)=={'f64'}: return {'f64':struct.unpack('>d',bytes.fromhex(v['f64']))[0].hex()}
            return {k:as_actual(x) for k,x in v.items()}
        if isinstance(v,list): return [as_actual(x) for x in v]
        return v
    actual=as_actual(actual)
    controls['one_ULP_detected']=not compare(actual,mutated)
    controls['known_positive_detection']=bool(target['target_detection_indices'])
    mutated=copy.deepcopy(record);mutated['detections']=[]
    controls['deleted_detection_detected']=not compare(actual,mutated)
    controls['signed_zero_detected']=not compare({'f64':(-0.).hex()},{'f64':struct.pack('>d',0.).hex()})
    arr=np.array([1.],dtype=np.float32)
    controls['dtype_detected']=not compare(encode(arr.astype(np.float64)),encode(arr))
    assert all(controls.values())
    # Component-only: reconstruct exact fixture inputs and independently check selected fits.
    fixture=runpy.run_path(str(Path(os.environ['RESENSE_REPO'])/'tests/fixtures/h1_physical.py'))['physical_column']
    components=[]
    for row in load('components.json'):
        if 'axis' not in row:
            assert row['model']['floor_held'] and row['anchor'] is None and row['interval'] is None
            components.append(dict(scope=row['scope'],guard_missing_anchor=True))
            continue
        raw=np.load(HERE/row['input']['file'])
        xyz,ring,label=fixture(rails=True,lateral=row['input']['geometry']['lateral'],wall_left=4.1,wall_right=-4.1,extra_rails=row['extra'])
        assert np.array_equal(xyz,raw['xyz']) and np.array_equal(ring,raw['ring']) and np.array_equal(label,raw['labels'])
        model=dict(floor_coef=[0.,0.,-2.18],floor_range=[3.,120.],center=row['axis'],yaw=0.,curvature=0.,curv_step=0.,curv_knot=0.)
        e=dict(cfg=load('manifest-before.json')['config']['track'],floor=model,prior=model,prior_center=row['axis'],result=row['fit'])
        fit=verify_fit(xyz,e)
        components.append(dict(axis=row['axis'],lateral=row['input']['geometry']['lateral'],extra=row['extra'],
            independently_verified_fit=fit,selected_mids=row['fit']['mids'],
            core=any(c['collision_core'] for c in row['clusters']),STOP=any(any(s) for s in row['stop'])))
    # Loaded library provenance (read only; all artifact writes stay in evidence).
    libraries={}
    for line in Path('/proc/self/maps').read_text().splitlines():
        path=line.split()[-1]
        if path.startswith('/') and ('.so' in path or path.endswith('/python3.12')) and Path(path).is_file():
            libraries[path]=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    import sys
    save(sys.argv[1] if len(sys.argv)>1 else 'fresh-raw-recheck.json',dict(cases=cases,scans=sum(c['scans'] for c in cases),controls=controls,
                                    components=components,runtime_libraries=libraries))
    if not (HERE/'selected-raw-snapshots.json').exists(): save('selected-raw-snapshots.json',checks)
    print('FRESH_RAW_EXACT',sum(c['scans'] for c in cases),'CASES',len(cases),'CONTROLS',controls)
    print('COMPONENTS',components)
    for row in checks:
        print('SNAPSHOT',row['case'],row['i'],'slabs',row['track']['rail_slabs'],'held',row['track']['floor_held'],
              'cand',row['candidates'],'tracks',row['tracks'],'dets',row['detections'])


if __name__=='__main__': main()
