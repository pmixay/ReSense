from h1_run import *


def main():
    d=Detector(DetectorConfig());xyz,ring,labels=cast(walls=2.43)
    for i in range(14):
        if d._previous_latency_ms is not None: d._previous_latency_ms=42.
        d.process(Frame(xyz=xyz,intensity=np.full(len(xyz),35,np.float32),ring=ring,stamp=i*.1))
    rows=[]
    for distance in (7.,9.,11.,13.):
        for top in (.8,1.4,1.9):
            dd=copy.deepcopy(d)
            spec=dict(host=False,shadow=True,walls=2.43,shadow_distance=distance,shadow_top=top)
            xyz,ring,labels=cast(**spec)
            dd._previous_latency_ms=42.
            cap=Capture(67.)
            sys.setprofile(cap)
            try: r=dd.process(Frame(xyz=xyz,intensity=np.full(len(xyz),35,np.float32),ring=ring,stamp=1.4))
            finally: sys.setprofile(None)
            rows.append(dict(spec=spec,track=serial(r.track),events=cap.events))
            print(distance,top,'HELD',r.track.floor_held,'SHADOW',r.track.floor_shadow,'AGE',r.track.age,flush=True)
    write('floor-forcing-screen.json',rows)
    found=[r for r in rows if r['track']['floor_held']]
    if found:
        spec=found[0]['spec']
        results=[full_case('actual_floor_held',[(14,dict(walls=2.43)),(14,spec)]),
                 full_case('actual_floor_recovery',[(14,dict(walls=2.43)),(7,spec),(7,dict(walls=2.43))])]
        write('floor-summary.json',results)


if __name__=='__main__': main()
