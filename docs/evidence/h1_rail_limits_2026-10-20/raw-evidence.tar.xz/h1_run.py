"""Final H1 directed physical evidence; unmodified detector, profile-hook capture."""
import copy
import dataclasses as dc
import gzip
import struct
import tarfile
from h1_explore import *
from resense.clustering import FrameRays
from resense import _native


def hashfile(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def fingerprint(x):
    """Exact canonical record including ndarray dtype/shape/bytes and IEEE float bits."""
    if dc.is_dataclass(x): return {f.name:fingerprint(getattr(x,f.name)) for f in dc.fields(x)}
    if isinstance(x,np.ndarray): return dict(dtype=x.dtype.str,shape=list(x.shape),sha256=digest(x))
    if isinstance(x,np.generic): return fingerprint(np.asarray(x))
    if isinstance(x,float): return {'f64':struct.pack('>d',x).hex()}
    if isinstance(x,dict): return {str(k):fingerprint(v) for k,v in sorted(x.items())}
    if isinstance(x,(list,tuple)): return [fingerprint(v) for v in x]
    return x


def exact_result(r,det):
    data={f.name:fingerprint(getattr(r,f.name)) for f in dc.fields(r) if f.name!='timing_ms'}
    data['tracker']=fingerprint(det.tracker.tracks)
    return data


def input_record(xyz,ring,labels,spec):
    key=digest(xyz)[:20]
    p=HERE/('raw_'+key+'.npz')
    if not p.exists(): np.savez_compressed(p,xyz=xyz,ring=ring,labels=labels)
    assert p.stat().st_size<20_000_000
    head=spec.get('bed',-2.18)+spec.get('host_height',.35)
    pts=xyz[labels==1]
    h=pts[:,2].astype(float)-head
    inside=(np.abs(pts[:,1])<=1.05)&(h>=.12)&(h<=3.)
    examples={str(k):serial(xyz[np.flatnonzero(labels==k)[::max(1,int((labels==k).sum())//4)][:5]])
              for k in np.unique(labels)}
    return dict(file=p.name,xyz=fingerprint(xyz),ring=fingerprint(ring),labels=fingerprint(labels),
                geometry=spec,host_head_z=head,host_pair=[-.795,.795],
                counts={str(k):int((labels==k).sum()) for k in np.unique(labels)},
                target_bounds=None if not len(pts) else [pts.min(0).tolist(),pts.max(0).tolist()],
                raw_host_body_points=int(inside.sum()),raw_examples=examples)


class Capture:
    def __init__(self,distance): self.events=[]; self.distance=distance

    def __call__(self,fr,event,value):
        if event!='return': return
        name=fr.f_code.co_name
        if name not in ('estimate_rails','collision_axis_anchor','collision_axis_interval',
                        '_collision_core','_advisory_reason','_qualifies','_floor_shadow'):
            return
        loc=fr.f_locals
        item=dict(function=name,line=fr.f_lineno,caller=fr.f_back.f_code.co_name)
        if name=='estimate_rails':
            item.update(result=serial(value),floor=serial(loc['floor']),prior=serial(loc['prior']),
                        prior_center=loc['prior_center'],cfg=serial(loc['cfg']),xyz_sha=digest(loc['xyz']))
        elif name in ('collision_axis_anchor','collision_axis_interval'):
            rays=loc['self']
            item.update(result=serial(value),model=serial(rays.track),
                anchor=serial(rays._core_anchor),stations=serial(rays._core_rail_stations),
                x=loc.get('x'),boundaries=serial(rays._core_boundaries))
        elif name=='_collision_core':
            b=loc['b']
            if abs(float(b.pts[:,0].mean())-self.distance)>1: return
            ix=b.idx
            item.update(result=bool(value),idx=serial(ix),pts=serial(b.pts),
                        bbox=[serial(b.bmin),serial(b.bmax)],
                        arrays={k:serial(loc[k][ix]) for k in ('dy','h','in_gauge','in_rail','inv','frame_idx')},
                        interval=serial(loc.get('interval')),current=serial(loc.get('current')),
                        keep=serial(loc.get('keep')),k=serial(loc.get('k')))
        elif name=='_advisory_reason':
            item.update(result=serial(value))
        elif name=='_qualifies':
            t=loc.get('t')
            if t is None or abs(float(t.centroid[0])-self.distance)>1: return
            item.update(result=serial(value),track=serial(t))
        elif name=='_floor_shadow':
            item.update(result=serial(value))
        self.events.append(item)


def matches(ds,spec):
    return [i for i,d in enumerate(ds) if abs(d.distance-spec.get('distance',67.))<1 and
            abs(float(d.center[1])-spec.get('lateral',.68))<.5]


def full_case(name,stages):
    frames=[]
    for n,spec in stages:
        xyz,ring,lab=cast(**spec)
        inp=input_record(xyz,ring,lab,spec)
        frames.extend([(spec,xyz,ring,lab,inp)]*n)
    arms=[]
    for traced in (False,True):
        det=Detector(DetectorConfig())
        rows=[]
        for i,(spec,xyz,ring,lab,inp) in enumerate(frames):
            if det._previous_latency_ms is not None: det._previous_latency_ms=42.
            cap=Capture(spec.get('distance',67.))
            if traced: sys.setprofile(cap)
            try:
                r=det.process(Frame(xyz=xyz,intensity=np.full(len(xyz),35,np.float32),ring=ring,stamp=i*.1))
            finally:
                sys.setprofile(None)
            exact=exact_result(r,det)
            out={f.name:serial(getattr(r,f.name)) for f in dc.fields(r)
                 if f.name not in ('timing_ms','xyz','corridor_idx')}
            out['xyz']=fingerprint(r.xyz)
            out['corridor_idx']=serial(r.corridor_idx)
            # Save processed raw points only when mount correction changes exact bytes.
            processed='raw_'+digest(r.xyz)[:20]+'.npz'
            pp=HERE/processed
            if not pp.exists(): np.savez_compressed(pp,xyz=r.xyz)
            assert pp.stat().st_size<20_000_000
            row=dict(i=i,input=inp['file'],processed=processed,output=out,
                exact=exact,tracker=serial(det.tracker.tracks),events=cap.events,
                target_detection_indices=matches(r.detections,spec),
                target_warning_indices=matches(r.warnings,spec),
                target_candidates=[j for j,c in enumerate(r.candidates)
                                   if abs(c.distance-spec.get('distance',67.))<1 and
                                   abs(float(c.centroid[1])-spec.get('lateral',.68))<.5])
            rows.append(row)
        arms.append(rows)
    equality=[a['exact']==b['exact'] for a,b in zip(*arms)]
    assert all(equality), (name,[i for i,v in enumerate(equality) if not v])
    # Positive perturbation control for exact comparator and target matcher.
    modified=copy.deepcopy(arms[0][-1]['exact'])
    modified['n_points']+=1
    controls=dict(exact_perturbation_detected=modified!=arms[0][-1]['exact'])
    report=dict(name=name,scope='full default Detector; observed raw rays; no supplied model',
                stages=stages,inputs={x[4]['file']:x[4] for x in frames},
                plain_traced_exact=equality,controls=controls,frames=arms[1])
    write(name+'.json',report)
    pos=[r['i'] for r in arms[1] if r['target_detection_indices']]
    cores=[r['i'] for r in arms[1] if any(r['output']['candidates'][j]['collision_core'] for j in r['target_candidates'])]
    print(name,'SCANS',len(frames),'STOP',pos,'CORE',cores,'FINAL_CENTER',r.track.center,flush=True)
    return dict(name=name,scans=len(frames),stop_frames=pos,core_frames=cores,equal=all(equality))


def component_cases():
    helper=runpy.run_path(str(ROOT/'tests/test_column_collision_core.py'))
    rows=[]
    for axis in (0.,1.59,-1.59):
        for lateral in (.68,1.5,-1.5):
            extra=[] if axis==0 else [np.sign(axis)*2.385]
            xyz,ring,lab=helper['physical_column'](lateral=lateral,wall_left=4.1,wall_right=-4.1,extra_rails=extra)
            model=TrackModel(np.array([0.,0.,-2.18]),(3.,120.),axis,0.,0.)
            fit=estimate_rails(xyz,model,DetectorConfig().track,axis,prior=model)
            rr=FrameRays(xyz,ring,xyz[:,2]+1.83,xyz[:,1]-axis,model,DetectorConfig().track)
            cc=helper['matched'](xyz,ring,lab,axis_error=axis)
            spec=dict(lateral=lateral)
            rows.append(dict(axis=axis,extra=extra,scope='supplied-coordinate component ONLY',
                    input=input_record(xyz,ring,lab,spec),fit=serial(fit),anchor=rr.collision_axis_anchor(),
                    interval=rr.collision_axis_interval(67.),clusters=serial(cc),
                    stop=[helper['stop_history'](c) for c in cc]))
    xyz,ring,lab=cast(walls=2.43)
    model=TrackModel(np.array([0.,0.,-2.18]),(3.,120.),0.,0.,0.,floor_held=True)
    rr=FrameRays(xyz,ring,xyz[:,2]+1.83,xyz[:,1],model,DetectorConfig().track)
    rows.append(dict(scope='supplied floor_held component ONLY',anchor=rr.collision_axis_anchor(),
                     interval=rr.collision_axis_interval(67.),model=serial(model),input=input_record(xyz,ring,lab,{})))
    write('components.json',rows)


def manifest():
    freeze=json.loads((ROOT/'docs/evidence/detector_freeze_2026-10-20_1.2.0_r3.json').read_text())
    files=sorted(set(freeze['files'])|{'tests/fixtures/h1_physical.py','tests/test_column_collision_core.py',
        'scripts/detector_freeze.py','CLAUDE.md','docs/DETECTOR_FREEZE.md'})
    return dict(head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),
        index_sha=hashfile(ROOT/'.git/index'),files={f:hashfile(ROOT/f) for f in files},
        config=serial(DetectorConfig()),native_enabled=_native.enabled(),
        environment={k:os.environ.get(k) for k in ('RESENSE_REPO','PYTHONPATH','OPENBLAS_CORETYPE',
            'OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','LD_LIBRARY_PATH','PYTHONDONTWRITEBYTECODE')},
        python=sys.version,executable=sys.executable)


def main():
    before=manifest()
    assert before['head']=='f56ad5e62d9d051811c804734c7731b6951eae90'
    write('manifest-before.json',before)
    cases=[]
    # Basic controls, including matching lower host height used in the wrong fits.
    for lateral in (.68,-.68,1.5):
        cases.append(('correct_'+str(lateral),[(14,dict(lateral=lateral,host_height=.2))]))
    cases.append(('correct_standard',[(14,dict(walls=2.43))]))
    for offset,lateral,distance in ((.4,1.29,67.),(.6,1.5,67.),(.4,-.68,67.),
            (.6,-.68,67.),(-.6,-1.5,67.),(-.6,.68,67.),(.6,1.5,37.),
            (.6,1.5,17.),(.6,-.68,17.)):
        spec=dict(host_height=.2,distractor_height=.3,distractor=offset,lateral=lateral,distance=distance)
        cases.append(('wrong_'+str(offset)+'_'+str(lateral)+'_'+str(distance),[(14,spec)]))
    for distance,bed in ((67.,-2.18),(17.,-2.18),(67.,-1.83)):
        cases.append(('no_rails_'+str(distance)+'_'+str(bed),[(14,dict(host=False,distance=distance,bed=bed,walls=2.43))]))
    warm=dict(walls=2.43)
    cases.extend([
        ('loss_target_remains',[(14,warm),(14,dict(host=False,walls=2.43))]),
        ('loss_target_absent',[(14,warm),(14,dict(host=False,target=False,walls=2.43))]),
        ('loss_shadow_held',[(14,warm),(14,dict(host=False,shadow=True,walls=2.43))]),
        ('shadow_removed_control',[(14,warm),(7,dict(host=False,shadow=True,walls=2.43)),(7,warm)]),
    ])
    summaries=[full_case(*case) for case in cases]
    component_cases()
    after=manifest()
    write('manifest-after.json',after)
    assert before==after
    # Compact exact source snapshot, excluding old evidence / data.
    p=HERE/'source.tar.gz'
    with tarfile.open(p,'w:gz') as tar:
        for f in before['files']: tar.add(ROOT/f,arcname=f,recursive=False)
    assert p.stat().st_size<20_000_000
    write('run-summary.json',summaries)
    print('SOURCE_INDEX_UNCHANGED',before==after,flush=True)


if __name__=='__main__': main()
