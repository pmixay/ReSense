"""Independent audit from saved raw points/snapshots; no production geometry helpers."""
import collections
import dataclasses
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import sys
import numpy as np

HERE=Path(__file__).resolve().parent


def load(p): return json.loads((HERE/p).read_text())


def sha(a): return hashlib.sha256(a.tobytes()).hexdigest()


def save(p,v):
    path=HERE/p
    assert not path.exists()
    path.write_text(json.dumps(v,separators=(',',':'),allow_nan=False)+'\n')
    assert path.stat().st_size<20_000_000


def bed_z(model,x):
    coef=model['floor_coef']; lo,hi=model['floor_range']
    u=np.clip(x,lo,hi)
    return np.polyval(coef,u)+np.polyval(np.polyder(coef),u)*(x-u)


def shape(model,x):
    if model is None: return np.zeros_like(x)
    return (math.tan(model['yaw'])*x+.5*model['curvature']*x*x+
            .5*model['curv_step']*np.maximum(x-model['curv_knot'],0)**2)


def profile(y,z,edges,p,minn):
    out=np.full(len(edges)-1,np.nan)
    # Explicit order statistics, independently from native/bin_percentile helpers.
    for i in range(len(out)):
        v=sorted(z[(y>=edges[i])&(y<edges[i+1])])
        if len(v)<minn: continue
        rank=(len(v)-1)*p/100
        low=math.floor(rank); high=math.ceil(rank)
        out[i]=v[low]*(high-rank)+v[high]*(rank-low) if low!=high else v[low]
    return out


def verify_fit(points,e):
    cfg=e['cfg']; prior=e['prior']; floor=e['floor']; pc=e['prior_center']
    x0,x1=cfg['rails_range']; half=cfg['rails_search_halfwidth']; step=cfg['rails_bin']
    p=points[(points[:,0]>x0)&(points[:,0]<x1)]
    x=p[:,0].astype(float); y=p[:,1].astype(float)-shape(prior,x)
    h=p[:,2]-bed_z(floor,x)
    keep=(abs(y-pc)<half)&(h>-.4)&(h<.8)
    x,y,h=x[keep],y[keep],h[keep]
    fit=e['result']
    if len(x)<200:
        assert fit['score']==-1 and fit['xm'] is None
        return None
    edges=np.arange(pc-half,pc+half+step,step)
    centers=edges[:-1]+step/2
    k=max(1,round(.25/step)); hs=round(.5*cfg['rails_spacing']/step)

    def ridge(v):
        r=np.full(len(v),np.nan)
        for i in range(k,len(v)-k): r[i]=v[i]-(v[i-k]+v[i+k])/2
        return r

    prof=profile(y,h,edges,cfg['rails_percentile'],8); rid=ridge(prof)
    best=-1; bins=None; center=pc
    for b in range(hs,len(prof)-hs):
        left,right=b-hs,b+hs
        if all(np.isfinite(rid[j]) and cfg['rails_head_height'][0]<prof[j]<cfg['rails_head_height'][1]
               for j in (left,right)):
            score=min(rid[left],rid[right])
            if score>best: best=score;bins=(left,right);center=centers[b]
    assert abs(best-fit['score'])<2e-7,(best,fit['score'])
    if bins is None:
        assert fit['xm'] is None
        return None
    xs=[];mids=[];weights=[]
    cuts=np.linspace(x0,x1,cfg['rails_yaw_slabs']+1)
    dev=max(1,round(cfg['rails_yaw_max_dev']/step))
    for a,b in zip(cuts[:-1],cuts[1:]):
        mask=(x>=a)&(x<b)
        if mask.sum()<100: continue
        v=profile(y[mask],h[mask],edges,cfg['rails_percentile'],4); r=ridge(v)
        positions=[];w=[]
        for base in bins:
            candidates=list(range(max(k,base-dev),min(len(v)-k,base+dev+1)))
            candidates=[j for j in candidates if np.isfinite(r[j])]
            if not candidates: break
            j=max(candidates,key=lambda t:r[t])
            if not (r[j]>=.5*cfg['rails_min_score'] and cfg['rails_head_height'][0]<v[j]<cfg['rails_head_height'][1]): break
            sub=0.
            if j>0 and j<len(r)-1 and np.isfinite(r[j-1:j+2]).all():
                d=r[j-1]-2*r[j]+r[j+1]
                if d < -1e-9: sub=float(np.clip(.5*(r[j-1]-r[j+1])/d,-.5,.5))
            positions.append(centers[j]+sub*step);w.append(r[j])
        if len(positions)==2:
            xs.append((a+b)/2);mids.append(sum(positions)/2);weights.append(min(w))
    assert len(mids)==fit['n_slabs'],(len(mids),fit['n_slabs'])
    if len(mids)<max(2,cfg['rails_yaw_min_slabs']):
        assert fit['mids'] is None
        return dict(global_center=float(center),slabs=len(mids))
    xx=np.asarray(xs); yy=np.asarray(mids)+shape(prior,xx)
    assert np.max(abs(yy-np.asarray(fit['mids'])))<1e-7,(yy,fit['mids'])
    # Weighted centered covariance, a different regression from np.polyfit.
    w=np.asarray(weights); u=yy-.5*(0. if prior is None else prior['curvature'])*xx**2
    mx=np.average(xx,weights=w); my=np.average(u,weights=w)
    slope=np.sum(w*(xx-mx)*(u-my))/np.sum(w*(xx-mx)**2)
    intercept=my-slope*mx
    assert abs(intercept-fit['center'])<1e-7
    return dict(global_center=float(center),raw_recomputed_center=float(intercept),slabs=len(mids))


def verify_core(e,cfg):
    a=e['arrays']; pts=np.asarray(e['pts']); n=len(pts)
    current=[i for i in range(n) if a['frame_idx'][i]>=0 and a['in_gauge'][i] and a['in_rail'][i]]
    footprint=pts.max(0)-pts.min(0)
    if max(footprint[:2])>cfg['cluster']['column_core_max_footprint']:
        expected=False; reason='footprint'
    elif len(current)<cfg['cluster']['column_core_min_voxels']:
        expected=False;reason='current_support'
    elif e['interval'] is None:
        expected=False;reason='no_interval'
    else:
        kept=[];mask=[]
        for i in current:
            x=float(pts[i,0]);height=a['h'][i]; y=a['dy'][i]
            g=cfg['gauge']; c=cfg['cluster']
            margin=g['edge_margin']+c['column_core_margin']+g['edge_margin_per_100m']*x/100+g['edge_margin_per_100m2']*(x/100)**2
            ok=True
            for delta in e['interval']:
                v=y-delta
                test=v+(1 if v>0 else -1 if v<0 else 0)*margin
                ok &= (-1.05<=test<1.05 and .12<=height<3.)
            mask.append(bool(ok))
            if ok: kept.append(i)
        assert mask==e['keep']
        heights=[a['h'][i] for i in kept]
        expected=bool(kept and len(set(a['inv'][i] for i in kept))>=c['column_core_min_voxels'] and
             max(heights)-min(heights)>=c['column_core_min_height'] and min(heights)<=c['far_max_bottom'])
        reason='body_bars_true' if expected else 'body_bars_false'
    assert expected==e['result'],(reason,e)
    return reason


def scalar_nearest(point,spec):
    length=float(np.linalg.norm(point.astype(float))); ray=point.astype(float)/length
    bed=spec.get('bed',-2.18); walls=spec.get('walls',4.1)
    times=[plane/ray[axis] for axis,plane in ((0,247.),(1,walls),(1,-walls),(2,2.29),(2,bed)) if plane*ray[axis]>0]
    boxes=[]
    if spec.get('target',True):
        d=spec.get('distance',67.);lat=spec.get('lateral',.68);w=spec.get('width',.46)/2;top=spec.get('top',3.22)
        boxes.append(([d-w,lat-w,-1.83],[d+w,lat+w,top-1.83]))
    if spec.get('shadow',False):
        d=spec.get('shadow_distance',7.);w=spec.get('shadow_halfwidth',2.)
        boxes.append(([d,-w,bed],[d+2.,w,spec.get('shadow_top',2.29)]))
    for center,height,width,start in ((0. if spec.get('host',True) else None,spec.get('host_height',.35),.08,spec.get('host_start',3.)),
             (spec.get('distractor'),spec.get('distractor_height',.46),spec.get('distractor_width',.08),spec.get('distractor_start',3.))):
        if center is None: continue
        for side in (-1,1):
            y=center+side*.795
            boxes.append(([start,y-width/2,bed],[247.,y+width/2,bed+height]))
    for lo,hi in boxes:
        enter=-math.inf;leave=math.inf
        for j in range(3):
            p,q=sorted((lo[j]/ray[j],hi[j]/ray[j]));enter=max(enter,p);leave=min(leave,q)
        if leave>=enter>0: times.append(enter)
    return abs(min(times)-length)


def main():
    manifest=load('manifest-before.json');cfg=manifest['config']
    summary=load('run-summary.json')+load('additional-controls-summary.json')
    if (HERE/'floor-summary.json').exists(): summary+=load('floor-summary.json')
    if (HERE/'near-control-summary.json').exists(): summary+=load('near-control-summary.json')
    rows=[]; fit_count=core_count=geometry_samples=0; calibration_fit_count=0; reasons=collections.Counter();max_ray_error=0.
    fits_cache={};raw_cache={};controls={}
    for case in summary:
        data=load(case['name']+'.json');dist=data['stages'][0][1].get('distance',67.)
        true_out=abs(data['stages'][0][1].get('lateral',.68))-.23>1.05
        perframe=[]
        for inp in data['inputs'].values():
            raw=np.load(HERE/inp['file']);raw_cache[inp['file']]=raw
            for key in ('xyz','ring','labels'):
                assert sha(raw[key])==inp[key]['sha256'],(case['name'],key)
            p=raw['xyz'];lab=raw['labels'];spec=inp['geometry'];head=spec.get('bed',-2.18)+spec.get('host_height',.35)
            target=p[lab==1];height=target[:,2].astype(float)-head
            actual=int(((abs(target[:,1])<=1.05)&(height>=.12)&(height<=3.)).sum())
            assert actual==inp['raw_host_body_points']
            for label in np.unique(lab):
                ix=np.flatnonzero(lab==label)
                for j in ix[np.linspace(0,len(ix)-1,min(9,len(ix))).astype(int)]:
                    error=scalar_nearest(p[j],spec); max_ray_error=max(max_ray_error,error)
                    assert error<.0001,(case['name'],label,p[j],error)
                    geometry_samples+=1
        for frame in data['frames']:
            inp=data['inputs'][frame['input']];spec=inp['geometry'];out=frame['output']
            points=np.load(HERE/frame['processed'])['xyz']
            assert sha(points)==out['xyz']['sha256']
            raw=raw_cache[frame['input']]
            rail_slabs=[]
            for a,b in zip((4.,12.6666666667,21.3333333333),(12.6666666667,21.3333333333,30.)):
                rail_slabs.append({str(label):int(((raw['labels']==label)&(raw['xyz'][:,0]>=a)&(raw['xyz'][:,0]<b)).sum()) for label in (10,11,20,21)})
            fits=[];core_exits=[];anchors=[]
            for e in frame['events']:
                if e['function']=='estimate_rails':
                    if e['caller']=='observe_mount':
                        calibration_fit_count+=1
                        continue  # trial mount hypotheses are not the chosen track/core pair
                    assert e['xyz_sha']==sha(points),(case['name'],frame['i'],e['caller'],e['xyz_sha'],sha(points))
                    cachekey=json.dumps(e,sort_keys=True)
                    if cachekey not in fits_cache: fits_cache[cachekey]=verify_fit(points,e)
                    fit_count+=1
                    fit=e['result'];offset=spec.get('distractor')
                    mids=fit['mids']
                    selected='absent_or_insufficient'
                    if mids is not None and fit['score']>=.05 and fit['n_slabs']>=2:
                        if max(abs(v) for v in mids)<.12: selected='host'
                        elif offset is not None and max(abs(v-offset) for v in mids)<.12: selected='distractor'
                        else: selected='mixed_or_other'
                    fits.append(dict(caller=e['caller'],selected=selected,center=fit['center'],xm=fit['xm'],mids=mids))
                elif e['function']=='_collision_core':
                    reason=verify_core(e,cfg);core_count+=1;reasons[reason]+=1;core_exits.append(dict(line=e['line'],rule=reason,result=e['result']))
                elif e['function']=='collision_axis_anchor': anchors.append(dict(line=e['line'],value=e['result'],floor_held=e['model']['floor_held']))
            # Independent interval containment matcher, from raw output positions.
            match=[]
            for i,d in enumerate(out['detections']):
                if dist-1 < d['distance'] < dist+1 and spec.get('lateral',.68)-.5<d['center'][1]<spec.get('lateral',.68)+.5: match.append(i)
            assert match==frame['target_detection_indices']
            if match: controls['matcher_positive']=True
            perframe.append(dict(i=frame['i'],selected_fits=fits,core_exits=core_exits,anchors=anchors,
                target_STOP=bool(match),floor_held=out['track']['floor_held'],rail_slabs_reported=out['track']['rail_slabs'],
                target_candidates=[dict(zone=out['candidates'][j]['zone'],reason=out['candidates'][j]['reason'],core=out['candidates'][j]['collision_core']) for j in frame['target_candidates']],
                current_raw_rail_counts=rail_slabs))
        rows.append(dict(name=case['name'],geometric_outside=true_out,frames=perframe))
    controls.update(core_positive=reasons['body_bars_true']>0,no_interval_positive=reasons['no_interval']>0,
                    fit_host_positive=any(f['selected']=='host' for r in rows for q in r['frames'] for f in q['selected_fits']),
                    fit_wrong_positive=any(f['selected']=='distractor' for r in rows for q in r['frames'] for f in q['selected_fits']))
    assert all(controls.values())
    save(sys.argv[1] if len(sys.argv)>1 else 'independent-check.json',dict(cases=len(rows),scans=sum(len(r['frames']) for r in rows),
         fit_calls=fit_count,unique_fit_recomputations=len(fits_cache),calibration_trial_fit_calls_not_rederived=calibration_fit_count,core_calls=core_count,core_rules=dict(reasons),
         ray_samples=geometry_samples,max_ray_error_m=max_ray_error,controls=controls,rows=rows))
    print('INDEPENDENT',len(rows),'SCANS',sum(len(r['frames']) for r in rows),'FITS',fit_count,
          'CORE',core_count,dict(reasons),'RAYS',geometry_samples,'MAX_ERR',max_ray_error)
    for r in rows:
        selected=collections.Counter(f['selected'] for q in r['frames'] for f in q['selected_fits'])
        print(r['name'],'FITS',dict(selected),'HELD',[q['i'] for q in r['frames'] if q['floor_held']])


if __name__=='__main__': main()
