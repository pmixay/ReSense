"""Final independent package inventory check; refresh only the documented README edit."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as stream:
        while True:
            b=stream.read(1024*1024)
            if not b: break
            h.update(b)
    return h.hexdigest()


def main():
    old=json.loads((HERE/'artifact-manifest.json').read_text())
    checked=0
    for name,record in old['files'].items():
        if name=='README.md': continue  # documented clarification of blocker global STOP
        p=HERE/name
        assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],name
        checked+=1
    files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(HERE.iterdir())
           if p.is_file() and p.name not in ('artifact-manifest.json','SHA256SUMS')}
    assert max(v['bytes'] for v in files.values())<20_000_000
    manifest=dict(files=files,file_count=len(files),total_bytes=sum(v['bytes'] for v in files.values()),
        largest=max(files,key=lambda k:files[k]['bytes']),exclude_self=True,
        finalization=dict(previous_manifest_other_artifacts_verified=checked,README_global_blocker_clarification=True))
    (HERE/'artifact-manifest.json').write_text(json.dumps(manifest,separators=(',',':'))+'\n')
    checks={name:v['sha256'] for name,v in files.items()}
    checks['artifact-manifest.json']=sha(HERE/'artifact-manifest.json')
    path=HERE/'SHA256SUMS';assert not path.exists()
    path.write_text(''.join(h+'  '+str(HERE/name)+'\n' for name,h in sorted(checks.items())))
    print('PRIOR_PACKAGE_CHECKED',checked,'FINAL_FILES',len(checks),'TOTAL_BYTES',manifest['total_bytes'],
          'MAX_FILE',max(v['bytes'] for v in files.values()))


if __name__=='__main__': main()
