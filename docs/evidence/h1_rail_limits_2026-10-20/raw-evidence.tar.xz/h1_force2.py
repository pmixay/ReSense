from h1_explore import *


def main():
    prev=json.loads((HERE/'forcing-screen.json').read_text())
    for r in prev:
        if r['spec']['distractor']==.6 and r['spec']['distractor_width']==.08:
            print('FIRST',r)
    cfg=DetectorConfig()
    rows=[]
    for host in (False,True):
        for hh in (.1,.15,.2,.35):
            for dh in (.2,.3,.35,.4,.46):
                for offset in (.4,.6,1.59):
                    spec=dict(host=host,host_height=hh,distractor=offset,distractor_height=dh)
                    xyz,ring,lab=cast(**spec)
                    model=TrackModel(np.array([0.,0.,-2.18]),(3.,120.),0.,0.,0.)
                    fit=estimate_rails(xyz,model,cfg.track,0.,prior=model)
                    rows.append(dict(spec=spec,fit=serial(fit),counts={str(k):int((lab==k).sum()) for k in np.unique(lab)}))
    write('forcing-screen-2.json',rows)
    found=[r for r in rows if r['fit']['mids'] is not None and
        max(abs(x-r['spec']['distractor']) for x in r['fit']['mids'])<.12]
    print('FOUND',len(found))
    print(*found[:20],sep='\n')
    print('NOHOST',*[r for r in rows if not r['spec']['host'] and r['spec']['host_height']==.35][:15],sep='\n')


if __name__=='__main__': main()
