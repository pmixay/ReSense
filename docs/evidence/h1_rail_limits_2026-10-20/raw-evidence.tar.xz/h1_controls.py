from h1_run import *


def main():
    before=manifest()
    cases=[]
    for distance,lateral in ((17.,.68),(17.,-.68),(37.,.68),(67.,1.29),(67.,-1.5)):
        cases.append(('paired_correct_'+str(distance)+'_'+str(lateral),
                     [(14,dict(distance=distance,lateral=lateral,host_height=.2))]))
    cases.append(('paired_standard_near',[(14,dict(distance=17.,walls=2.43))]))
    for distance in (17.,67.):
        cases.append(('wrong_inside_control_'+str(distance),[(14,dict(distance=distance,
            host_height=.2,distractor=.6,distractor_height=.3))]))
    results=[full_case(*x) for x in cases]
    write('additional-controls-summary.json',results)
    assert manifest()==before


if __name__=='__main__': main()
