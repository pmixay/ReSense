"""Preregistered forcing screen. Writes no production code and runs no held-out data."""
import dataclasses as dc
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import numpy as np
from h1_cast import cast
from resense.config import DetectorConfig
from resense.detector import Detector
from resense.frame import Frame
from resense.track import TrackModel, estimate_rails

HERE=Path(__file__).resolve().parent
ROOT=Path(os.environ['RESENSE_REPO'])


def digest(a):
    return hashlib.sha256(a.tobytes()).hexdigest()


def serial(x):
    if dc.is_dataclass(x):
        return {f.name:serial(getattr(x,f.name)) for f in dc.fields(x)}
    if isinstance(x,np.ndarray):
        return x.tolist()
    if isinstance(x,np.generic):
        return serial(x.item())
    if isinstance(x,float) and not np.isfinite(x):
        return str(x)
    if isinstance(x,dict):
        return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):
        return [serial(v) for v in x]
    return x


def write(name,data):
    p=HERE/name
    assert not p.exists(), p
    p.write_text(json.dumps(serial(data),separators=(',',':'),allow_nan=False)+'\n')
    assert p.stat().st_size < 20_000_000


def main():
    fixture=runpy.run_path(str(ROOT/'tests/fixtures/h1_physical.py'))['physical_column']
    checks=[]
    for rails in (False,True):
        a=fixture(rails=rails)
        b=cast(host=rails,bed=-2.18 if rails else -1.83,walls=2.43)
        checks.append(dict(rails=rails,xyz_exact=np.array_equal(a[0],b[0]),
                           ring_exact=np.array_equal(a[1],b[1]),xyz_sha=digest(b[0]),
                           target=int((b[2]==1).sum()),fixture_target=int((a[2]==1).sum())))
    assert all(c['xyz_exact'] and c['ring_exact'] and c['target']==84 for c in checks)
    assert checks[0]['xyz_sha']=='680878ed4f0b233cec517f999ca8648b1193522c929b7ce0f9df9fad7d545a20'
    write('caster-controls.json',checks)
    cfg=DetectorConfig()
    model=TrackModel(np.array([0.,0.,-2.18]),(3.,120.),0.,0.,0.)
    rows=[]
    for offset in (.4,.6,1.59,-.4,-.6,-1.59):
        for hh in (.2,.35):
            for dh in (.4,.46,.48):
                for rw in (.08,.16):
                    spec=dict(distractor=offset,host_height=hh,distractor_height=dh,distractor_width=rw)
                    xyz,ring,lab=cast(**spec)
                    fit=estimate_rails(xyz,model,cfg.track,0.,prior=model)
                    rows.append(dict(spec=spec,fit=serial(fit),n=len(xyz),
                        raw_sha=digest(xyz),counts={str(k):int((lab==k).sum()) for k in np.unique(lab)}))
    write('forcing-screen.json',rows)
    good=[r for r in rows if r['fit']['mids'] is not None and
          max(abs(x-r['spec']['distractor']) for x in r['fit']['mids'])<.12]
    print('CASTER_CONTROLS',checks)
    print('SCREEN',len(rows),'ACTUAL_WRONG_COMPONENT',len(good))
    for offset in (.4,.6,1.59,-.4,-.6,-1.59):
        group=[r for r in good if r['spec']['distractor']==offset]
        print('OFFSET',offset,'N',len(group),'EXAMPLE',group[0] if group else None)
    # Fresh full pipeline probes; model above is NOT supplied to Detector.
    probes=[]
    for offset in (None,.4,.6,1.59,-.6):
        for lateral in (.68,1.29):
            xyz,ring,lab=cast(distractor=offset,lateral=lateral)
            det=Detector(cfg)
            frames=[]
            for i in range(14):
                if det._previous_latency_ms is not None:
                    det._previous_latency_ms=42.
                r=det.process(Frame(xyz=xyz,intensity=np.full(len(xyz),35,np.float32),ring=ring,stamp=i*.1))
                fit=estimate_rails(r.xyz,r.track,cfg.track,r.track.center,prior=r.track)
                frames.append(dict(i=i,track=r.track.to_dict(),fit=serial(fit),
                    target_candidates=[serial(c) for c in r.candidates if abs(c.distance-67)<1],
                    detections=serial(r.detections),warnings=serial(r.warnings)))
            probes.append(dict(offset=offset,lateral=lateral,frames=frames))
            last=frames[-1]
            print('FULL',offset,lateral,'center',r.track.center,'fit',fit.center,fit.mids,
                'cand',[(c['zone'],c['reason'],c['collision_core']) for c in last['target_candidates']],
                'dets',[(d['distance'],d['lateral']) for d in last['detections']])
    write('full-forcing-probes.json',probes)


if __name__=='__main__':
    main()
