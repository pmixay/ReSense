from h1_run import *


def main():
    rows=[full_case('paired_host_near_center',[(14,dict(distance=17.,lateral=0.,host_height=.2))])]
    write('near-control-summary.json',rows)


if __name__=='__main__': main()
