"""Seal evidence-only receipts and inspect all stored JSON/NPZ/source archive members."""
import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import numpy as np
from h1_verify import HERE,load,save


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    before=load('manifest-before.json')
    root=Path(os.environ['RESENSE_REPO'])
    final=dict(head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),
        index_sha=sha(root/'.git/index'),files={p:sha(root/p) for p in before['files']},
        python_binary_sha256=sha('/tmp/opencode/resense-b4-venv/bin/python'),
        git_status=subprocess.check_output(['git','-C',str(root),'status','--short'],text=True),
        git_tracked_diff=subprocess.check_output(['git','-C',str(root),'diff','--stat'],text=True))
    assert all(final[k]==before[k] for k in ('head','index_sha','files'))
    save('manifest-final.json',final)
    # Persist successful and failed run logs, each bounded well below file limit.
    logparent=Path('/tmp/opencode/h1-rail-limits')
    for p in sorted(logparent.glob('*.log')):
        target=HERE/('log-'+p.name)
        assert not target.exists()
        shutil.copyfile(p,target)
    summaries=load('run-summary.json')+load('additional-controls-summary.json')+load('floor-summary.json')
    if (HERE/'near-control-summary.json').exists(): summaries+=load('near-control-summary.json')
    independent=load('independent-check-complete.json')
    verified={r['name']:r for r in independent['rows']}
    table=[]
    for summary in summaries:
        data=load(summary['name']+'.json');frames=data['frames'];stages=[];start=0
        for count,spec in data['stages']:
            fs=frames[start:start+count];vs=verified[summary['name']]['frames'][start:start+count]
            selected=collections.Counter(q['selected'] for f in vs for q in f['selected_fits'] if q['caller']=='estimate_track')
            # Both source hashes and independently rereplayed outputs cover all candidates.
            all_core=[f['i'] for f in fs if any(c['collision_core'] for c in f['output']['candidates'])]
            if not spec.get('host',True) and spec.get('distractor') is None: assert not all_core
            stages.append(dict(start=start,count=count,geometry=spec,
                target_STOP=[f['i'] for f in fs if f['target_detection_indices']],
                global_STOP=[f['i'] for f in fs if f['output']['obstacle']],all_candidate_core=all_core,
                floor_held=[f['i'] for f in fs if f['output']['track']['floor_held']],selected_track_pairs=dict(selected)))
            start+=count
        row=dict(name=summary['name'],stages=stages);table.append(row)
        print('FINAL_CASE',json.dumps(row,separators=(',',':')))
    checks=dict(
        source_and_index_unchanged=True,freeze_digest='6d091081769104657ecc2c0b06f53049647d4f6c7327b7429bbda92673782452',
        directed_cases=len(summaries),directed_scans=sum(r['scans'] for r in summaries),
        plain_traced_exact_scans=sum(sum(load(r['name']+'.json')['plain_traced_exact']) for r in summaries),
        independent_fresh_raw_replay_scans=load('fresh-raw-recheck-complete.json')['scans'],
        component_cases=len(load('components.json')),original_tests='104 passed in 22.27s',
        geometric_samples=independent['ray_samples'],independent_fit_calls=independent['fit_calls'],
        independent_core_calls=independent['core_calls'],core_rules=independent['core_rules'],
        raw_anchor_coordinate_checks=load('raw-anchor-coordinate-check-complete.json'),cases=table,
        unverified=['Real-world prevalence of synthetic 0.20/0.30 m box-ridge geometry',
            'Wrong host selection for standard 0.35 m host in tested forcing grid',
            'Actual +/-1.59 m wrong selection: supplied-coordinate component attempts had no qualified fit',
            'Calibration-hypothesis estimate_rails calls are captured but not independently rederived',
            'Full-pipeline floor_held anchor guard with simultaneously visible target body: physical blocker hides target; supplied held-model guard is component-only',
            'Longer persistence than the tested 14 no-rail scans, dynamic/curved/real recordings, G3'])
    save('ACCEPTANCE.json',checks)
    # Reopen every source archive member and compare its bytes to the source manifest.
    source_members=[]
    with tarfile.open(HERE/'source.tar.gz','r:gz') as tar:
        for member in tar.getmembers():
            stream=tar.extractfile(member);h=hashlib.sha256(stream.read()).hexdigest()
            assert h==before['files'][member.name]
            source_members.append(dict(path=member.name,bytes=member.size,sha256=h))
    # Reopen all raw arrays; compressed artifacts are inputs, not claims of checksums.
    raw_members=[]
    for p in sorted(HERE.glob('*.npz')):
        with np.load(p) as raw:
            raw_members.append(dict(path=p.name,arrays={k:dict(shape=list(raw[k].shape),dtype=raw[k].dtype.str,
                sha256=hashlib.sha256(raw[k].tobytes()).hexdigest()) for k in raw.files}))
    for p in HERE.glob('*.json'): json.loads(p.read_text(),parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
    save('container-member-checks.json',dict(source_members=source_members,raw_files=raw_members))
    files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(HERE.iterdir()) if p.is_file()}
    assert all(v['bytes']<20_000_000 for v in files.values())
    save('artifact-manifest.json',dict(files=files,file_count=len(files),total_bytes=sum(v['bytes'] for v in files.values()),
        largest=max(files,key=lambda k:files[k]['bytes']),exclude_self=True))
    print('PACKAGE',len(files),'BYTES',sum(v['bytes'] for v in files.values()),'LARGEST',max(v['bytes'] for v in files.values()))


if __name__=='__main__': main()
