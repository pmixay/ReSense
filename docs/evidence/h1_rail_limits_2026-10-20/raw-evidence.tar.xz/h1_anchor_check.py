"""Verify raw-coordinate anchors/intervals and every current core d/h snapshot."""
import collections
import math
import numpy as np
from h1_verify import HERE,load,save,shape,bed_z


def axis(model,x): return model['center']+shape(model,x)


def close(a,b):
    if a is None or b is None: return a is None and b is None
    return np.asarray(a).shape==np.asarray(b).shape and np.allclose(a,b,rtol=0,atol=1e-6)


def main():
    summaries=load('run-summary.json')+load('additional-controls-summary.json')+load('floor-summary.json')
    if (HERE/'near-control-summary.json').exists(): summaries+=load('near-control-summary.json')
    n_anchor=n_interval=n_coord=n_boundaries=0;returns=collections.Counter();core_positive=False;anchor_positive=False
    vote_checks=0;raw_pair_examples=[]
    for case in summaries:
        data=load(case['name']+'.json');tcfg=load('manifest-before.json')['config']['track']
        for frame in data['frames']:
            p=np.load(HERE/frame['processed'])['xyz'];model=frame['output']['track']
            if model['floor_held']:
                assert any(e['function']=='_floor_shadow' and e['result'][-1] for e in frame['events'])
            lastfit=None;lastanchor=None
            for e in frame['events']:
                name=e['function']
                if name=='estimate_rails' and e['caller']=='collision_axis_anchor': lastfit=e['result']
                elif name=='collision_axis_anchor':
                    m=e['model'];anchor=None
                    if not m['floor_held'] and lastfit is not None:
                        fit=lastfit
                        if fit['score']>=tcfg['rails_min_score'] and fit['n_slabs']>=max(2,tcfg['rails_yaw_min_slabs']) and fit['xm'] is not None and fit['mids'] is not None:
                            x=np.asarray(fit['xm']);res=np.asarray(fit['mids'])-axis(m,x)
                            anchor=[float(min(res)-tcfg['rails_bin']),float(max(res)+tcfg['rails_bin'])]
                    assert close(anchor,e['result']),(case['name'],frame['i'],anchor,e['result'])
                    lastanchor=anchor;n_anchor+=1;anchor_positive |= anchor is not None
                elif name=='collision_axis_interval':
                    m=e['model'];x=e['x'];a=e['anchor'];stations=e['stations'];expected=None
                    if a is not None:
                        if stations is not None and len(stations)>=3 and min(stations)<=x<=max(stations):
                            expected=[min(0.,a[0]),max(0.,a[1])]
                        else:
                            # Derive all four boundary profiles from raw XYZ, not captured medians.
                            X=p[:,0].astype(float);dy=p[:,1]-axis(m,X);h=p[:,2]-bed_z(m,X)-m['rail_offset']
                            profiles=[]
                            for lo,hi in ((.4,1.4),(1.4,2.4)):
                                for side in (-1,1):
                                    good=(X>=4)&(X<250)&(h>=lo)&(h<hi)&(side*dy>1.4)&(side*dy<5.)
                                    bins=np.floor(X[good]/2).astype(int);ys=dy[good];zs=h[good]
                                    xx=[];vv=[]
                                    for j in sorted(set(bins)):
                                        on=bins==j
                                        if on.sum()>=2 and max(zs[on])-min(zs[on])>=.15:
                                            xx.append(2*j+1);vv.append(float(np.median(ys[on])))
                                    profiles.append((xx,vv))
                            assert e['boundaries'] is not None
                            for actual,captured in zip(profiles,e['boundaries']):
                                assert close(actual[0],captured[0]) and close(actual[1],captured[1])
                            n_boundaries+=1
                            lower=upper=0.;window=max(6.,.16*x)
                            for xx,vv in profiles:
                                near=[v for q,v in zip(xx,vv) if 8<=q<=28]
                                local=[v for q,v in zip(xx,vv) if abs(q-x)<=window]
                                if len(near)<4 or len(local)<2: break
                                b0=float(np.median(near));b1=float(np.median(local))
                                spread=max(abs(v-b0) for v in near)+max(abs(v-b1) for v in local)+.1
                                lower=min(lower,b1-b0+a[0]-spread);upper=max(upper,b1-b0+a[1]+spread)
                            else: expected=[lower,upper]
                    assert close(expected,e['result']),(case['name'],frame['i'],expected,e['result'])
                    n_interval+=1;returns['no_interval' if expected is None else 'observed_interval']+=1
                elif name=='_collision_core':
                    pts=np.asarray(e['pts']);x=pts[:,0].astype(float)
                    dy=pts[:,1]-axis(model,x);h=pts[:,2]-bed_z(model,x)-model['rail_offset']
                    assert np.allclose(dy,e['arrays']['dy'],rtol=0,atol=1e-6)
                    assert np.allclose(h,e['arrays']['h'],rtol=0,atol=1e-6)
                    n_coord+=1;core_positive |= e['result']
            # Independent vote/column checks on every saved tracker row (not only examples).
            for t in frame['tracker']:
                if abs(t['centroid'][0]-data['stages'][0][1].get('distance',67.))>=1: continue
                vote=(sum(t['zone_hist'])>=t['zone_min_fraction']*max(len(t['zone_hist']),t['zone_min_votes'])-1e-9)
                column=t['column_hold']>0 and sum(t['column_hist'])>=t['column_hold'] and not t['collision_core_ready']
                if case['name']=='loss_target_remains' and frame['i']>=14:
                    assert t['collision_core_hits']==0 and not t['collision_core_ready']
                    assert not column
                    assert bool(frame['target_detection_indices'])==vote
                vote_checks+=1
            if case['name'].startswith('wrong_') and frame['i']==13:
                raw=np.load(HERE/frame['input']);spec=data['inputs'][frame['input']]['geometry']
                slabs=[]
                for lo,hi in zip((4.,12.66666667,21.33333333),(12.66666667,21.33333333,30.)):
                    d={}
                    for label in (10,11,20,21):
                        q=raw['xyz'][(raw['labels']==label)&(raw['xyz'][:,0]>=lo)&(raw['xyz'][:,0]<hi)]
                        d[str(label)]={'n':len(q),'median_y':None if not len(q) else float(np.median(q[:,1]))}
                    slabs.append(d)
                raw_pair_examples.append(dict(case=case['name'],slabs=slabs))
    assert core_positive and anchor_positive and returns['no_interval'] and returns['observed_interval']
    import sys
    save(sys.argv[1] if len(sys.argv)>1 else 'raw-anchor-coordinate-check.json',dict(anchor_calls=n_anchor,interval_calls=n_interval,
        raw_boundary_profile_sets=n_boundaries,core_coordinate_calls=n_coord,tracker_rows=vote_checks,
        interval_returns=dict(returns),positive_controls=dict(core=bool(core_positive),anchor=bool(anchor_positive)),raw_rail_examples=raw_pair_examples))
    print('ANCHORS',n_anchor,'INTERVALS',n_interval,'RAW_BOUNDARIES',n_boundaries,'COORDS',n_coord,'TRACKS',vote_checks,dict(returns))


if __name__=='__main__': main()
